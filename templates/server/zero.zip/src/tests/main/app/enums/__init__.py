# SPDX-License-Identifier: MIT
"""Enums module tests."""
