# SPDX-License-Identifier: MIT
"""Comprehensive unit tests for enums module."""

from enum import Enum
from http import HTTPStatus

import pytest

from src.main.app.enums.auth_error_code import AuthErrorCode
from src.main.app.enums.biz_error_code import BusinessErrorCode
from src.main.app.enums.sys_error_code import SystemErrorCode
from src.main.app.libs.enums.base_error_code import ExceptionCode
from src.main.app.libs.enums.enum import (
    CommonErrorCode,
    DBTypeEnum,
    MediaTypeEnum,
    SortEnum,
)


class TestExceptionCode:
    """Test suite for ExceptionCode base class."""

    def test_exception_code_creation(self):
        """Test creating ExceptionCode instances."""
        code = ExceptionCode(code=404, message="Not found")

        assert code.code == 404
        assert code.message == "Not found"

    def test_exception_code_immutability(self):
        """Test that ExceptionCode instances are immutable via Pydantic."""
        code = ExceptionCode(code=500, message="Server error")

        # Pydantic models are typically mutable unless frozen=True
        # Test that we can create instances properly instead
        assert code.code == 500
        assert code.message == "Server error"

        # Test that assignment works (since this is a regular Pydantic model)
        code.code = 501
        assert code.code == 501

    def test_exception_code_equality(self):
        """Test ExceptionCode equality comparison."""
        code1 = ExceptionCode(code=400, message="Bad request")
        code2 = ExceptionCode(code=400, message="Bad request")
        code3 = ExceptionCode(code=401, message="Unauthorized")

        assert code1 == code2
        assert code1 != code3

    def test_exception_code_dict_conversion(self):
        """Test converting ExceptionCode to dictionary."""
        code = ExceptionCode(code=200, message="Success")

        code_dict = code.model_dump()

        assert code_dict == {"code": 200, "message": "Success"}

    def test_exception_code_json_serialization(self):
        """Test JSON serialization of ExceptionCode."""
        code = ExceptionCode(code=201, message="Created")

        json_str = code.model_dump_json()

        assert '"code":201' in json_str
        assert '"message":"Created"' in json_str

    def test_exception_code_from_dict(self):
        """Test creating ExceptionCode from dictionary."""
        data = {"code": 422, "message": "Unprocessable entity"}

        code = ExceptionCode(**data)

        assert code.code == 422
        assert code.message == "Unprocessable entity"

    def test_exception_code_validation(self):
        """Test ExceptionCode validation."""
        # Valid creation
        code = ExceptionCode(code=100, message="Continue")
        assert code.code == 100

        # Test with different types
        code_with_str = ExceptionCode(code="200", message="OK")
        assert code_with_str.code == 200  # Should be converted to int

    def test_exception_code_string_representation(self):
        """Test string representation of ExceptionCode."""
        code = ExceptionCode(code=418, message="I'm a teapot")

        str_repr = str(code)

        assert "418" in str_repr
        assert "I'm a teapot" in str_repr


class TestSortEnum:
    """Test suite for SortEnum."""

    def test_sort_enum_values(self):
        """Test SortEnum values are correct."""
        assert SortEnum.ascending == "asc"
        assert SortEnum.descending == "desc"

    def test_sort_enum_is_string_enum(self):
        """Test that SortEnum inherits from str and Enum."""
        assert isinstance(SortEnum.ascending, str)
        assert isinstance(SortEnum.ascending, Enum)

    def test_sort_enum_membership(self):
        """Test membership testing for SortEnum."""
        assert "asc" in SortEnum
        assert "desc" in SortEnum
        assert "invalid" not in SortEnum

    def test_sort_enum_iteration(self):
        """Test iterating over SortEnum values."""
        values = list(SortEnum)

        assert len(values) == 2
        assert SortEnum.ascending in values
        assert SortEnum.descending in values

    def test_sort_enum_string_operations(self):
        """Test string operations work on SortEnum values."""
        asc = SortEnum.ascending

        assert asc.upper() == "ASC"
        assert asc.startswith("a")
        assert len(asc) == 3

    def test_sort_enum_comparison(self):
        """Test comparison operations on SortEnum."""
        assert SortEnum.ascending == "asc"
        assert SortEnum.descending == "desc"
        assert SortEnum.ascending != SortEnum.descending

    def test_sort_enum_from_string(self):
        """Test creating SortEnum from string values."""
        assert SortEnum("asc") == SortEnum.ascending
        assert SortEnum("desc") == SortEnum.descending

        with pytest.raises(ValueError):
            SortEnum("invalid")


class TestDBTypeEnum:
    """Test suite for DBTypeEnum."""

    def test_db_type_enum_values(self):
        """Test DBTypeEnum values are correct."""
        assert DBTypeEnum.PGSQL == "postgresql"
        assert DBTypeEnum.MYSQL == "mysql"
        assert DBTypeEnum.SQLITE == "sqlite"

    def test_db_type_enum_is_string_enum(self):
        """Test that DBTypeEnum inherits from str and Enum."""
        assert isinstance(DBTypeEnum.PGSQL, str)
        assert isinstance(DBTypeEnum.PGSQL, Enum)

    def test_db_type_enum_membership(self):
        """Test membership testing for DBTypeEnum."""
        assert "postgresql" in DBTypeEnum
        assert "mysql" in DBTypeEnum
        assert "sqlite" in DBTypeEnum
        assert "oracle" not in DBTypeEnum

    def test_db_type_enum_iteration(self):
        """Test iterating over DBTypeEnum values."""
        values = list(DBTypeEnum)

        assert len(values) == 3
        assert DBTypeEnum.PGSQL in values
        assert DBTypeEnum.MYSQL in values
        assert DBTypeEnum.SQLITE in values

    def test_db_type_enum_string_operations(self):
        """Test string operations work on DBTypeEnum values."""
        pgsql = DBTypeEnum.PGSQL

        assert pgsql.startswith("postgre")
        assert "sql" in pgsql
        assert len(pgsql) == 10

    def test_db_type_enum_comparison(self):
        """Test comparison operations on DBTypeEnum."""
        assert DBTypeEnum.MYSQL == "mysql"
        assert DBTypeEnum.SQLITE != DBTypeEnum.MYSQL
        assert DBTypeEnum.PGSQL != "postgres"  # Not exact match

    def test_db_type_enum_from_string(self):
        """Test creating DBTypeEnum from string values."""
        assert DBTypeEnum("postgresql") == DBTypeEnum.PGSQL
        assert DBTypeEnum("mysql") == DBTypeEnum.MYSQL
        assert DBTypeEnum("sqlite") == DBTypeEnum.SQLITE

        with pytest.raises(ValueError):
            DBTypeEnum("mongodb")


class TestMediaTypeEnum:
    """Test suite for MediaTypeEnum."""

    def test_media_type_enum_values(self):
        """Test MediaTypeEnum values are correct."""
        assert MediaTypeEnum.JSON == ".json"

    def test_media_type_enum_is_string_enum(self):
        """Test that MediaTypeEnum inherits from str and Enum."""
        assert isinstance(MediaTypeEnum.JSON, str)
        assert isinstance(MediaTypeEnum.JSON, Enum)

    def test_media_type_enum_membership(self):
        """Test membership testing for MediaTypeEnum."""
        assert ".json" in MediaTypeEnum
        assert ".xml" not in MediaTypeEnum

    def test_media_type_enum_iteration(self):
        """Test iterating over MediaTypeEnum values."""
        values = list(MediaTypeEnum)

        assert len(values) == 1
        assert MediaTypeEnum.JSON in values

    def test_media_type_enum_string_operations(self):
        """Test string operations work on MediaTypeEnum values."""
        json_type = MediaTypeEnum.JSON

        assert json_type.startswith(".")
        assert json_type.endswith("json")
        assert len(json_type) == 5

    def test_media_type_enum_comparison(self):
        """Test comparison operations on MediaTypeEnum."""
        assert MediaTypeEnum.JSON == ".json"
        assert MediaTypeEnum.JSON != ".JSON"  # Case sensitive

    def test_media_type_enum_from_string(self):
        """Test creating MediaTypeEnum from string values."""
        assert MediaTypeEnum(".json") == MediaTypeEnum.JSON

        with pytest.raises(ValueError):
            MediaTypeEnum(".xml")


class TestCommonErrorCode:
    """Test suite for CommonErrorCode class."""

    def test_common_error_code_internal_server_error(self):
        """Test CommonErrorCode.INTERNAL_SERVER_ERROR."""
        error = CommonErrorCode.INTERNAL_SERVER_ERROR

        assert isinstance(error, ExceptionCode)
        assert error.code == -1
        assert error.message == "Internal server exception"

    def test_common_error_code_is_exception_code(self):
        """Test that CommonErrorCode members are ExceptionCode instances."""
        assert isinstance(CommonErrorCode.INTERNAL_SERVER_ERROR, ExceptionCode)

    def test_common_error_code_attributes(self):
        """Test CommonErrorCode class attributes."""
        # Verify the class has the expected attributes
        assert hasattr(CommonErrorCode, "INTERNAL_SERVER_ERROR")

        # Verify it's a class attribute, not instance
        assert CommonErrorCode.INTERNAL_SERVER_ERROR is not None


class TestAuthErrorCode:
    """Test suite for AuthErrorCode class."""

    def test_auth_error_code_values(self):
        """Test AuthErrorCode values are correct."""
        assert AuthErrorCode.AUTH_FAILED.code == HTTPStatus.UNAUTHORIZED
        assert AuthErrorCode.AUTH_FAILED.message == "Username or password error"

        assert AuthErrorCode.TOKEN_EXPIRED.code == HTTPStatus.UNAUTHORIZED
        assert AuthErrorCode.TOKEN_EXPIRED.message == "Token has expired"

        assert AuthErrorCode.OPENAPI_FORBIDDEN.code == HTTPStatus.FORBIDDEN
        assert AuthErrorCode.OPENAPI_FORBIDDEN.message == "OpenAPI is not ready"

        assert AuthErrorCode.MISSING_TOKEN.code == HTTPStatus.UNAUTHORIZED
        assert AuthErrorCode.MISSING_TOKEN.message == "Authentication token is missing"

    def test_auth_error_code_types(self):
        """Test that AuthErrorCode members are ExceptionCode instances."""
        assert isinstance(AuthErrorCode.AUTH_FAILED, ExceptionCode)
        assert isinstance(AuthErrorCode.TOKEN_EXPIRED, ExceptionCode)
        assert isinstance(AuthErrorCode.OPENAPI_FORBIDDEN, ExceptionCode)
        assert isinstance(AuthErrorCode.MISSING_TOKEN, ExceptionCode)

    def test_auth_error_code_http_status_codes(self):
        """Test that AuthErrorCode uses correct HTTP status codes."""
        assert AuthErrorCode.AUTH_FAILED.code == 401
        assert AuthErrorCode.TOKEN_EXPIRED.code == 401
        assert AuthErrorCode.OPENAPI_FORBIDDEN.code == 403
        assert AuthErrorCode.MISSING_TOKEN.code == 401

    def test_auth_error_code_attributes(self):
        """Test AuthErrorCode class attributes."""
        assert hasattr(AuthErrorCode, "AUTH_FAILED")
        assert hasattr(AuthErrorCode, "TOKEN_EXPIRED")
        assert hasattr(AuthErrorCode, "OPENAPI_FORBIDDEN")
        assert hasattr(AuthErrorCode, "MISSING_TOKEN")


class TestBusinessErrorCode:
    """Test suite for BusinessErrorCode class."""

    def test_business_error_code_values(self):
        """Test BusinessErrorCode values are correct."""
        assert BusinessErrorCode.USER_NAME_EXISTS.code == HTTPStatus.CONFLICT
        assert BusinessErrorCode.USER_NAME_EXISTS.message == "Username already exists"

        assert BusinessErrorCode.MENU_NAME_EXISTS.code == HTTPStatus.CONFLICT
        assert BusinessErrorCode.MENU_NAME_EXISTS.message == "Menu name already exists"

        assert BusinessErrorCode.RESOURCE_NOT_FOUND.code == HTTPStatus.NOT_FOUND
        assert (
            BusinessErrorCode.RESOURCE_NOT_FOUND.message
            == "Requested resource not found"
        )

        assert BusinessErrorCode.PARAMETER_ERROR.code == HTTPStatus.BAD_REQUEST
        assert BusinessErrorCode.PARAMETER_ERROR.message == "Parameter error"

    def test_business_error_code_types(self):
        """Test that BusinessErrorCode members are ExceptionCode instances."""
        assert isinstance(BusinessErrorCode.USER_NAME_EXISTS, ExceptionCode)
        assert isinstance(BusinessErrorCode.MENU_NAME_EXISTS, ExceptionCode)
        assert isinstance(BusinessErrorCode.RESOURCE_NOT_FOUND, ExceptionCode)
        assert isinstance(BusinessErrorCode.PARAMETER_ERROR, ExceptionCode)

    def test_business_error_code_http_status_codes(self):
        """Test that BusinessErrorCode uses correct HTTP status codes."""
        assert BusinessErrorCode.USER_NAME_EXISTS.code == 409
        assert BusinessErrorCode.MENU_NAME_EXISTS.code == 409
        assert BusinessErrorCode.RESOURCE_NOT_FOUND.code == 404
        assert BusinessErrorCode.PARAMETER_ERROR.code == 400

    def test_business_error_code_attributes(self):
        """Test BusinessErrorCode class attributes."""
        assert hasattr(BusinessErrorCode, "USER_NAME_EXISTS")
        assert hasattr(BusinessErrorCode, "MENU_NAME_EXISTS")
        assert hasattr(BusinessErrorCode, "RESOURCE_NOT_FOUND")
        assert hasattr(BusinessErrorCode, "PARAMETER_ERROR")


class TestSystemErrorCode:
    """Test suite for SystemErrorCode class."""

    def test_system_error_code_values(self):
        """Test SystemErrorCode values are correct."""
        assert SystemErrorCode.INTERNAL_ERROR.code == HTTPStatus.INTERNAL_SERVER_ERROR
        assert SystemErrorCode.INTERNAL_ERROR.message == "Internal server error"

    def test_system_error_code_types(self):
        """Test that SystemErrorCode members are ExceptionCode instances."""
        assert isinstance(SystemErrorCode.INTERNAL_ERROR, ExceptionCode)

    def test_system_error_code_http_status_codes(self):
        """Test that SystemErrorCode uses correct HTTP status codes."""
        assert SystemErrorCode.INTERNAL_ERROR.code == 500

    def test_system_error_code_attributes(self):
        """Test SystemErrorCode class attributes."""
        assert hasattr(SystemErrorCode, "INTERNAL_ERROR")


class TestEnumInteroperability:
    """Test interoperability between different enum types."""

    def test_exception_code_in_different_error_classes(self):
        """Test that ExceptionCode works consistently across error classes."""
        auth_error = AuthErrorCode.AUTH_FAILED
        biz_error = BusinessErrorCode.PARAMETER_ERROR
        sys_error = SystemErrorCode.INTERNAL_ERROR

        # All should be ExceptionCode instances
        assert isinstance(auth_error, ExceptionCode)
        assert isinstance(biz_error, ExceptionCode)
        assert isinstance(sys_error, ExceptionCode)

        # All should have code and message attributes
        assert hasattr(auth_error, "code")
        assert hasattr(auth_error, "message")
        assert hasattr(biz_error, "code")
        assert hasattr(biz_error, "message")
        assert hasattr(sys_error, "code")
        assert hasattr(sys_error, "message")

    def test_enum_values_in_container_operations(self):
        """Test enum values work in container operations."""
        db_types = [DBTypeEnum.MYSQL, DBTypeEnum.PGSQL, DBTypeEnum.SQLITE]
        sort_directions = {SortEnum.ascending, SortEnum.descending}

        assert "mysql" in db_types
        assert DBTypeEnum.MYSQL in db_types

        assert "asc" in sort_directions
        assert SortEnum.ascending in sort_directions

    def test_enum_comparison_with_strings(self):
        """Test that string enums compare correctly with strings."""
        # These should all be True
        assert SortEnum.ascending == "asc"
        assert DBTypeEnum.MYSQL == "mysql"
        assert MediaTypeEnum.JSON == ".json"

        # These should be False
        assert SortEnum.ascending != "desc"
        assert DBTypeEnum.MYSQL != "postgresql"
        assert MediaTypeEnum.JSON != "json"

    def test_error_code_uniqueness(self):
        """Test that error codes are unique within their domains."""
        auth_codes = [
            AuthErrorCode.AUTH_FAILED.code,
            AuthErrorCode.TOKEN_EXPIRED.code,
            AuthErrorCode.OPENAPI_FORBIDDEN.code,
            AuthErrorCode.MISSING_TOKEN.code,
        ]

        biz_codes = [
            BusinessErrorCode.USER_NAME_EXISTS.code,
            BusinessErrorCode.MENU_NAME_EXISTS.code,
            BusinessErrorCode.RESOURCE_NOT_FOUND.code,
            BusinessErrorCode.PARAMETER_ERROR.code,
        ]

        # Codes within each domain might repeat (like 401 for different auth errors)
        # but the combinations of code+message should be meaningful
        assert all(isinstance(code, int) for code in auth_codes)
        assert all(isinstance(code, int) for code in biz_codes)


class TestEnumImportStructure:
    """Test the import structure and module organization."""

    def test_libs_enums_imports(self):
        """Test that libs.enums module exports work correctly."""
        # These imports should work without error
        from src.main.app.libs.enums import (
            DBTypeEnum,
            ExceptionCode,
            MediaTypeEnum,
            SortEnum,
        )

        assert ExceptionCode is not None
        assert SortEnum is not None
        assert DBTypeEnum is not None
        assert MediaTypeEnum is not None

    def test_app_enums_imports(self):
        """Test that app.enums module exports work correctly."""
        # These imports should work without error
        from src.main.app.enums import AuthErrorCode, BusinessErrorCode, SystemErrorCode

        assert AuthErrorCode is not None
        assert BusinessErrorCode is not None
        assert SystemErrorCode is not None

    def test_enum_base_class_import(self):
        """Test that ExceptionCode base class imports correctly."""
        from src.main.app.libs.enums.base_error_code import ExceptionCode

        assert ExceptionCode is not None
        # ExceptionCode is a class, not an instance, so check its fields
        assert hasattr(ExceptionCode, "__fields__") or hasattr(
            ExceptionCode, "model_fields"
        )

        # Create an instance to test the fields
        instance = ExceptionCode(code=100, message="Test")
        assert hasattr(instance, "code")
        assert hasattr(instance, "message")


class TestEnumPracticalUsage:
    """Test practical usage scenarios of enums in the application."""

    def test_sort_enum_usage_in_queries(self):
        """Test SortEnum usage in query-like scenarios."""

        def sort_data(data, direction):
            if direction == SortEnum.ascending:
                return sorted(data)
            elif direction == SortEnum.descending:
                return sorted(data, reverse=True)
            else:
                raise ValueError("Invalid sort direction")

        data = [3, 1, 4, 1, 5]

        asc_result = sort_data(data, SortEnum.ascending)
        desc_result = sort_data(data, SortEnum.descending)

        assert asc_result == [1, 1, 3, 4, 5]
        assert desc_result == [5, 4, 3, 1, 1]

    def test_db_type_enum_usage_in_connection_strings(self):
        """Test DBTypeEnum usage in database connection scenarios."""

        def get_connection_string(db_type, host, database):
            if db_type == DBTypeEnum.MYSQL:
                return f"mysql://{host}/{database}"
            elif db_type == DBTypeEnum.PGSQL:
                return f"postgresql://{host}/{database}"
            elif db_type == DBTypeEnum.SQLITE:
                return f"sqlite:///{database}"
            else:
                raise ValueError("Unsupported database type")

        mysql_conn = get_connection_string(DBTypeEnum.MYSQL, "localhost", "test")
        pgsql_conn = get_connection_string(DBTypeEnum.PGSQL, "localhost", "test")
        sqlite_conn = get_connection_string(DBTypeEnum.SQLITE, "", "test.db")

        assert mysql_conn == "mysql://localhost/test"
        assert pgsql_conn == "postgresql://localhost/test"
        assert sqlite_conn == "sqlite:///test.db"

    def test_error_code_usage_in_api_responses(self):
        """Test error code usage in API response scenarios."""

        def create_error_response(error_code):
            return {
                "success": False,
                "error": {"code": error_code.code, "message": error_code.message},
            }

        auth_response = create_error_response(AuthErrorCode.AUTH_FAILED)
        biz_response = create_error_response(BusinessErrorCode.RESOURCE_NOT_FOUND)
        sys_response = create_error_response(SystemErrorCode.INTERNAL_ERROR)

        assert auth_response["error"]["code"] == 401
        assert auth_response["error"]["message"] == "Username or password error"

        assert biz_response["error"]["code"] == 404
        assert biz_response["error"]["message"] == "Requested resource not found"

        assert sys_response["error"]["code"] == 500
        assert sys_response["error"]["message"] == "Internal server error"
