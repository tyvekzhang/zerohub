# SPDX-License-Identifier: MIT
"""Controller module tests."""
