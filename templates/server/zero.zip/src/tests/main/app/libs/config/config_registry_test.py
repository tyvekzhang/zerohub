# SPDX-License-Identifier: MIT
"""Comprehensive unit tests for ConfigRegistry class and BaseConfig abstract class."""

import pytest

from src.main.app.libs.config.config_registry import (
    BaseConfig,
    ConfigRegistry,
    config_class,
)


class TestBaseConfig:
    """Test cases for BaseConfig abstract class."""

    def test_baseconfig_is_abstract(self):
        """Test that BaseConfig cannot be instantiated directly."""
        with pytest.raises(TypeError, match="Can't instantiate abstract class"):
            BaseConfig()

    def test_baseconfig_subclass_implementation(self):
        """Test that BaseConfig subclasses must implement abstract methods."""

        class IncompleteConfig(BaseConfig):
            pass

        with pytest.raises(TypeError, match="Can't instantiate abstract class"):
            IncompleteConfig()

    def test_baseconfig_valid_subclass(self):
        """Test that valid BaseConfig subclass can be instantiated."""

        class ValidConfig(BaseConfig):
            def __init__(self, name: str = "test"):
                self.name = name

            def __str__(self) -> str:
                return f"ValidConfig(name={self.name})"

        config = ValidConfig()
        assert config.name == "test"
        assert str(config) == "ValidConfig(name=test)"

        config_with_param = ValidConfig("custom")
        assert config_with_param.name == "custom"
        assert str(config_with_param) == "ValidConfig(name=custom)"


class TestConfigRegistry:
    """Test cases for ConfigRegistry class."""

    def setup_method(self):
        """Set up test fixtures before each test method."""
        # Clear registry before each test
        ConfigRegistry.clear_all()

    def teardown_method(self):
        """Clean up after each test method."""
        # Clear registry after each test
        ConfigRegistry.clear_all()

    def test_registry_singleton_behavior(self):
        """Test that ConfigRegistry maintains singleton-like behavior for registry data."""

        class TestConfig1(BaseConfig):
            def __init__(self, value: str = "test1"):
                self.value = value

            def __str__(self) -> str:
                return f"TestConfig1(value={self.value})"

        ConfigRegistry.register("test1", TestConfig1)

        # Check that registry data persists across different access methods
        assert "test1" in ConfigRegistry.list_registered()
        assert ConfigRegistry.get_config_class("test1") == TestConfig1

    def test_register_valid_config_class(self):
        """Test registering a valid configuration class."""

        class TestConfig(BaseConfig):
            def __init__(self, name: str = "test"):
                self.name = name

            def __str__(self) -> str:
                return f"TestConfig(name={self.name})"

        ConfigRegistry.register("test_config", TestConfig)
        assert ConfigRegistry.get_config_class("test_config") == TestConfig
        assert "test_config" in ConfigRegistry.list_registered()

    def test_register_duplicate_name_raises_error(self):
        """Test that registering duplicate name raises ValueError."""

        class TestConfig1(BaseConfig):
            def __init__(self):
                pass

            def __str__(self) -> str:
                return "TestConfig1"

        class TestConfig2(BaseConfig):
            def __init__(self):
                pass

            def __str__(self) -> str:
                return "TestConfig2"

        ConfigRegistry.register("duplicate", TestConfig1)

        with pytest.raises(
            ValueError, match="Configuration 'duplicate' is already registered"
        ):
            ConfigRegistry.register("duplicate", TestConfig2)

    def test_register_invalid_config_class_raises_error(self):
        """Test that registering non-BaseConfig class raises ValueError."""

        class InvalidConfig:
            pass

        with pytest.raises(
            ValueError, match="Configuration class must inherit from BaseConfig"
        ):
            ConfigRegistry.register("invalid", InvalidConfig)

    def test_unregister_existing_config(self):
        """Test unregistering an existing configuration."""

        class TestConfig(BaseConfig):
            def __init__(self):
                pass

            def __str__(self) -> str:
                return "TestConfig"

        ConfigRegistry.register("test_config", TestConfig)
        assert "test_config" in ConfigRegistry.list_registered()

        ConfigRegistry.unregister("test_config")
        assert "test_config" not in ConfigRegistry.list_registered()
        assert ConfigRegistry.get_config_class("test_config") is None

    def test_unregister_nonexistent_config(self):
        """Test unregistering non-existent configuration doesn't raise error."""
        # Should not raise any exception
        ConfigRegistry.unregister("nonexistent")

    def test_get_config_class_existing(self):
        """Test getting an existing configuration class."""

        class TestConfig(BaseConfig):
            def __init__(self):
                pass

            def __str__(self) -> str:
                return "TestConfig"

        ConfigRegistry.register("test_config", TestConfig)
        retrieved_class = ConfigRegistry.get_config_class("test_config")
        assert retrieved_class == TestConfig

    def test_get_config_class_nonexistent(self):
        """Test getting non-existent configuration class returns None."""
        result = ConfigRegistry.get_config_class("nonexistent")
        assert result is None

    def test_create_instance_success(self):
        """Test creating instance of registered configuration class."""

        class TestConfig(BaseConfig):
            def __init__(self, name: str = "default", value: int = 0):
                self.name = name
                self.value = value

            def __str__(self) -> str:
                return f"TestConfig(name={self.name}, value={self.value})"

        ConfigRegistry.register("test_config", TestConfig)

        config_data = {"test_config": {"name": "test", "value": 42}}
        instance = ConfigRegistry.create_instance("test_config", config_data)

        assert instance is not None
        assert isinstance(instance, TestConfig)
        assert instance.name == "test"
        assert instance.value == 42

    def test_create_instance_with_empty_config_data(self):
        """Test creating instance with empty configuration data."""

        class TestConfig(BaseConfig):
            def __init__(self, name: str = "default"):
                self.name = name

            def __str__(self) -> str:
                return f"TestConfig(name={self.name})"

        ConfigRegistry.register("test_config", TestConfig)

        config_data = {"test_config": {}}
        instance = ConfigRegistry.create_instance("test_config", config_data)

        assert instance is not None
        assert instance.name == "default"

    def test_create_instance_nonexistent_config(self):
        """Test creating instance of non-existent configuration returns None."""
        config_data = {"nonexistent": {"name": "test"}}
        instance = ConfigRegistry.create_instance("nonexistent", config_data)
        assert instance is None

    def test_create_instance_invalid_parameters(self):
        """Test creating instance with invalid parameters raises ValueError."""

        class TestConfig(BaseConfig):
            def __init__(self, required_param: str):
                self.required_param = required_param

            def __str__(self) -> str:
                return f"TestConfig(required_param={self.required_param})"

        ConfigRegistry.register("test_config", TestConfig)

        config_data = {"test_config": {}}  # Missing required_param

        with pytest.raises(
            ValueError, match="Failed to create test_config config instance"
        ):
            ConfigRegistry.create_instance("test_config", config_data)

    def test_get_instance_existing(self):
        """Test getting cached configuration instance."""

        class TestConfig(BaseConfig):
            def __init__(self, name: str = "test"):
                self.name = name

            def __str__(self) -> str:
                return f"TestConfig(name={self.name})"

        ConfigRegistry.register("test_config", TestConfig)

        config_data = {"test_config": {"name": "cached"}}
        created_instance = ConfigRegistry.create_instance("test_config", config_data)
        retrieved_instance = ConfigRegistry.get_instance("test_config")

        assert retrieved_instance is not None
        assert retrieved_instance is created_instance
        assert retrieved_instance.name == "cached"

    def test_get_instance_nonexistent(self):
        """Test getting non-existent cached instance returns None."""
        result = ConfigRegistry.get_instance("nonexistent")
        assert result is None

    def test_list_registered_empty(self):
        """Test listing registered configurations when registry is empty."""
        result = ConfigRegistry.list_registered()
        assert result == []

    def test_list_registered_multiple(self):
        """Test listing multiple registered configurations."""

        class TestConfig1(BaseConfig):
            def __init__(self):
                pass

            def __str__(self) -> str:
                return "TestConfig1"

        class TestConfig2(BaseConfig):
            def __init__(self):
                pass

            def __str__(self) -> str:
                return "TestConfig2"

        ConfigRegistry.register("config1", TestConfig1)
        ConfigRegistry.register("config2", TestConfig2)

        registered = ConfigRegistry.list_registered()
        assert len(registered) == 2
        assert "config1" in registered
        assert "config2" in registered

    def test_clear_instances(self):
        """Test clearing cached instances."""

        class TestConfig(BaseConfig):
            def __init__(self, name: str = "test"):
                self.name = name

            def __str__(self) -> str:
                return f"TestConfig(name={self.name})"

        ConfigRegistry.register("test_config", TestConfig)

        config_data = {"test_config": {"name": "test"}}
        ConfigRegistry.create_instance("test_config", config_data)

        # Verify instance exists
        assert ConfigRegistry.get_instance("test_config") is not None

        # Clear instances
        ConfigRegistry.clear_instances()

        # Verify instance is cleared but registration remains
        assert ConfigRegistry.get_instance("test_config") is None
        assert ConfigRegistry.get_config_class("test_config") is not None

    def test_clear_all(self):
        """Test clearing both registry and instances."""

        class TestConfig(BaseConfig):
            def __init__(self):
                pass

            def __str__(self) -> str:
                return "TestConfig"

        ConfigRegistry.register("test_config", TestConfig)
        config_data = {"test_config": {}}
        ConfigRegistry.create_instance("test_config", config_data)

        # Verify both registration and instance exist
        assert ConfigRegistry.get_config_class("test_config") is not None
        assert ConfigRegistry.get_instance("test_config") is not None

        # Clear all
        ConfigRegistry.clear_all()

        # Verify both are cleared
        assert ConfigRegistry.get_config_class("test_config") is None
        assert ConfigRegistry.get_instance("test_config") is None
        assert ConfigRegistry.list_registered() == []

    def test_instance_caching_behavior(self):
        """Test that instances are properly cached and reused."""

        class TestConfig(BaseConfig):
            def __init__(self, name: str = "test"):
                self.name = name
                self.creation_count = getattr(TestConfig, "_creation_count", 0) + 1
                TestConfig._creation_count = self.creation_count

            def __str__(self) -> str:
                return f"TestConfig(name={self.name}, count={self.creation_count})"

        ConfigRegistry.register("test_config", TestConfig)

        config_data = {"test_config": {"name": "test"}}

        # Create instance twice
        instance1 = ConfigRegistry.create_instance("test_config", config_data)
        instance2 = ConfigRegistry.create_instance("test_config", config_data)

        # Second call should create a new instance (overwrites cache)
        assert instance1 is not instance2
        assert instance2.creation_count == 2

        # But get_instance should return the most recent cached instance
        cached_instance = ConfigRegistry.get_instance("test_config")
        assert cached_instance is instance2


class TestConfigClassDecorator:
    """Test cases for config_class decorator."""

    def setup_method(self):
        """Set up test fixtures before each test method."""
        ConfigRegistry.clear_all()

    def teardown_method(self):
        """Clean up after each test method."""
        ConfigRegistry.clear_all()

    def test_config_class_decorator_success(self):
        """Test successful use of config_class decorator."""

        @config_class("decorated_config")
        class DecoratedConfig(BaseConfig):
            def __init__(self, name: str = "decorated"):
                self.name = name

            def __str__(self) -> str:
                return f"DecoratedConfig(name={self.name})"

        # Verify the class is registered
        assert ConfigRegistry.get_config_class("decorated_config") == DecoratedConfig
        assert "decorated_config" in ConfigRegistry.list_registered()

    def test_config_class_decorator_returns_original_class(self):
        """Test that decorator returns the original class."""

        @config_class("test_config")
        class TestConfig(BaseConfig):
            def __init__(self):
                pass

            def __str__(self) -> str:
                return "TestConfig"

        # Verify the decorated class can still be used normally
        instance = TestConfig()
        assert isinstance(instance, TestConfig)
        assert str(instance) == "TestConfig"

    def test_config_class_decorator_duplicate_registration(self):
        """Test decorator with duplicate registration."""

        @config_class("duplicate")
        class FirstConfig(BaseConfig):
            def __init__(self):
                pass

            def __str__(self) -> str:
                return "FirstConfig"

        # Should raise error on duplicate registration
        with pytest.raises(
            ValueError, match="Configuration 'duplicate' is already registered"
        ):

            @config_class("duplicate")
            class SecondConfig(BaseConfig):
                def __init__(self):
                    pass

                def __str__(self) -> str:
                    return "SecondConfig"
