# SPDX-License-Identifier: MIT

"""Main entry point of the application."""

import argparse
import os
import sys

import uvicorn
from loguru import logger

current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)


def parse_arguments() -> argparse.Namespace:
    """Parse and return command line arguments."""
    parser = argparse.ArgumentParser(
        description="Fast web server with custom configurations"
    )

    parser.add_argument(
        "-e",
        "--env",
        type=str,
        choices=["dev", "test", "prod"], # Add expected environments
        default="dev",
        help="Specify the runtime environment (dev|test|prod)",
    )
    parser.add_argument(
        "-c",
        "--config-file",
        type=str,
        default=None,
        help="Path to a custom configuration file",
    )

    return parser.parse_args()


def configure_environment(args: argparse.Namespace) -> None:
    """Set up environment variables based on command line arguments."""
    from src.main.app.libs import constant

    os.environ[constant.ENV] = args.env
    if args.config_file:
        os.environ[constant.CONFIG_FILE] = args.config_file


def run_server() -> None:
    """Load configuration and start the Uvicorn server."""
    from src.main.app.libs.config import config_manager

    server_config = config_manager.load_server_config()
    logger.info(f"OpenAPI url: http://{server_config.host}:{server_config.port}/docs")
    uvicorn.run(
        app="src.main.app.server:app",
        host=server_config.host,
        port=server_config.port,
        workers=server_config.workers,
    )


def main() -> None:
    """Main application entry point."""
    args = parse_arguments()
    configure_environment(args)
    run_server()


if __name__ == "__main__":
    main()
