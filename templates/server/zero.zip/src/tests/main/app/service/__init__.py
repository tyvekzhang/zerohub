# SPDX-License-Identifier: MIT
"""Service module tests."""
