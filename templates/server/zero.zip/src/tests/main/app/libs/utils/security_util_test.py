# SPDX-License-Identifier: MIT
"""Unit tests for security_util module."""

import base64
import hmac
import os
import tempfile
from unittest.mock import MagicMock, patch
import hashlib

import pytest

from src.main.app.libs.utils.security_util import (
    HAS_CRYPTOGRAPHY,
    HMACSigner,
    SimpleSymmetricEncryption,
    SymmetricEncryption,
    RSASigner,
    create_symmetric_encryption,
    decrypt_data,
    encrypt_data,
    generate_random_key,
    hash_password,
    verify_password,
)


class TestHMACSigner:
    """Test suite for HMACSigner class."""

    def test_hmac_signer_init_with_string_key(self):
        """Test HMACSigner initialization with string key."""
        key = "secret_key"
        signer = HMACSigner(key)
        assert signer._secret_key == key.encode('utf-8')
        assert signer._hash_func == hashlib.sha256

    def test_hmac_signer_init_with_bytes_key(self):
        """Test HMACSigner initialization with bytes key."""
        key = b"secret_key"
        signer = HMACSigner(key)
        assert signer._secret_key == key
        assert signer._hash_func == hashlib.sha256

    def test_hmac_signer_init_with_different_algorithms(self):
        """Test HMACSigner initialization with different algorithms."""
        key = "secret"
        
        signer_256 = HMACSigner(key, "sha256")
        assert signer_256._hash_func == hashlib.sha256
        
        signer_384 = HMACSigner(key, "sha384")
        assert signer_384._hash_func == hashlib.sha384
        
        signer_512 = HMACSigner(key, "sha512")
        assert signer_512._hash_func == hashlib.sha512

    def test_hmac_signer_init_with_invalid_algorithm(self):
        """Test HMACSigner initialization with invalid algorithm."""
        with pytest.raises(ValueError, match="Unsupported algorithm: invalid"):
            HMACSigner("key", "invalid")

    def test_hmac_sign_with_string_message(self):
        """Test HMAC signing with string message."""
        signer = HMACSigner("secret_key")
        message = "hello world"
        signature = signer.sign(message)
        
        assert isinstance(signature, str)
        # Verify signature can be decoded as base64
        decoded = base64.b64decode(signature.encode('utf-8'))
        assert len(decoded) == 32  # SHA256 produces 32-byte hash

    def test_hmac_sign_with_bytes_message(self):
        """Test HMAC signing with bytes message."""
        signer = HMACSigner("secret_key")
        message = b"hello world"
        signature = signer.sign(message)
        
        assert isinstance(signature, str)
        decoded = base64.b64decode(signature.encode('utf-8'))
        assert len(decoded) == 32

    def test_hmac_verify_valid_signature(self):
        """Test HMAC verification with valid signature."""
        signer = HMACSigner("secret_key")
        message = "hello world"
        signature = signer.sign(message)
        
        assert signer.verify(message, signature) is True

    def test_hmac_verify_invalid_signature(self):
        """Test HMAC verification with invalid signature."""
        signer = HMACSigner("secret_key")
        message = "hello world"
        invalid_signature = "invalid_signature"
        
        assert signer.verify(message, invalid_signature) is False

    def test_hmac_verify_tampered_message(self):
        """Test HMAC verification with tampered message."""
        signer = HMACSigner("secret_key")
        original_message = "hello world"
        signature = signer.sign(original_message)
        tampered_message = "hello world!"
        
        assert signer.verify(tampered_message, signature) is False

    def test_hmac_sign_data_dictionary(self):
        """Test HMAC signing with dictionary data."""
        signer = HMACSigner("secret_key")
        data = {"user_id": "123", "amount": "100.50", "currency": "USD"}
        signature = signer.sign_data(data)
        
        assert isinstance(signature, str)
        assert signer.verify_data(data, signature) is True

    def test_hmac_verify_data_with_different_order(self):
        """Test HMAC verification with dictionary data in different order."""
        signer = HMACSigner("secret_key")
        data1 = {"user_id": "123", "amount": "100.50", "currency": "USD"}
        data2 = {"currency": "USD", "user_id": "123", "amount": "100.50"}
        
        signature = signer.sign_data(data1)
        assert signer.verify_data(data2, signature) is True

    def test_hmac_verify_data_with_tampered_value(self):
        """Test HMAC verification with tampered dictionary value."""
        signer = HMACSigner("secret_key")
        original_data = {"user_id": "123", "amount": "100.50"}
        tampered_data = {"user_id": "123", "amount": "200.00"}
        
        signature = signer.sign_data(original_data)
        assert signer.verify_data(tampered_data, signature) is False

    def test_hmac_consistency_across_calls(self):
        """Test HMAC signature consistency across multiple calls."""
        signer = HMACSigner("secret_key")
        message = "test message"
        
        signature1 = signer.sign(message)
        signature2 = signer.sign(message)
        
        assert signature1 == signature2

    @pytest.mark.parametrize("algorithm", ["sha256", "sha384", "sha512"])
    def test_hmac_with_different_algorithms(self, algorithm):
        """Test HMAC signing and verification with different algorithms."""
        signer = HMACSigner("secret_key", algorithm)
        message = "test message"
        signature = signer.sign(message)
        
        assert signer.verify(message, signature) is True

    def test_hmac_verify_exception_handling(self):
        """Test HMAC verification handles exceptions gracefully."""
        signer = HMACSigner("secret_key")
        
        # Test with malformed base64
        assert signer.verify("message", "invalid_base64!@#") is False
        
        # Test with empty signature
        assert signer.verify("message", "") is False


class TestSimpleSymmetricEncryption:
    """Test suite for SimpleSymmetricEncryption class."""

    def test_simple_encryption_init_with_no_key(self):
        """Test SimpleSymmetricEncryption initialization without key."""
        encryptor = SimpleSymmetricEncryption()
        assert len(encryptor._key) == 32
        assert isinstance(encryptor._key, bytes)

    def test_simple_encryption_init_with_key(self):
        """Test SimpleSymmetricEncryption initialization with provided key."""
        key = b"test_key_1234567890123456789012"  # 32 bytes
        encryptor = SimpleSymmetricEncryption(key)
        # Key should be exactly 32 bytes, padded if necessary
        assert len(encryptor._key) == 32
        assert encryptor._key.startswith(key)

    def test_simple_encryption_init_with_short_key(self):
        """Test SimpleSymmetricEncryption initialization with short key."""
        short_key = b"short"
        encryptor = SimpleSymmetricEncryption(short_key)
        assert len(encryptor._key) == 32
        assert encryptor._key.startswith(short_key)

    def test_simple_encryption_init_with_long_key(self):
        """Test SimpleSymmetricEncryption initialization with long key."""
        long_key = b"this_is_a_very_long_key_that_exceeds_32_bytes_in_length"
        encryptor = SimpleSymmetricEncryption(long_key)
        assert len(encryptor._key) == 32
        assert encryptor._key == long_key[:32]

    def test_simple_encryption_get_key(self):
        """Test getting the encryption key."""
        key = b"test_key_123456789012345678901"  # 31 bytes
        encryptor = SimpleSymmetricEncryption(key)
        # Key should be padded to 32 bytes
        assert len(encryptor.get_key()) == 32
        assert encryptor.get_key().startswith(key)

    def test_simple_encrypt_decrypt_string(self):
        """Test encrypting and decrypting string data."""
        encryptor = SimpleSymmetricEncryption()
        plaintext = "Hello, World!"
        
        encrypted = encryptor.encrypt(plaintext)
        decrypted = encryptor.decrypt(encrypted)
        
        assert decrypted.decode('utf-8') == plaintext

    def test_simple_encrypt_decrypt_bytes(self):
        """Test encrypting and decrypting bytes data."""
        encryptor = SimpleSymmetricEncryption()
        plaintext = b"Hello, World!"
        
        encrypted = encryptor.encrypt(plaintext)
        decrypted = encryptor.decrypt(encrypted)
        
        assert decrypted == plaintext

    def test_simple_encrypt_decrypt_string_methods(self):
        """Test encrypt_string and decrypt_string methods."""
        encryptor = SimpleSymmetricEncryption()
        plaintext = "Hello, World!"
        
        encrypted_string = encryptor.encrypt_string(plaintext)
        decrypted_string = encryptor.decrypt_string(encrypted_string)
        
        assert decrypted_string == plaintext
        assert isinstance(encrypted_string, str)

    def test_simple_encryption_different_plaintexts(self):
        """Test encryption produces different ciphertexts for same plaintext."""
        encryptor = SimpleSymmetricEncryption()
        plaintext = "Hello, World!"
        
        encrypted1 = encryptor.encrypt(plaintext)
        encrypted2 = encryptor.encrypt(plaintext)
        
        # Should be different due to random IV
        assert encrypted1 != encrypted2
        
        # But should decrypt to the same plaintext
        assert encryptor.decrypt(encrypted1).decode('utf-8') == plaintext
        assert encryptor.decrypt(encrypted2).decode('utf-8') == plaintext

    def test_simple_decryption_with_invalid_length(self):
        """Test decryption with invalid ciphertext length."""
        encryptor = SimpleSymmetricEncryption()
        short_ciphertext = b"too_short"
        
        with pytest.raises(ValueError, match="Invalid ciphertext length"):
            encryptor.decrypt(short_ciphertext)

    def test_simple_decryption_with_invalid_hmac(self):
        """Test decryption with invalid HMAC."""
        encryptor = SimpleSymmetricEncryption()
        
        # Create a ciphertext with correct length but invalid HMAC
        iv = os.urandom(16)
        fake_mac = os.urandom(32)
        encrypted_data = b"some_encrypted_data"
        invalid_ciphertext = iv + fake_mac + encrypted_data
        
        with pytest.raises(ValueError, match="HMAC verification failed"):
            encryptor.decrypt(invalid_ciphertext)

    def test_simple_encryption_empty_string(self):
        """Test encrypting and decrypting empty string."""
        encryptor = SimpleSymmetricEncryption()
        plaintext = ""
        
        encrypted = encryptor.encrypt(plaintext)
        decrypted = encryptor.decrypt(encrypted)
        
        assert decrypted.decode('utf-8') == plaintext

    def test_simple_encryption_large_data(self):
        """Test encrypting and decrypting large data."""
        encryptor = SimpleSymmetricEncryption()
        plaintext = "A" * 10000  # 10KB of data
        
        encrypted = encryptor.encrypt(plaintext)
        decrypted = encryptor.decrypt(encrypted)
        
        assert decrypted.decode('utf-8') == plaintext

    @pytest.mark.parametrize("data", [
        "Simple text",
        "Text with special chars: !@#$%^&*()",
        "Unicode text: 你好世界",
        "Emoji test: 😀🎉🔐",
        "Numbers: 1234567890",
        ""
    ])
    def test_simple_encryption_various_inputs(self, data):
        """Test encryption with various input types."""
        encryptor = SimpleSymmetricEncryption()
        
        encrypted = encryptor.encrypt_string(data)
        decrypted = encryptor.decrypt_string(encrypted)
        
        assert decrypted == data


class TestPasswordHashing:
    """Test suite for password hashing functions."""

    def test_hash_password_with_auto_salt(self):
        """Test password hashing with automatically generated salt."""
        password = "test_password"
        hashed, salt = hash_password(password)
        
        assert isinstance(hashed, str)
        assert isinstance(salt, str)
        assert len(base64.b64decode(hashed.encode('utf-8'))) == 32  # SHA256 output
        assert len(base64.b64decode(salt.encode('utf-8'))) == 16  # Salt length

    def test_hash_password_with_provided_salt(self):
        """Test password hashing with provided salt."""
        password = "test_password"
        salt = base64.b64encode(os.urandom(16)).decode('utf-8')
        hashed, returned_salt = hash_password(password, salt)
        
        assert returned_salt == salt
        assert isinstance(hashed, str)

    def test_hash_password_with_bytes_salt(self):
        """Test password hashing with bytes salt (internal handling)."""
        password = "test_password"
        salt_bytes = os.urandom(16)
        # Convert bytes to string as expected by the function signature
        salt_string = base64.b64encode(salt_bytes).decode('utf-8')
        hashed, returned_salt = hash_password(password, salt_string)
        
        assert returned_salt == salt_string
        assert isinstance(hashed, str)

    def test_hash_password_consistency(self):
        """Test password hashing consistency with same salt."""
        password = "test_password"
        salt = base64.b64encode(os.urandom(16)).decode('utf-8')
        
        hashed1, _ = hash_password(password, salt)
        hashed2, _ = hash_password(password, salt)
        
        assert hashed1 == hashed2

    def test_hash_password_different_salts(self):
        """Test password hashing produces different results with different salts."""
        password = "test_password"
        
        hashed1, salt1 = hash_password(password)
        hashed2, salt2 = hash_password(password)
        
        assert salt1 != salt2
        assert hashed1 != hashed2

    def test_verify_password_correct(self):
        """Test password verification with correct password."""
        password = "test_password"
        hashed, salt = hash_password(password)
        
        assert verify_password(password, hashed, salt) is True

    def test_verify_password_incorrect(self):
        """Test password verification with incorrect password."""
        password = "test_password"
        wrong_password = "wrong_password"
        hashed, salt = hash_password(password)
        
        assert verify_password(wrong_password, hashed, salt) is False

    def test_verify_password_with_invalid_salt(self):
        """Test password verification with invalid salt."""
        password = "test_password"
        hashed, _ = hash_password(password)
        invalid_salt = "invalid_salt"
        
        assert verify_password(password, hashed, invalid_salt) is False

    def test_verify_password_with_invalid_hash(self):
        """Test password verification with invalid hash."""
        password = "test_password"
        _, salt = hash_password(password)
        invalid_hash = "invalid_hash"
        
        assert verify_password(password, invalid_hash, salt) is False

    @pytest.mark.parametrize("password", [
        "simple",
        "with spaces",
        "with!@#$%special^&*()chars",
        "Unicode密码测试",
        "🔐🛡️💻",
        "very_long_password_that_exceeds_typical_length_expectations_and_includes_various_characters_123456789",
        ""  # Empty password
    ])
    def test_password_hashing_various_inputs(self, password):
        """Test password hashing with various input types."""
        hashed, salt = hash_password(password)
        assert verify_password(password, hashed, salt) is True

    @patch('src.main.app.libs.utils.security_util.HAS_CRYPTOGRAPHY', False)
    def test_hash_password_without_cryptography(self):
        """Test password hashing fallback without cryptography package."""
        password = "test_password"
        hashed, salt = hash_password(password)
        
        assert verify_password(password, hashed, salt) is True


class TestSymmetricEncryption:
    """Test suite for SymmetricEncryption class (requires cryptography)."""

    @pytest.mark.skipif(not HAS_CRYPTOGRAPHY, reason="cryptography package not available")
    def test_symmetric_encryption_init(self):
        """Test SymmetricEncryption initialization."""
        encryptor = SymmetricEncryption()
        assert encryptor._key is not None
        assert len(encryptor._key) == 44  # Fernet key length (base64 encoded)

    @pytest.mark.skipif(not HAS_CRYPTOGRAPHY, reason="cryptography package not available")
    def test_symmetric_encryption_with_provided_key(self):
        """Test SymmetricEncryption with provided key."""
        from cryptography.fernet import Fernet
        key = Fernet.generate_key()
        encryptor = SymmetricEncryption(key)
        assert encryptor._key == key

    @pytest.mark.skipif(not HAS_CRYPTOGRAPHY, reason="cryptography package not available")
    def test_symmetric_encrypt_decrypt(self):
        """Test symmetric encryption and decryption."""
        encryptor = SymmetricEncryption()
        plaintext = "Hello, World!"
        
        encrypted = encryptor.encrypt(plaintext)
        decrypted = encryptor.decrypt(encrypted)
        
        assert decrypted.decode('utf-8') == plaintext

    @pytest.mark.skipif(not HAS_CRYPTOGRAPHY, reason="cryptography package not available")
    def test_symmetric_encrypt_decrypt_string_methods(self):
        """Test symmetric encryption string methods."""
        encryptor = SymmetricEncryption()
        plaintext = "Hello, World!"
        
        encrypted_string = encryptor.encrypt_string(plaintext)
        decrypted_string = encryptor.decrypt_string(encrypted_string)
        
        assert decrypted_string == plaintext

    def test_symmetric_encryption_without_cryptography(self):
        """Test SymmetricEncryption raises ImportError without cryptography."""
        with patch('src.main.app.libs.utils.security_util.HAS_CRYPTOGRAPHY', False):
            with pytest.raises(ImportError, match="cryptography package is required"):
                SymmetricEncryption()

    @pytest.mark.skipif(not HAS_CRYPTOGRAPHY, reason="cryptography package not available")
    def test_symmetric_encryption_from_password(self):
        """Test creating SymmetricEncryption from password."""
        password = "test_password"
        encryptor = SymmetricEncryption.from_password(password)
        
        plaintext = "Hello, World!"
        encrypted = encryptor.encrypt_string(plaintext)
        decrypted = encryptor.decrypt_string(encrypted)
        
        assert decrypted == plaintext


class TestRSASigner:
    """Test suite for RSASigner class (requires cryptography)."""

    def test_rsa_signer_without_cryptography(self):
        """Test RSASigner raises ImportError without cryptography."""
        with patch('src.main.app.libs.utils.security_util.HAS_CRYPTOGRAPHY', False):
            with pytest.raises(ImportError, match="cryptography package is required"):
                RSASigner()

    @pytest.mark.skipif(not HAS_CRYPTOGRAPHY, reason="cryptography package not available")
    def test_rsa_generate_keypair(self):
        """Test RSA keypair generation."""
        private_pem, public_pem = RSASigner.generate_keypair()
        
        assert isinstance(private_pem, bytes)
        assert isinstance(public_pem, bytes)
        assert b'-----BEGIN PRIVATE KEY-----' in private_pem
        assert b'-----BEGIN PUBLIC KEY-----' in public_pem

    @pytest.mark.skipif(not HAS_CRYPTOGRAPHY, reason="cryptography package not available")
    def test_rsa_sign_and_verify(self):
        """Test RSA signing and verification."""
        private_pem, public_pem = RSASigner.generate_keypair()
        signer = RSASigner(private_pem, public_pem)
        
        message = "Hello, World!"
        signature = signer.sign(message)
        
        assert isinstance(signature, str)
        assert signer.verify(message, signature) is True

    @pytest.mark.skipif(not HAS_CRYPTOGRAPHY, reason="cryptography package not available")
    def test_rsa_verify_invalid_signature(self):
        """Test RSA verification with invalid signature."""
        private_pem, public_pem = RSASigner.generate_keypair()
        signer = RSASigner(private_pem, public_pem)
        
        message = "Hello, World!"
        invalid_signature = "invalid_signature"
        
        assert signer.verify(message, invalid_signature) is False

    @pytest.mark.skipif(not HAS_CRYPTOGRAPHY, reason="cryptography package not available")
    def test_rsa_sign_without_private_key(self):
        """Test RSA signing without private key raises ValueError."""
        _, public_pem = RSASigner.generate_keypair()
        signer = RSASigner(public_key=public_pem)
        
        with pytest.raises(ValueError, match="Private key required for signing"):
            signer.sign("message")

    @pytest.mark.skipif(not HAS_CRYPTOGRAPHY, reason="cryptography package not available")
    def test_rsa_verify_without_public_key(self):
        """Test RSA verification without public key returns False."""
        private_pem, _ = RSASigner.generate_keypair()
        signer = RSASigner(private_key=private_pem)
        
        assert signer.verify("message", "signature") is False


class TestUtilityFunctions:
    """Test suite for utility functions."""

    def test_generate_random_key_default_length(self):
        """Test generating random key with default length."""
        key = generate_random_key()
        
        assert isinstance(key, str)
        decoded = base64.b64decode(key.encode('utf-8'))
        assert len(decoded) == 32  # Default length

    def test_generate_random_key_custom_length(self):
        """Test generating random key with custom length."""
        length = 16
        key = generate_random_key(length)
        
        decoded = base64.b64decode(key.encode('utf-8'))
        assert len(decoded) == length

    def test_generate_random_key_uniqueness(self):
        """Test that generated keys are unique."""
        key1 = generate_random_key()
        key2 = generate_random_key()
        
        assert key1 != key2

    def test_create_symmetric_encryption_with_cryptography(self):
        """Test create_symmetric_encryption when cryptography is available."""
        with patch('src.main.app.libs.utils.security_util.HAS_CRYPTOGRAPHY', True):
            with patch('src.main.app.libs.utils.security_util.SymmetricEncryption') as mock_sym:
                mock_instance = MagicMock()
                mock_sym.return_value = mock_instance
                
                result = create_symmetric_encryption()
                
                assert result == mock_instance
                mock_sym.assert_called_once_with(None)

    def test_create_symmetric_encryption_without_cryptography(self):
        """Test create_symmetric_encryption falls back to SimpleSymmetricEncryption."""
        with patch('src.main.app.libs.utils.security_util.HAS_CRYPTOGRAPHY', False):
            encryptor = create_symmetric_encryption()
            assert isinstance(encryptor, SimpleSymmetricEncryption)

    def test_encrypt_decrypt_data_functions(self):
        """Test encrypt_data and decrypt_data utility functions."""
        plaintext = "Hello, World!"
        
        encrypted, key = encrypt_data(plaintext)
        decrypted = decrypt_data(encrypted, key)
        
        assert decrypted.decode('utf-8') == plaintext
        assert isinstance(key, bytes)

    def test_encrypt_decrypt_data_with_provided_key(self):
        """Test encrypt_data and decrypt_data with provided key."""
        plaintext = b"Hello, World!"
        # For SymmetricEncryption, we need a proper Fernet key if cryptography is available
        if HAS_CRYPTOGRAPHY:
            from cryptography.fernet import Fernet
            key = Fernet.generate_key()
        else:
            key = os.urandom(32)
        
        encrypted, returned_key = encrypt_data(plaintext, key)
        decrypted = decrypt_data(encrypted, returned_key)
        
        assert decrypted == plaintext
        assert returned_key == key

    @pytest.mark.parametrize("length", [8, 16, 32, 64, 128])
    def test_generate_random_key_various_lengths(self, length):
        """Test generating random keys with various lengths."""
        key = generate_random_key(length)
        decoded = base64.b64decode(key.encode('utf-8'))
        assert len(decoded) == length


class TestEdgeCases:
    """Test suite for edge cases and error conditions."""

    def test_hmac_signer_with_empty_key(self):
        """Test HMACSigner with empty key."""
        signer = HMACSigner("")
        message = "test"
        signature = signer.sign(message)
        
        # Should still work, just with empty key
        assert signer.verify(message, signature) is True

    def test_simple_encryption_with_empty_key(self):
        """Test SimpleSymmetricEncryption with empty key."""
        encryptor = SimpleSymmetricEncryption(b"")
        # Key should be padded to 32 bytes with null bytes
        assert len(encryptor._key) == 32
        assert encryptor._key == b"\x00" * 32

    def test_password_hashing_edge_cases(self):
        """Test password hashing with edge case inputs."""
        # Empty password
        hashed, salt = hash_password("")
        assert verify_password("", hashed, salt) is True
        
        # Very long password
        long_password = "A" * 10000
        hashed, salt = hash_password(long_password)
        assert verify_password(long_password, hashed, salt) is True

    def test_base64_decoding_errors(self):
        """Test handling of base64 decoding errors."""
        signer = HMACSigner("key")
        
        # Invalid base64 in verify
        assert signer.verify("message", "not_base64!@#") is False
        
        # Invalid base64 in password verification
        assert verify_password("password", "not_base64", "valid_salt") is False

    def test_memory_efficiency_large_data(self):
        """Test memory efficiency with large data."""
        encryptor = SimpleSymmetricEncryption()
        
        # Test with 1MB of data
        large_data = "A" * (1024 * 1024)
        encrypted = encryptor.encrypt_string(large_data)
        decrypted = encryptor.decrypt_string(encrypted)
        
        assert decrypted == large_data

    def test_concurrent_access_safety(self):
        """Test that encryption objects are safe for concurrent access."""
        import threading
        
        encryptor = SimpleSymmetricEncryption()
        results = []
        
        def encrypt_decrypt_task(data):
            encrypted = encryptor.encrypt_string(data)
            decrypted = encryptor.decrypt_string(encrypted)
            results.append(decrypted == data)
        
        threads = []
        for i in range(10):
            thread = threading.Thread(target=encrypt_decrypt_task, args=(f"data_{i}",))
            threads.append(thread)
            thread.start()
        
        for thread in threads:
            thread.join()
        
        assert all(results)  # All operations should succeed