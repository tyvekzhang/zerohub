# SPDX-License-Identifier: MIT
"""Comprehensive unit tests for probe controller."""

from unittest.mock import Mock, patch

import pytest
from fastapi import APIRouter
from fastapi.testclient import TestClient

from src.main.app.controller.probe_controller import liveness, probe_router
from src.main.app.libs.schema.response import HttpResponse


class TestProbeController:
    """Test suite for probe controller endpoints."""

    def test_probe_router_is_api_router(self):
        """Test that probe_router is an APIRouter instance."""
        assert isinstance(probe_router, APIRouter)

    def test_probe_router_has_routes(self):
        """Test that probe_router has the expected routes."""
        routes = probe_router.routes
        assert len(routes) > 0

        # Check that liveness route exists
        liveness_route = next(
            (
                route
                for route in routes
                if hasattr(route, "path") and route.path == "/liveness"
            ),
            None,
        )
        assert liveness_route is not None
        assert "GET" in liveness_route.methods

    @pytest.mark.asyncio
    async def test_liveness_endpoint_success(self):
        """Test the liveness endpoint returns success response."""
        response = await liveness()

        assert isinstance(response, HttpResponse)
        assert response.code == 0  # Default success code
        assert response.message == "Hi"
        assert response.data is None

    @pytest.mark.asyncio
    async def test_liveness_endpoint_response_structure(self):
        """Test that liveness endpoint returns properly structured response."""
        response = await liveness()

        # Test response attributes
        assert hasattr(response, "code")
        assert hasattr(response, "message")
        assert hasattr(response, "data")

        # Test serialization
        serialized = response.serialize_model()
        assert "code" in serialized
        assert "message" in serialized
        assert serialized["code"] == 0
        assert serialized["message"] == "Hi"

    def test_liveness_function_signature(self):
        """Test that liveness function has correct signature."""
        import inspect

        sig = inspect.signature(liveness)

        # Should have no parameters
        assert len(sig.parameters) == 0

        # Should be async
        assert inspect.iscoroutinefunction(liveness)

        # Check return annotation
        return_annotation = sig.return_annotation
        assert return_annotation is not None


class TestProbeControllerIntegration:
    """Integration tests for probe controller with FastAPI."""

    @pytest.fixture
    def test_app(self):
        """Create a test FastAPI app with probe router."""
        from fastapi import FastAPI

        app = FastAPI()
        app.include_router(probe_router)
        return app

    @pytest.fixture
    def client(self, test_app):
        """Create a test client."""
        return TestClient(test_app)

    def test_liveness_endpoint_via_client(self, client):
        """Test liveness endpoint through FastAPI test client."""
        response = client.get("/liveness")

        assert response.status_code == 200

        data = response.json()
        assert data["code"] == 0
        assert data["message"] == "Hi"
        assert "data" not in data  # Should be excluded when None

    def test_liveness_endpoint_response_headers(self, client):
        """Test that liveness endpoint returns correct headers."""
        response = client.get("/liveness")

        assert response.status_code == 200
        assert response.headers["content-type"] == "application/json"

    def test_liveness_endpoint_method_not_allowed(self, client):
        """Test that non-GET methods are not allowed for liveness endpoint."""
        # Test POST method
        response = client.post("/liveness")
        assert response.status_code == 405  # Method Not Allowed

        # Test PUT method
        response = client.put("/liveness")
        assert response.status_code == 405

        # Test DELETE method
        response = client.delete("/liveness")
        assert response.status_code == 405

    def test_liveness_endpoint_with_query_parameters(self, client):
        """Test liveness endpoint with query parameters (should still work)."""
        response = client.get("/liveness?param=value")

        assert response.status_code == 200
        data = response.json()
        assert data["code"] == 0
        assert data["message"] == "Hi"

    def test_liveness_endpoint_multiple_requests(self, client):
        """Test multiple consecutive requests to liveness endpoint."""
        for i in range(5):
            response = client.get("/liveness")

            assert response.status_code == 200
            data = response.json()
            assert data["code"] == 0
            assert data["message"] == "Hi"


class TestProbeControllerErrorScenarios:
    """Test error scenarios for probe controller."""

    @pytest.mark.asyncio
    async def test_liveness_with_mocked_response_creation_error(self):
        """Test liveness behavior when HttpResponse.success fails."""
        with patch(
            "src.main.app.controller.probe_controller.HttpResponse.success"
        ) as mock_success:
            mock_success.side_effect = Exception("Response creation failed")

            with pytest.raises(Exception, match="Response creation failed"):
                await liveness()

    @pytest.mark.asyncio
    async def test_liveness_with_mocked_response_success(self):
        """Test liveness with mocked HttpResponse.success."""
        mock_response = Mock(spec=HttpResponse)
        mock_response.code = 0
        mock_response.message = "Mocked Hi"
        mock_response.data = None

        with patch(
            "src.main.app.controller.probe_controller.HttpResponse.success",
            return_value=mock_response,
        ):
            response = await liveness()

            assert response is mock_response
            assert response.message == "Mocked Hi"

    def test_probe_router_configuration(self):
        """Test probe router configuration and setup."""
        # Test router attributes
        assert hasattr(probe_router, "routes")
        assert hasattr(probe_router, "prefix")
        assert hasattr(probe_router, "tags")

        # Test that router can be included in an app
        from fastapi import FastAPI

        app = FastAPI()

        # Should not raise an exception
        app.include_router(probe_router)

        # Check that routes were added
        app_routes = [route for route in app.routes if hasattr(route, "path")]
        liveness_routes = [route for route in app_routes if route.path == "/liveness"]
        assert len(liveness_routes) > 0


class TestProbeControllerDocumentation:
    """Test documentation and metadata for probe controller."""

    def test_liveness_function_docstring(self):
        """Test that liveness function has proper docstring."""
        docstring = liveness.__doc__

        assert docstring is not None
        assert "Check if the system is alive" in docstring
        assert "Returns:" in docstring
        assert "HttpResponse[str]" in docstring

    def test_module_docstring(self):
        """Test that probe_controller module has docstring."""
        import src.main.app.controller.probe_controller as probe_module

        docstring = probe_module.__doc__
        assert docstring is not None
        assert "Project health probe" in docstring

    def test_liveness_endpoint_openapi_metadata(self):
        """Test OpenAPI metadata for liveness endpoint."""
        from fastapi import FastAPI

        app = FastAPI()
        app.include_router(probe_router)

        openapi_schema = app.openapi()

        # Check that liveness endpoint is documented
        assert "/liveness" in openapi_schema["paths"]
        liveness_spec = openapi_schema["paths"]["/liveness"]

        assert "get" in liveness_spec
        get_spec = liveness_spec["get"]

        # Check summary/description
        assert "summary" in get_spec or "description" in get_spec

        # Check response schema
        assert "responses" in get_spec
        assert "200" in get_spec["responses"]


class TestProbeControllerPerformance:
    """Performance and load-related tests for probe controller."""

    @pytest.mark.asyncio
    async def test_liveness_response_time(self):
        """Test that liveness endpoint responds quickly."""
        import time

        start_time = time.time()
        response = await liveness()
        end_time = time.time()

        response_time = end_time - start_time

        # Should respond within 100ms (very generous for a simple endpoint)
        assert response_time < 0.1
        assert isinstance(response, HttpResponse)

    @pytest.mark.asyncio
    async def test_liveness_concurrent_requests(self):
        """Test liveness endpoint under concurrent load."""
        import asyncio

        async def single_request():
            return await liveness()

        # Run 10 concurrent requests
        tasks = [single_request() for _ in range(10)]
        responses = await asyncio.gather(*tasks)

        # All should succeed
        assert len(responses) == 10
        for response in responses:
            assert isinstance(response, HttpResponse)
            assert response.code == 0
            assert response.message == "Hi"

    def test_liveness_endpoint_scalability(self):
        """Test liveness endpoint with test client under load."""
        from fastapi import FastAPI

        app = FastAPI()
        app.include_router(probe_router)
        client = TestClient(app)

        # Make multiple requests
        responses = []
        for i in range(100):
            response = client.get("/liveness")
            responses.append(response)

        # All should succeed
        assert len(responses) == 100
        for response in responses:
            assert response.status_code == 200
            data = response.json()
            assert data["code"] == 0


class TestProbeControllerCompatibility:
    """Test compatibility with different FastAPI configurations."""

    def test_probe_router_with_prefix(self):
        """Test probe router with API prefix."""
        from fastapi import FastAPI

        app = FastAPI()
        app.include_router(probe_router, prefix="/api/v1")
        client = TestClient(app)

        response = client.get("/api/v1/liveness")

        assert response.status_code == 200
        data = response.json()
        assert data["code"] == 0
        assert data["message"] == "Hi"

    def test_probe_router_with_tags(self):
        """Test probe router with tags."""
        from fastapi import FastAPI

        app = FastAPI()
        app.include_router(probe_router, tags=["health"])

        openapi_schema = app.openapi()
        liveness_spec = openapi_schema["paths"]["/liveness"]["get"]

        # Tags should be inherited
        assert "tags" in liveness_spec
        assert "health" in liveness_spec["tags"]

    def test_probe_router_with_dependencies(self):
        """Test probe router with dependencies."""
        from fastapi import Depends, FastAPI

        def common_dependency():
            return {"dependency": "injected"}

        app = FastAPI()
        app.include_router(probe_router, dependencies=[Depends(common_dependency)])
        client = TestClient(app)

        # Should still work with dependencies
        response = client.get("/liveness")
        assert response.status_code == 200

    def test_probe_router_multiple_inclusions(self):
        """Test that probe router can be included multiple times with different prefixes."""
        from fastapi import FastAPI

        app = FastAPI()
        app.include_router(probe_router, prefix="/health")
        app.include_router(probe_router, prefix="/status")
        client = TestClient(app)

        # Both should work
        response1 = client.get("/health/liveness")
        assert response1.status_code == 200

        response2 = client.get("/status/liveness")
        assert response2.status_code == 200
