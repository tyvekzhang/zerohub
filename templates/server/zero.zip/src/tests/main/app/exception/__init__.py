# SPDX-License-Identifier: MIT
"""Exception module tests."""
