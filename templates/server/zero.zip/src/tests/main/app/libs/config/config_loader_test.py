# SPDX-License-Identifier: MIT
"""Comprehensive unit tests for ConfigLoader class."""

import os
import tempfile
from unittest.mock import patch

import pytest
import yaml

from src.main.app.libs.config.config_loader import ConfigLoader


class TestConfigLoader:
    """Test cases for ConfigLoader class."""

    def setup_method(self):
        """Set up test fixtures before each test method."""
        self.test_config_data = {
            "server": {
                "name": "test-server",
                "host": "127.0.0.1",
                "port": 8080,
                "debug": True,
            },
            "database": {"url": "sqlite:///test.db", "pool_size": 5},
        }

        self.env_config_data = {
            "server": {
                "port": 9000, # Override port
                "workers": 4, # Add new field
            },
            "security": {
                "enable": True  # Add new section
            },
        }

    def test_init_with_default_config_file(self):
        """Test initialization with default config file path."""
        loader = ConfigLoader("dev")

        assert loader.env == "dev"
        assert loader.default_flag is True
        assert "config.yml" in loader.base_config_file

    def test_init_with_custom_config_file(self):
        """Test initialization with custom config file path."""
        custom_path = "/custom/path/config.yml"
        loader = ConfigLoader("prod", custom_path)

        assert loader.env == "prod"
        assert loader.base_config_file == custom_path
        # default_flag should be set to False when custom config file is provided
        assert hasattr(loader, "default_flag")
        assert loader.default_flag is False

    def test_load_yaml_file_success(self):
        """Test successful YAML file loading."""
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".yml", delete=False
        ) as temp_file:
            yaml.dump(self.test_config_data, temp_file)
            temp_file_path = temp_file.name

        try:
            result = ConfigLoader.load_yaml_file(temp_file_path)
            assert result == self.test_config_data
        finally:
            os.unlink(temp_file_path)

    def test_load_yaml_file_nonexistent(self):
        """Test loading non-existent YAML file raises FileNotFoundError."""
        with pytest.raises(FileNotFoundError):
            ConfigLoader.load_yaml_file("/nonexistent/file.yml")

    def test_load_yaml_file_invalid_yaml(self):
        """Test loading invalid YAML file raises yaml.YAMLError."""
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".yml", delete=False
        ) as temp_file:
            temp_file.write("invalid: yaml: content: [unclosed")
            temp_file_path = temp_file.name

        try:
            with pytest.raises(yaml.YAMLError):
                ConfigLoader.load_yaml_file(temp_file_path)
        finally:
            os.unlink(temp_file_path)

    def test_load_yaml_file_empty_file(self):
        """Test loading empty YAML file returns None."""
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".yml", delete=False
        ) as temp_file:
            # Write empty content
            temp_file.write("")
            temp_file_path = temp_file.name

        try:
            result = ConfigLoader.load_yaml_file(temp_file_path)
            assert result is None
        finally:
            os.unlink(temp_file_path)

    def test_merge_dicts_simple(self):
        """Test merging simple dictionaries."""
        loader = ConfigLoader("dev")

        base = {"a": 1, "b": 2}
        override = {"b": 3, "c": 4}

        result = loader.merge_dicts(base, override)

        expected = {"a": 1, "b": 3, "c": 4}
        assert result == expected

    def test_merge_dicts_nested(self):
        """Test merging nested dictionaries."""
        loader = ConfigLoader("dev")

        base = {
            "server": {"host": "127.0.0.1", "port": 8080, "debug": False},
            "database": {"url": "sqlite:///base.db"},
        }

        override = {"server": {"port": 9000, "workers": 4}, "cache": {"enabled": True}}

        result = loader.merge_dicts(base, override)

        expected = {
            "server": {"host": "127.0.0.1", "port": 9000, "debug": False, "workers": 4},
            "database": {"url": "sqlite:///base.db"},
            "cache": {"enabled": True},
        }

        assert result == expected

    def test_merge_dicts_override_none(self):
        """Test merging with None override dictionary."""
        loader = ConfigLoader("dev")

        base = {"a": 1, "b": 2}
        result = loader.merge_dicts(base, None)

        assert result == base

    def test_merge_dicts_override_replace_dict_with_value(self):
        """Test merging where override replaces dict with simple value."""
        loader = ConfigLoader("dev")

        base = {"server": {"host": "127.0.0.1", "port": 8080}}

        override = {"server": "simple_value"}

        result = loader.merge_dicts(base, override)

        expected = {"server": "simple_value"}

        assert result == expected

    @patch("src.main.app.libs.config.config_loader.ConfigLoader.load_yaml_file")
    def test_load_config_base_only(self, mock_load_yaml):
        """Test loading config with base file only."""
        mock_load_yaml.return_value = self.test_config_data

        loader = ConfigLoader("dev", "/custom/config.yml")
        # When using custom config file, default_flag is not set
        result = loader.load_config()

        assert result == self.test_config_data
        mock_load_yaml.assert_called_once_with("/custom/config.yml")

    @patch("os.path.exists")
    @patch("src.main.app.libs.config.config_loader.ConfigLoader.load_yaml_file")
    def test_load_config_with_environment_override(self, mock_load_yaml, mock_exists):
        """Test loading config with environment-specific override."""
        # Setup mocks
        mock_exists.return_value = True
        mock_load_yaml.side_effect = [self.test_config_data, self.env_config_data]

        # Use default config file path to trigger environment override logic
        loader = ConfigLoader("dev")
        result = loader.load_config()

        # Verify both files were loaded
        assert mock_load_yaml.call_count == 2

        # Verify merged result
        expected = {
            "server": {
                "name": "test-server",
                "host": "127.0.0.1",
                "port": 9000, # Overridden
                "debug": True,
                "workers": 4, # Added
            },
            "database": {"url": "sqlite:///test.db", "pool_size": 5},
            "security": {
                "enable": True  # New section
            },
        }

        assert result == expected

    @patch("os.path.exists")
    @patch("src.main.app.libs.config.config_loader.ConfigLoader.load_yaml_file")
    def test_load_config_environment_file_not_exists(self, mock_load_yaml, mock_exists):
        """Test loading config when environment file doesn't exist."""
        # Setup mocks
        mock_exists.return_value = False
        mock_load_yaml.return_value = self.test_config_data

        loader = ConfigLoader("dev")
        result = loader.load_config()

        # Only base file should be loaded
        mock_load_yaml.assert_called_once()
        assert result == self.test_config_data

    @patch("os.path.exists")
    @patch("src.main.app.libs.config.config_loader.ConfigLoader.load_yaml_file")
    def test_load_config_with_custom_environment(self, mock_load_yaml, mock_exists):
        """Test loading config with custom environment parameter."""
        mock_exists.return_value = True
        mock_load_yaml.side_effect = [self.test_config_data, self.env_config_data]

        loader = ConfigLoader("dev")
        result = loader.load_config("prod")

        # Verify environment-specific file path is constructed correctly
        base_call = mock_load_yaml.call_args_list[0][0][0]
        env_call = mock_load_yaml.call_args_list[1][0][0]

        assert "config.yml" in base_call
        assert "config-prod.yml" in env_call

    def test_load_config_real_files(self):
        """Test loading config with real temporary files."""
        # Create temporary directory
        with tempfile.TemporaryDirectory() as temp_dir:
            # Create base config file
            base_config_path = os.path.join(temp_dir, "config.yml")
            with open(base_config_path, "w") as f:
                yaml.dump(self.test_config_data, f)

            # Create environment config file
            env_config_path = os.path.join(temp_dir, "config-dev.yml")
            with open(env_config_path, "w") as f:
                yaml.dump(self.env_config_data, f)

            # Test with base config only
            loader = ConfigLoader("prod", base_config_path)
            result = loader.load_config()
            assert result == self.test_config_data

            # Test with environment override using default constructor
            with patch(
                "src.main.app.libs.config.config_loader.constant"
            ) as mock_constant:
                mock_constant.RESOURCE_DIR = temp_dir
                mock_constant.CONFIG_FILE_NAME = "config.yml"
                loader = ConfigLoader(
                    "dev"
                )  # Use default constructor to set default_flag
                result = loader.load_config()

            # Verify merged result
            assert result["server"]["port"] == 9000  # Overridden
            assert result["server"]["name"] == "test-server"  # Original
            assert result["security"]["enable"] is True  # New section

    @patch("src.main.app.libs.config.config_loader.ConfigLoader.load_yaml_file")
    def test_load_config_yaml_error_handling(self, mock_load_yaml):
        """Test config loading with YAML parsing errors."""
        mock_load_yaml.side_effect = yaml.YAMLError("Invalid YAML")

        loader = ConfigLoader("dev")

        with pytest.raises(yaml.YAMLError):
            loader.load_config()

    def test_environment_config_path_construction(self):
        """Test environment-specific config file path construction."""
        with tempfile.TemporaryDirectory() as temp_dir:
            base_config_path = os.path.join(temp_dir, "config.yml")

            # Create base config file
            with open(base_config_path, "w") as f:
                yaml.dump(self.test_config_data, f)

            loader = ConfigLoader("production", base_config_path)
            loader.default_flag = True

            # Mock os.path.exists to return False for env file
            with patch("os.path.exists", return_value=False):
                result = loader.load_config()

            # Should load only base config since env file doesn't exist
            assert result == self.test_config_data

    def test_config_loader_instance_variables(self):
        """Test that ConfigLoader properly initializes instance variables."""
        loader = ConfigLoader("test_env", "/test/path")

        assert loader.env == "test_env"
        assert loader.base_config_file == "/test/path"
        assert loader.config == {}

    @patch("src.main.app.libs.config.config_loader.constant")
    def test_load_config_with_constant_integration(self, mock_constant):
        """Test config loading with constant module integration."""
        mock_constant.RESOURCE_DIR = "/test/resource"
        mock_constant.CONFIG_FILE_NAME = "app.yml"

        loader = ConfigLoader("dev")

        # Verify the base config file path is constructed using constants
        # On Windows, path separators might be different
        expected_components = ["/test/resource", "app.yml"]
        for component in expected_components:
            assert (
                component.replace("/", os.sep) in loader.base_config_file
                or component in loader.base_config_file
            )

    def test_complex_nested_merge(self):
        """Test complex nested dictionary merging scenarios."""
        loader = ConfigLoader("dev")

        base = {
            "level1": {
                "level2": {
                    "level3": {"keep": "original", "override": "old_value"},
                    "keep_level2": "original",
                },
                "keep_level1": "original",
            },
            "keep_root": "original",
        }

        override = {
            "level1": {
                "level2": {
                    "level3": {"override": "new_value", "add": "new_field"},
                    "add_level2": "new_field",
                },
                "add_level1": "new_field",
            },
            "add_root": "new_field",
        }

        result = loader.merge_dicts(base, override)

        # Verify deep merging worked correctly
        assert result["level1"]["level2"]["level3"]["keep"] == "original"
        assert result["level1"]["level2"]["level3"]["override"] == "new_value"
        assert result["level1"]["level2"]["level3"]["add"] == "new_field"
        assert result["level1"]["level2"]["keep_level2"] == "original"
        assert result["level1"]["level2"]["add_level2"] == "new_field"
        assert result["level1"]["keep_level1"] == "original"
        assert result["level1"]["add_level1"] == "new_field"
        assert result["keep_root"] == "original"
        assert result["add_root"] == "new_field"

    def test_load_config_multiple_calls(self):
        """Test that multiple calls to load_config work correctly."""
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".yml", delete=False
        ) as temp_file:
            yaml.dump(self.test_config_data, temp_file)
            temp_file_path = temp_file.name

        try:
            loader = ConfigLoader("dev", temp_file_path)

            result1 = loader.load_config()
            result2 = loader.load_config()

            # Both calls should return the same result
            assert result1 == result2
            assert result1 == self.test_config_data

            # Instance config should be updated
            assert loader.config == self.test_config_data

        finally:
            os.unlink(temp_file_path)
