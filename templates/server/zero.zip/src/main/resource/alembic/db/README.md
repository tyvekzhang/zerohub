fix empty dir auto delete issue
