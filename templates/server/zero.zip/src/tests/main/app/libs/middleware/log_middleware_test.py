# SPDX-License-Identifier: MIT
"""Comprehensive unit tests for log_middleware module."""

from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from fastapi import Request, Response

from src.main.app.libs.middleware.log_middleware import log_requests


class TestLogRequestsMiddleware:
    """Test cases for log_requests middleware."""

    def setup_method(self):
        """Set up test fixtures before each test method."""
        self.mock_request = MagicMock(spec=Request)
        self.mock_call_next = AsyncMock()
        self.mock_response = MagicMock(spec=Response)
        self.mock_response.status_code = 200
        self.mock_response.headers = {}

    @pytest.mark.asyncio
    async def test_log_requests_successful_request(self):
        """Test log_requests middleware with successful request."""
        # Setup request mock
        self.mock_request.method = "GET"
        self.mock_request.url = MagicMock()
        self.mock_request.url.path = "/api/v1/users"
        self.mock_request.client = MagicMock()
        self.mock_request.client.host = "192.168.1.100"
        self.mock_request.headers = {"user-agent": "Test-Agent/1.0"}
        self.mock_request.state = MagicMock()

        # Setup response mock
        self.mock_call_next.return_value = self.mock_response

        with patch("src.main.app.libs.middleware.log_middleware.logger") as mock_logger:
            with patch(
                "src.main.app.libs.middleware.log_middleware.uuid.uuid4"
            ) as mock_uuid:
                mock_uuid.return_value = MagicMock()
                mock_uuid.return_value.__str__ = MagicMock(
                    return_value="test-request-id-123"
                )

                # Call middleware
                result = await log_requests(self.mock_request, self.mock_call_next)

                # Verify response is returned
                assert result == self.mock_response

                # Verify request ID is set
                assert hasattr(self.mock_request.state, "request_id")

                # Verify request ID is added to response headers
                assert "X-Request-ID" in self.mock_response.headers
                assert (
                    self.mock_response.headers["X-Request-ID"] == "test-request-id-123"
                )

                # Verify logging calls
                assert mock_logger.info.call_count == 2

                # Check request started log
                start_log_call = mock_logger.info.call_args_list[0]
                assert "Request started" in str(start_log_call)
                assert "GET /api/v1/users" in str(start_log_call)
                assert "test-request-id-123" in str(start_log_call)
                assert "192.168.1.100" in str(start_log_call)
                assert "Test-Agent/1.0" in str(start_log_call)

                # Check request completed log
                completed_log_call = mock_logger.info.call_args_list[1]
                assert "Request completed" in str(completed_log_call)
                assert "Status: 200" in str(completed_log_call)
                assert "Time:" in str(completed_log_call)
                assert "ms" in str(completed_log_call)

    @pytest.mark.asyncio
    async def test_log_requests_with_exception(self):
        """Test log_requests middleware when downstream raises exception."""
        # Setup request mock
        self.mock_request.method = "POST"
        self.mock_request.url = MagicMock()
        self.mock_request.url.path = "/api/v1/auth"
        self.mock_request.client = MagicMock()
        self.mock_request.client.host = "10.0.0.1"
        self.mock_request.headers = {"user-agent": "TestClient/2.0"}
        self.mock_request.state = MagicMock()

        # Setup exception
        test_exception = ValueError("Test error occurred")
        self.mock_call_next.side_effect = test_exception

        with patch("src.main.app.libs.middleware.log_middleware.logger") as mock_logger:
            with patch(
                "src.main.app.libs.middleware.log_middleware.uuid.uuid4"
            ) as mock_uuid:
                mock_uuid.return_value = MagicMock()
                mock_uuid.return_value.__str__ = MagicMock(
                    return_value="error-request-id-456"
                )

                # Call middleware and expect exception
                with pytest.raises(ValueError, match="Test error occurred"):
                    await log_requests(self.mock_request, self.mock_call_next)

                # Verify request ID is set
                assert hasattr(self.mock_request.state, "request_id")

                # Verify logging calls
                mock_logger.info.assert_called_once()  # Only request started log
                mock_logger.error.assert_called_once()

                # Check request started log
                start_log_call = mock_logger.info.call_args_list[0]
                assert "Request started" in str(start_log_call)
                assert "POST /api/v1/auth" in str(start_log_call)

                # Check error log
                error_log_call = mock_logger.error.call_args_list[0]
                assert "Request failed" in str(error_log_call)
                assert "error-request-id-456" in str(error_log_call)
                assert "Test error occurred" in str(error_log_call)

                # Verify exc_info=True was passed
                _, kwargs = mock_logger.error.call_args
                assert kwargs.get("exc_info") is True

    @pytest.mark.asyncio
    async def test_log_requests_no_client_info(self):
        """Test log_requests middleware when client info is not available."""
        # Setup request mock without client
        self.mock_request.method = "DELETE"
        self.mock_request.url = MagicMock()
        self.mock_request.url.path = "/api/v1/items/123"
        self.mock_request.client = None
        self.mock_request.headers = {}
        self.mock_request.state = MagicMock()

        # Setup response mock
        self.mock_call_next.return_value = self.mock_response

        with patch("src.main.app.libs.middleware.log_middleware.logger") as mock_logger:
            with patch(
                "src.main.app.libs.middleware.log_middleware.uuid.uuid4"
            ) as mock_uuid:
                mock_uuid.return_value = MagicMock()
                mock_uuid.return_value.__str__ = MagicMock(
                    return_value="no-client-id-789"
                )

                # Call middleware
                result = await log_requests(self.mock_request, self.mock_call_next)

                # Verify response is returned
                assert result == self.mock_response

                # Verify logging calls
                assert mock_logger.info.call_count == 2

                # Check request started log handles None client
                start_log_call = mock_logger.info.call_args_list[0]
                assert "Request started" in str(start_log_call)
                assert "IP: None" in str(start_log_call)
                assert "UA: None" in str(start_log_call)

    @pytest.mark.asyncio
    async def test_log_requests_processing_time_calculation(self):
        """Test that processing time is correctly calculated and logged."""
        # Setup request mock
        self.mock_request.method = "PUT"
        self.mock_request.url = MagicMock()
        self.mock_request.url.path = "/api/v1/update"
        self.mock_request.client = MagicMock()
        self.mock_request.client.host = "127.0.0.1"
        self.mock_request.headers = {}
        self.mock_request.state = MagicMock()

        # Setup response mock
        self.mock_call_next.return_value = self.mock_response

        # Mock time to control processing time calculation
        with patch("src.main.app.libs.middleware.log_middleware.time") as mock_time:
            mock_time.time.side_effect = [1000.0, 1000.250]  # 250ms processing time

            with patch(
                "src.main.app.libs.middleware.log_middleware.logger"
            ) as mock_logger:
                with patch(
                    "src.main.app.libs.middleware.log_middleware.uuid.uuid4"
                ) as mock_uuid:
                    mock_uuid.return_value = MagicMock()
                    mock_uuid.return_value.__str__ = MagicMock(
                        return_value="timing-test-id"
                    )

                    # Call middleware
                    await log_requests(self.mock_request, self.mock_call_next)

                    # Check completed log for processing time
                    completed_log_call = mock_logger.info.call_args_list[1]
                    assert "Time: 250.0ms" in str(completed_log_call)

    @pytest.mark.asyncio
    async def test_log_requests_different_status_codes(self):
        """Test log_requests middleware with different HTTP status codes."""
        test_cases = [
            (200, "OK"),
            (201, "Created"),
            (400, "Bad Request"),
            (401, "Unauthorized"),
            (404, "Not Found"),
            (500, "Internal Server Error"),
        ]

        for status_code, description in test_cases:
            # Setup fresh mocks for each test case
            mock_request = MagicMock(spec=Request)
            mock_request.method = "GET"
            mock_request.url = MagicMock()
            mock_request.url.path = f"/api/v1/status/{status_code}"
            mock_request.client = MagicMock()
            mock_request.client.host = "192.168.1.1"
            mock_request.headers = {}
            mock_request.state = MagicMock()

            mock_response = MagicMock(spec=Response)
            mock_response.status_code = status_code
            mock_response.headers = {}

            mock_call_next = AsyncMock(return_value=mock_response)

            with patch(
                "src.main.app.libs.middleware.log_middleware.logger"
            ) as mock_logger:
                with patch(
                    "src.main.app.libs.middleware.log_middleware.uuid.uuid4"
                ) as mock_uuid:
                    mock_uuid.return_value = MagicMock()
                    mock_uuid.return_value.__str__ = MagicMock(
                        return_value=f"status-{status_code}-id"
                    )

                    # Call middleware
                    result = await log_requests(mock_request, mock_call_next)

                    # Verify response
                    assert result == mock_response

                    # Check completed log includes correct status code
                    completed_log_call = mock_logger.info.call_args_list[1]
                    assert f"Status: {status_code}" in str(completed_log_call)

    @pytest.mark.asyncio
    async def test_log_requests_uuid_generation(self):
        """Test that unique UUIDs are generated for each request."""
        # Setup request mock
        self.mock_request.method = "GET"
        self.mock_request.url = MagicMock()
        self.mock_request.url.path = "/api/v1/test"
        self.mock_request.client = None
        self.mock_request.headers = {}
        self.mock_request.state = MagicMock()

        # Setup response mock
        self.mock_call_next.return_value = self.mock_response

        with patch("src.main.app.libs.middleware.log_middleware.logger"):
            with patch(
                "src.main.app.libs.middleware.log_middleware.uuid.uuid4"
            ) as mock_uuid:
                # Call middleware multiple times
                for i in range(3):
                    mock_uuid.reset_mock()
                    mock_request_state = MagicMock()
                    self.mock_request.state = mock_request_state
                    self.mock_response.headers = {}

                    await log_requests(self.mock_request, self.mock_call_next)

                    # Verify uuid4 was called for each request
                    mock_uuid.assert_called_once()

    @pytest.mark.asyncio
    async def test_log_requests_header_modification(self):
        """Test that response headers are properly modified."""
        # Setup request mock
        self.mock_request.method = "GET"
        self.mock_request.url = MagicMock()
        self.mock_request.url.path = "/api/v1/headers"
        self.mock_request.client = None
        self.mock_request.headers = {}
        self.mock_request.state = MagicMock()

        # Setup response mock with existing headers
        self.mock_response.headers = {"Content-Type": "application/json"}
        self.mock_call_next.return_value = self.mock_response

        with patch("src.main.app.libs.middleware.log_middleware.logger"):
            with patch(
                "src.main.app.libs.middleware.log_middleware.uuid.uuid4"
            ) as mock_uuid:
                mock_uuid.return_value = MagicMock()
                mock_uuid.return_value.__str__ = MagicMock(
                    return_value="header-test-id"
                )

                # Call middleware
                result = await log_requests(self.mock_request, self.mock_call_next)

                # Verify original headers are preserved
                assert result.headers["Content-Type"] == "application/json"

                # Verify request ID header is added
                assert result.headers["X-Request-ID"] == "header-test-id"

    @pytest.mark.asyncio
    async def test_log_requests_complex_url_path(self):
        """Test log_requests middleware with complex URL paths."""
        complex_paths = [
            "/api/v1/users/123/posts/456/comments",
            "/api/v2/search?q=test&limit=10",
            "/admin/dashboard/analytics",
            "/",
            "/api/v1/files/upload",
            "/health/check",
        ]

        for path in complex_paths:
            # Setup fresh mocks
            mock_request = MagicMock(spec=Request)
            mock_request.method = "GET"
            mock_request.url = MagicMock()
            mock_request.url.path = path
            mock_request.client = MagicMock()
            mock_request.client.host = "test.example.com"
            mock_request.headers = {}
            mock_request.state = MagicMock()

            mock_response = MagicMock(spec=Response)
            mock_response.status_code = 200
            mock_response.headers = {}

            mock_call_next = AsyncMock(return_value=mock_response)

            with patch(
                "src.main.app.libs.middleware.log_middleware.logger"
            ) as mock_logger:
                with patch(
                    "src.main.app.libs.middleware.log_middleware.uuid.uuid4"
                ) as mock_uuid:
                    mock_uuid.return_value = MagicMock()
                    mock_uuid.return_value.__str__ = MagicMock(
                        return_value=f"path-test-{path.replace('/', '-')}"
                    )

                    # Call middleware
                    await log_requests(mock_request, mock_call_next)

                    # Verify path is correctly logged
                    start_log_call = mock_logger.info.call_args_list[0]
                    assert path in str(start_log_call)

                    completed_log_call = mock_logger.info.call_args_list[1]
                    assert path in str(completed_log_call)

    def test_log_requests_is_async_function(self):
        """Test that log_requests is properly defined as an async function."""
        import asyncio
        import inspect

        assert asyncio.iscoroutinefunction(log_requests)
        assert inspect.iscoroutinefunction(log_requests)

    @pytest.mark.asyncio
    async def test_log_requests_call_next_invocation(self):
        """Test that call_next is properly invoked with the request."""
        # Setup request mock
        self.mock_request.method = "POST"
        self.mock_request.url = MagicMock()
        self.mock_request.url.path = "/api/v1/data"
        self.mock_request.client = None
        self.mock_request.headers = {}
        self.mock_request.state = MagicMock()

        # Setup response mock
        self.mock_call_next.return_value = self.mock_response

        with patch("src.main.app.libs.middleware.log_middleware.logger"):
            with patch(
                "src.main.app.libs.middleware.log_middleware.uuid.uuid4"
            ) as mock_uuid:
                mock_uuid.return_value = MagicMock()
                mock_uuid.return_value.__str__ = MagicMock(
                    return_value="call-next-test"
                )

                # Call middleware
                await log_requests(self.mock_request, self.mock_call_next)

                # Verify call_next was called with the request
                self.mock_call_next.assert_called_once_with(self.mock_request)
