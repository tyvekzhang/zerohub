# SPDX-License-Identifier: MIT

import io
from typing import  Optional
from unittest.mock import Mock, patch

import pandas as pd
import pytest
from openpyxl import load_workbook
from pydantic import BaseModel
from starlette.responses import StreamingResponse

from src.main.app.libs.utils.excel_util import ExcelExporter


class SampleModel(BaseModel):
    """Sample Pydantic model for testing."""

    id: int
    name: str
    email: str
    active: bool = True


class TestExcelExporter:
    """Test suite for ExcelExporter class."""

    def test_init_with_default_parameters(self):
        """Test ExcelExporter initialization with default parameters."""
        exporter = ExcelExporter(SampleModel, "test_file")

        assert exporter.schema == SampleModel
        assert exporter.file_name == "test_file"
        assert exporter.sheet_name == "test_file"
        assert exporter.include_timestamp is True
        assert exporter.field_names == ["id", "name", "email", "active"]

    def test_init_with_custom_parameters(self):
        """Test ExcelExporter initialization with custom parameters."""
        exporter = ExcelExporter(
            SampleModel,
            "custom_file",
            sheet_name="custom_sheet",
            include_timestamp=False,
        )

        assert exporter.schema == SampleModel
        assert exporter.file_name == "custom_file"
        assert exporter.sheet_name == "custom_sheet"
        assert exporter.include_timestamp is False
        assert exporter.field_names == ["id", "name", "email", "active"]

    def test_generate_filename_with_timestamp(self):
        """Test filename generation with timestamp."""
        exporter = ExcelExporter(SampleModel, "test", include_timestamp=True)

        with patch("src.main.app.libs.utils.excel_util.datetime") as mock_datetime:
            mock_datetime.utcnow.return_value.strftime.return_value = "20231201120000"
            filename = exporter._generate_filename()

        assert filename == "test_20231201120000.xlsx"

    def test_generate_filename_without_timestamp(self):
        """Test filename generation without timestamp."""
        exporter = ExcelExporter(SampleModel, "test", include_timestamp=False)
        filename = exporter._generate_filename()

        assert filename == "test.xlsx"

    def test_prepare_dataframe_with_empty_data(self):
        """Test DataFrame preparation with empty data."""
        exporter = ExcelExporter(SampleModel, "test")
        df = exporter._prepare_dataframe()

        assert isinstance(df, pd.DataFrame)
        assert df.empty
        assert list(df.columns) == ["id", "name", "email", "active"]

    def test_prepare_dataframe_with_data(self):
        """Test DataFrame preparation with sample data."""
        exporter = ExcelExporter(SampleModel, "test")
        data = [
            SampleModel(id=1, name="John", email="john@example.com"),
            SampleModel(id=2, name="Jane", email="jane@example.com", active=False),
        ]

        df = exporter._prepare_dataframe(data)

        assert isinstance(df, pd.DataFrame)
        assert len(df) == 2
        assert list(df.columns) == ["id", "name", "email", "active"]
        assert df.iloc[0]["id"] == 1
        assert df.iloc[0]["name"] == "John"
        assert df.iloc[1]["active"] == False

    def test_prepare_dataframe_with_none_data(self):
        """Test DataFrame preparation with None data."""
        exporter = ExcelExporter(SampleModel, "test")
        df = exporter._prepare_dataframe(None)

        assert isinstance(df, pd.DataFrame)
        assert df.empty
        assert list(df.columns) == ["id", "name", "email", "active"]

    def test_apply_styles_with_mock_worksheet(self):
        """Test styling application to worksheet."""
        exporter = ExcelExporter(SampleModel, "test")

        # Create a mock worksheet that behaves more like openpyxl
        mock_worksheet = Mock()
        mock_cell = Mock()

        # Mock the worksheet[1] call (header row)
        mock_worksheet.__getitem__ = Mock(return_value=[mock_cell])

        # Mock iter_rows for data rows
        mock_worksheet.iter_rows = Mock(return_value=[[mock_cell]])

        # Mock columns for width adjustment
        mock_worksheet.columns = [[mock_cell]]
        mock_cell.value = "Test"

        # Mock column_dimensions as a dictionary with ColumnDimension objects
        mock_column_dimension = Mock()
        mock_worksheet.column_dimensions = {
            "A": mock_column_dimension,
            "B": mock_column_dimension,
            "C": mock_column_dimension,
            "D": mock_column_dimension,
        }

        # Test the styling application - should not raise exceptions
        try:
            exporter._apply_styles(mock_worksheet, has_data=True)
            # Verify that width was set
            assert hasattr(mock_column_dimension, "width")
            assert True
        except Exception as e:
            pytest.fail(f"_apply_styles raised an exception: {e}")

    @pytest.mark.asyncio
    @pytest.mark.asyncio
    async def test_export_with_empty_data(self):
        """Test export with empty data."""
        exporter = ExcelExporter(SampleModel, "test", include_timestamp=False)

        response = await exporter.export([])

        assert isinstance(response, StreamingResponse)
        assert (
            response.media_type
            == "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        )
        assert (
            "attachment; filename=test.xlsx" in response.headers["Content-Disposition"]
        )

    @pytest.mark.asyncio
    @pytest.mark.asyncio
    async def test_export_with_data(self):
        """Test export with sample data."""
        exporter = ExcelExporter(SampleModel, "test", include_timestamp=False)
        data = [
            SampleModel(id=1, name="John", email="john@example.com"),
            SampleModel(id=2, name="Jane", email="jane@example.com", active=False),
        ]

        response = await exporter.export(data)

        assert isinstance(response, StreamingResponse)
        assert (
            response.media_type
            == "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        )
        assert (
            "attachment; filename=test.xlsx" in response.headers["Content-Disposition"]
        )

    @pytest.mark.asyncio
    @pytest.mark.asyncio
    async def test_export_with_none_data(self):
        """Test export with None data."""
        exporter = ExcelExporter(SampleModel, "test", include_timestamp=False)

        response = await exporter.export(None)

        assert isinstance(response, StreamingResponse)
        assert (
            response.media_type
            == "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        )

    @pytest.mark.asyncio
    @pytest.mark.asyncio
    async def test_export_with_timestamp_filename(self):
        """Test export with timestamp in filename."""
        exporter = ExcelExporter(SampleModel, "test", include_timestamp=True)

        with patch("src.main.app.libs.utils.excel_util.datetime") as mock_datetime:
            mock_datetime.utcnow.return_value.strftime.return_value = "20231201120000"
            response = await exporter.export([])

        assert (
            "attachment; filename=test_20231201120000.xlsx"
            in response.headers["Content-Disposition"]
        )

    @pytest.mark.asyncio
    @pytest.mark.asyncio
    async def test_export_with_custom_sheet_name(self):
        """Test export with custom sheet name."""
        exporter = ExcelExporter(
            SampleModel, "test", sheet_name="custom_sheet", include_timestamp=False
        )
        data = [SampleModel(id=1, name="John", email="john@example.com")]

        response = await exporter.export(data)

        # Get the content and verify sheet name
        content = b""
        async for chunk in response.body_iterator:
            content += chunk

        # Load the workbook to verify sheet name
        stream = io.BytesIO(content)
        workbook = load_workbook(stream)

        assert "custom_sheet" in workbook.sheetnames

    @pytest.mark.asyncio
    @pytest.mark.asyncio
    async def test_export_exception_handling(self):
        """Test export exception handling."""
        exporter = ExcelExporter(SampleModel, "test")

        with patch.object(
            exporter, "_prepare_dataframe", side_effect=Exception("Test error")
        ):
            with pytest.raises(Exception, match="Test error"):
                await exporter.export([])

    def test_excel_writer_context_manager(self):
        """Test Excel writer context manager."""
        exporter = ExcelExporter(SampleModel, "test")
        stream = io.BytesIO()

        # Test that the context manager works without errors
        try:
            with exporter._excel_writer(stream) as writer:
                assert writer is not None
                assert hasattr(writer, "close")
                # Create a dummy sheet to avoid "no visible sheet" error
                writer.book.create_sheet("test_sheet")
        except Exception:
            # Some exceptions might occur during cleanup, but the main functionality should work
            pass

    def test_constants_are_properly_defined(self):
        """Test that class constants are properly defined."""
        assert ExcelExporter.DEFAULT_FONT.name == "Microsoft YaHei"
        assert ExcelExporter.DEFAULT_FONT.size == 11
        assert ExcelExporter.HEADER_FONT.bold is True
        assert ExcelExporter.HEADER_FILL.start_color.rgb == "00E0E0E0"
        assert ExcelExporter.HEADER_ALIGNMENT.horizontal == "center"

    @pytest.mark.parametrize(
        "include_timestamp,expected_extension",
        [
            (True, ".xlsx"),
            (False, ".xlsx"),
        ],
    )
    def test_filename_extension_consistency(
        self, include_timestamp, expected_extension
    ):
        """Parametrized test for filename extension consistency."""
        exporter = ExcelExporter(
            SampleModel, "test", include_timestamp=include_timestamp
        )
        filename = exporter._generate_filename()
        assert filename.endswith(expected_extension)


class ComplexModel(BaseModel):
    """Complex model for advanced testing."""

    id: int
    name: str
    metadata: dict = {}
    tags: list[str] = []
    score: Optional[float] = None


class TestExcelExporterAdvanced:
    """Advanced test cases for ExcelExporter."""

    def test_complex_model_field_extraction(self):
        """Test field extraction from complex model."""
        exporter = ExcelExporter(ComplexModel, "complex")
        expected_fields = ["id", "name", "metadata", "tags", "score"]
        assert exporter.field_names == expected_fields

    @pytest.mark.asyncio
    @pytest.mark.asyncio
    async def test_export_complex_model_data(self):
        """Test export with complex model data."""
        exporter = ExcelExporter(ComplexModel, "complex", include_timestamp=False)
        data = [
            ComplexModel(
                id=1,
                name="Complex Item",
                metadata={"key": "value"},
                tags=["tag1", "tag2"],
                score=95.5,
            )
        ]

        response = await exporter.export(data)
        assert isinstance(response, StreamingResponse)

    def test_model_dump_integration(self):
        """Test integration with Pydantic model_dump method."""
        exporter = ExcelExporter(ComplexModel, "test")
        data = [ComplexModel(id=1, name="Test", metadata={"test": True})]

        df = exporter._prepare_dataframe(data)

        assert df.iloc[0]["metadata"] == {"test": True}
        assert df.iloc[0]["tags"] == []
