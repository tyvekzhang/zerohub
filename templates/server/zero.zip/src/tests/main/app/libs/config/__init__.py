# SPDX-License-Identifier: MIT
"""Config tests package."""
