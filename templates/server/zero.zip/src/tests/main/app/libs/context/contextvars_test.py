# SPDX-License-Identifier: MIT
"""Comprehensive unit tests for contextvars module."""

import asyncio
import concurrent.futures
import threading
import time
from contextvars import ContextVar, copy_context
from typing import Optional

import pytest

from src.main.app.libs.context.contextvars import current_user_id


class TestCurrentUserIdContextVar:
    """Test cases for current_user_id context variable."""

    def setup_method(self):
        """Set up test fixtures before each test method."""
        # Reset context variable to default state before each test
        current_user_id.set(None)

    def teardown_method(self):
        """Clean up after each test method."""
        # Reset context variable to default state after each test
        current_user_id.set(None)

    def test_contextvar_initialization(self):
        """Test that context variable is properly initialized."""
        # Test the context variable exists and has correct name
        assert current_user_id.name == "current_user_id"

        # Test default value
        assert current_user_id.get() is None

    def test_contextvar_type_annotation(self):
        """Test that context variable has correct type annotation."""
        # Access the context variable's annotation through its class
        assert hasattr(current_user_id, "__class__")
        # ContextVar should be parameterized with Optional[int]
        assert isinstance(current_user_id, ContextVar)

    def test_get_default_value(self):
        """Test getting default value when nothing is set."""
        value = current_user_id.get()
        assert value is None

    def test_get_with_explicit_default(self):
        """Test getting value with explicit default parameter."""
        # Create a new ContextVar without a default to test this behavior
        test_var: ContextVar[Optional[int]] = ContextVar("test_var")

        # When no default is defined in ContextVar, get() with default should work
        value = test_var.get(42)
        assert value == 42

        # Set a value and verify get() returns that value instead of the default parameter
        token1 = test_var.set(100)
        assert test_var.get(42) == 100  # Should return 100, not 42

        # Set another value and reset to check that we go back to previous value
        token2 = test_var.set(200)
        assert test_var.get(42) == 200
        test_var.reset(token2)
        assert test_var.get(42) == 100  # Back to 100

        # Reset to original state and check default parameter again
        test_var.reset(token1)
        assert test_var.get(42) == 42

    def test_set_and_get_integer_value(self):
        """Test setting and getting integer user ID."""
        user_id = 12345
        token = current_user_id.set(user_id)

        # Verify the value was set
        assert current_user_id.get() == user_id

        # Verify set() returns a token
        assert token is not None

    def test_set_none_value(self):
        """Test setting None value explicitly."""
        # First set a value
        current_user_id.set(100)
        assert current_user_id.get() == 100

        # Then set None
        token = current_user_id.set(None)
        assert current_user_id.get() is None
        assert token is not None

    def test_reset_to_previous_value(self):
        """Test resetting to previous value using token."""
        # Set initial value
        initial_value = 1001
        current_user_id.set(initial_value)
        assert current_user_id.get() == initial_value

        # Set new value and get token
        new_value = 2002
        token = current_user_id.set(new_value)
        assert current_user_id.get() == new_value

        # Reset to previous value
        current_user_id.reset(token)
        assert current_user_id.get() == initial_value

    def test_reset_to_default_when_no_previous_value(self):
        """Test resetting when there was no previous value."""
        # Set a value from default state
        token = current_user_id.set(5555)
        assert current_user_id.get() == 5555

        # Reset should go back to default (None)
        current_user_id.reset(token)
        assert current_user_id.get() is None

    def test_multiple_set_operations(self):
        """Test multiple set operations and their tokens."""
        # Set first value
        token1 = current_user_id.set(111)
        assert current_user_id.get() == 111

        # Set second value
        token2 = current_user_id.set(222)
        assert current_user_id.get() == 222

        # Set third value
        token3 = current_user_id.set(333)
        assert current_user_id.get() == 333

        # Reset operations should work in reverse order
        current_user_id.reset(token3)
        assert current_user_id.get() == 222

        current_user_id.reset(token2)
        assert current_user_id.get() == 111

        current_user_id.reset(token1)
        assert current_user_id.get() is None

    def test_contextvar_isolation_between_contexts(self):
        """Test that context variables are isolated between different contexts."""
        # Set value in main context
        current_user_id.set(1000)
        main_context_value = current_user_id.get()

        def context_function():
            # This should see the value from the copied context
            initial_value = current_user_id.get()

            # Set a different value in this context
            current_user_id.set(2000)
            context_value = current_user_id.get()

            return initial_value, context_value

        # Copy current context and run function in it
        ctx = copy_context()
        initial_in_context, value_in_context = ctx.run(context_function)

        # The context should have inherited the main context value
        assert initial_in_context == 1000
        assert value_in_context == 2000

        # Main context should remain unchanged
        assert current_user_id.get() == main_context_value == 1000

    @pytest.mark.asyncio
    async def test_contextvar_in_async_context(self):
        """Test context variable behavior in async functions."""
        # Set value in main async context
        user_id = 4444
        current_user_id.set(user_id)

        async def async_function():
            # Should see the value from parent context
            return current_user_id.get()

        # Call async function
        result = await async_function()
        assert result == user_id

        # Value should still be accessible in main context
        assert current_user_id.get() == user_id

    @pytest.mark.asyncio
    async def test_contextvar_isolation_in_async_tasks(self):
        """Test context variable isolation between different async tasks."""

        async def task_with_user_id(user_id: int) -> int:
            current_user_id.set(user_id)
            # Simulate some async work
            await asyncio.sleep(0.01)
            return current_user_id.get()

        # Run multiple tasks concurrently
        tasks = [
            task_with_user_id(1),
            task_with_user_id(2),
            task_with_user_id(3),
            task_with_user_id(4),
            task_with_user_id(5),
        ]

        results = await asyncio.gather(*tasks)

        # Each task should return its own user ID
        assert results == [1, 2, 3, 4, 5]

        # Main context should still have default value
        assert current_user_id.get() is None

    def test_contextvar_in_thread_isolation(self):
        """Test that context variables are isolated between threads."""
        results = {}

        def thread_function(thread_id: int, user_id: int):
            current_user_id.set(user_id)
            time.sleep(0.01)  # Small delay to allow context switching
            results[thread_id] = current_user_id.get()

        # Create and start multiple threads
        threads = []
        for i in range(5):
            thread = threading.Thread(target=thread_function, args=(i, (i + 1) * 100))
            threads.append(thread)
            thread.start()

        # Wait for all threads to complete
        for thread in threads:
            thread.join()

        # Each thread should have its own isolated value
        expected_results = {0: 100, 1: 200, 2: 300, 3: 400, 4: 500}
        assert results == expected_results

        # Main thread should still have default value
        assert current_user_id.get() is None

    def test_contextvar_with_executor(self):
        """Test context variable behavior with ThreadPoolExecutor."""

        def executor_function(user_id: int) -> int:
            current_user_id.set(user_id)
            return current_user_id.get()

        # Set value in main context
        main_user_id = 9999
        current_user_id.set(main_user_id)

        # Use ThreadPoolExecutor to run function
        with concurrent.futures.ThreadPoolExecutor(max_workers=3) as executor:
            # Submit tasks with different user IDs
            futures = [
                executor.submit(executor_function, 1111),
                executor.submit(executor_function, 2222),
                executor.submit(executor_function, 3333),
            ]

            # Get results
            results = [
                future.result() for future in concurrent.futures.as_completed(futures)
            ]

        # Each task should return its own user ID
        assert sorted(results) == [1111, 2222, 3333]

        # Main context should be unchanged
        assert current_user_id.get() == main_user_id

    def test_contextvar_copy_context_behavior(self):
        """Test explicit context copying behavior."""
        # Set value in current context
        original_value = 7777
        current_user_id.set(original_value)

        # Copy current context
        ctx_copy = copy_context()

        # Modify value in current context
        current_user_id.set(8888)
        assert current_user_id.get() == 8888

        # Run function in copied context
        def check_value():
            return current_user_id.get()

        # The copied context should have the original value
        value_in_copy = ctx_copy.run(check_value)
        assert value_in_copy == original_value

        # Current context should still have the modified value
        assert current_user_id.get() == 8888

    def test_contextvar_edge_cases(self):
        """Test edge cases and boundary conditions."""
        # Test with zero
        current_user_id.set(0)
        assert current_user_id.get() == 0

        # Test with negative values
        current_user_id.set(-1)
        assert current_user_id.get() == -1

        # Test with very large values
        large_value = 2**31 - 1  # Max 32-bit signed integer
        current_user_id.set(large_value)
        assert current_user_id.get() == large_value

    def test_contextvar_token_behavior(self):
        """Test detailed token behavior and edge cases."""
        # Test token from setting None
        token_none = current_user_id.set(None)
        assert current_user_id.get() is None

        # Test token from setting value over None
        token_value = current_user_id.set(123)
        assert current_user_id.get() == 123

        # Reset to None using token
        current_user_id.reset(token_value)
        assert current_user_id.get() is None

        # Test that tokens are unique objects
        token1 = current_user_id.set(111)
        token2 = current_user_id.set(222)
        assert token1 is not token2

    @pytest.mark.asyncio
    async def test_contextvar_async_context_manager(self):
        """Test context variable with async context managers."""

        class AsyncUserContext:
            def __init__(self, user_id: int):
                self.user_id = user_id
                self.token = None

            async def __aenter__(self):
                self.token = current_user_id.set(self.user_id)
                return self

            async def __aexit__(self, exc_type, exc_val, exc_tb):
                if self.token:
                    current_user_id.reset(self.token)

        # Test the async context manager
        assert current_user_id.get() is None

        async with AsyncUserContext(6666):
            assert current_user_id.get() == 6666

            # Nested context
            async with AsyncUserContext(7777):
                assert current_user_id.get() == 7777

            # Should be back to outer context
            assert current_user_id.get() == 6666

        # Should be back to original context
        assert current_user_id.get() is None

    def test_contextvar_exception_safety(self):
        """Test context variable behavior when exceptions occur."""
        # Set initial value
        current_user_id.set(1234)

        def function_with_exception():
            token = current_user_id.set(5678)
            try:
                assert current_user_id.get() == 5678
                raise ValueError("Test exception")
            finally:
                # Reset should happen even with exception
                current_user_id.reset(token)

        # The exception should not affect context variable reset
        with pytest.raises(ValueError, match="Test exception"):
            function_with_exception()

        # Value should be back to original
        assert current_user_id.get() == 1234

    def test_contextvar_module_level_access(self):
        """Test that the context variable can be accessed at module level."""
        # Test that we can import and access the context variable
        from src.main.app.libs.context.contextvars import (
            current_user_id as imported_var,
        )

        # Should be the same object
        assert imported_var is current_user_id

        # Should have the same behavior
        imported_var.set(9876)
        assert current_user_id.get() == 9876
        assert imported_var.get() == 9876

    def test_contextvar_string_representation(self):
        """Test string representation of context variable."""
        # ContextVar should have a meaningful string representation
        var_str = str(current_user_id)
        assert "current_user_id" in var_str

        # Repr should also be meaningful
        var_repr = repr(current_user_id)
        assert "ContextVar" in var_repr
        assert "current_user_id" in var_repr


class TestContextVarIntegration:
    """Integration tests for context variable usage in the application."""

    def setup_method(self):
        """Set up test fixtures before each test method."""
        current_user_id.set(None)

    def teardown_method(self):
        """Clean up after each test method."""
        current_user_id.set(None)

    def test_jwt_middleware_integration_pattern(self):
        """Test the pattern used in JWT middleware."""

        # Simulate the JWT middleware pattern
        def simulate_jwt_middleware(user_id: int):
            """Simulate how JWT middleware sets the user ID."""
            ctx_token = current_user_id.set(user_id)
            try:
                # Simulate request processing
                return process_request()
            finally:
                # Always reset the context
                current_user_id.reset(ctx_token)

        def process_request():
            """Simulate request processing that uses the context variable."""
            user_id = current_user_id.get()
            return f"Processing request for user {user_id}"

        # Test the middleware pattern
        result = simulate_jwt_middleware(12345)
        assert result == "Processing request for user 12345"

        # Context should be reset after middleware
        assert current_user_id.get() is None

    def test_decorator_integration_pattern(self):
        """Test the pattern used in authorization decorators."""

        def simulate_pre_authorize_decorator(required_permission: str):
            """Simulate the pre_authorize decorator pattern."""

            def decorator(func):
                def wrapper(*args, **kwargs):
                    user_id = current_user_id.get()
                    if user_id is None:
                        raise PermissionError("No user context")

                    # Simulate permission check
                    if user_id == 0:
                        raise PermissionError(
                            f"User {user_id} lacks {required_permission}"
                        )

                    return func(*args, **kwargs)

                return wrapper

            return decorator

        @simulate_pre_authorize_decorator("read_data")
        def protected_function():
            user_id = current_user_id.get()
            return f"Data accessed by user {user_id}"

        # Test without user context
        with pytest.raises(PermissionError, match="No user context"):
            protected_function()

        # Test with unauthorized user
        current_user_id.set(0)
        with pytest.raises(PermissionError, match="User 0 lacks read_data"):
            protected_function()

        # Test with authorized user
        current_user_id.set(1001)
        result = protected_function()
        assert result == "Data accessed by user 1001"

    @pytest.mark.asyncio
    async def test_async_middleware_pattern(self):
        """Test async middleware pattern similar to actual implementation."""

        async def simulate_async_middleware(user_id: int):
            """Simulate async middleware."""
            ctx_token = current_user_id.set(user_id)
            try:
                return await async_request_handler()
            finally:
                current_user_id.reset(ctx_token)

        async def async_request_handler():
            """Simulate async request handling."""
            user_id = current_user_id.get()
            # Simulate async operation
            await asyncio.sleep(0.01)
            return f"Async response for user {user_id}"

        # Test async middleware
        result = await simulate_async_middleware(5555)
        assert result == "Async response for user 5555"

        # Context should be reset
        assert current_user_id.get() is None

    def test_nested_context_operations(self):
        """Test nested context operations as might occur in complex applications."""

        def outer_operation(user_id: int):
            token = current_user_id.set(user_id)
            try:
                return inner_operation()
            finally:
                current_user_id.reset(token)

        def inner_operation():
            user_id = current_user_id.get()
            # Inner operation might temporarily change context
            temp_token = current_user_id.set(user_id + 1000)
            try:
                return deepest_operation()
            finally:
                current_user_id.reset(temp_token)

        def deepest_operation():
            user_id = current_user_id.get()
            return f"Deepest operation with user {user_id}"

        # Test nested operations
        result = outer_operation(100)
        assert result == "Deepest operation with user 1100"

        # All contexts should be properly restored
        assert current_user_id.get() is None


class TestContextVarErrorHandling:
    """Test error handling and edge cases for context variables."""

    def setup_method(self):
        """Set up test fixtures before each test method."""
        current_user_id.set(None)

    def teardown_method(self):
        """Clean up after each test method."""
        current_user_id.set(None)

    def test_invalid_token_reset(self):
        """Test behavior with invalid token reset."""
        # Note: ContextVar.reset() with invalid token raises RuntimeError
        # We document this behavior rather than trying to handle it gracefully

        token = current_user_id.set(123)
        current_user_id.reset(token)  # Valid reset

        # Trying to reset with the same token again should raise RuntimeError
        with pytest.raises(RuntimeError, match="has already been used once"):
            current_user_id.reset(token)

    def test_reset_without_set(self):
        """Test reset behavior when no value was previously set."""
        # Create a token by setting a value
        token = current_user_id.set(456)

        # Reset normally
        current_user_id.reset(token)
        assert current_user_id.get() is None

        # Trying to reset again with same token should fail
        with pytest.raises(RuntimeError, match="has already been used once"):
            current_user_id.reset(token)

    def test_type_safety_documentation(self):
        """Document the type safety characteristics of the context variable."""
        # The context variable is typed as Optional[int], but at runtime
        # Python doesn't enforce this. We document expected usage.

        # Correct usage
        current_user_id.set(123)
        assert isinstance(current_user_id.get(), int)

        current_user_id.set(None)
        assert current_user_id.get() is None

        # While Python allows this at runtime, it violates the type annotation
        # This test documents that type checking should catch such issues
        current_user_id.set("invalid_type")  # Type checker should warn about this
        assert current_user_id.get() == "invalid_type"  # But it works at runtime

        # Reset to proper state
        current_user_id.set(None)
