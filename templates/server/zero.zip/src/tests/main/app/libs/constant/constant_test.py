# SPDX-License-Identifier: MIT
"""Comprehensive unit tests for constant module."""

import os
from unittest.mock import patch

from src.main.app.libs.constant.constant import (
    ADMIN_ID,
    AUTHORIZATION,
    CONFIG_FILE,
    CONFIG_FILE_NAME,
    ENV,
    MAX_PAGE_SIZE,
    PARENT_ID,
    RESOURCE_DIR,
    ROOT_PARENT_ID,
    FilterOperators,
    current_dir,
)


class TestModuleConstants:
    """Test suite for module-level constants."""

    def test_current_dir_is_string(self):
        """Test that current_dir is a string."""
        assert isinstance(current_dir, str)
        assert len(current_dir) > 0

    def test_current_dir_points_to_constant_directory(self):
        """Test that current_dir points to the constant module directory."""
        # Should end with 'constant' directory
        assert current_dir.endswith("constant") or current_dir.endswith("constant/")

        # Should be an absolute path
        assert os.path.isabs(current_dir)

        # Should exist
        assert os.path.exists(current_dir)

    def test_resource_dir_is_string(self):
        """Test that RESOURCE_DIR is a string."""
        assert isinstance(RESOURCE_DIR, str)
        assert len(RESOURCE_DIR) > 0

    def test_resource_dir_is_absolute_path(self):
        """Test that RESOURCE_DIR is an absolute path."""
        assert os.path.isabs(RESOURCE_DIR)

    def test_resource_dir_construction(self):
        """Test that RESOURCE_DIR is constructed correctly."""
        # Should be relative to current_dir
        expected_parts = ["resource"]
        assert RESOURCE_DIR.endswith("resource") or RESOURCE_DIR.endswith("resource/")

    def test_resource_dir_path_structure(self):
        """Test that RESOURCE_DIR has expected path structure."""
        # RESOURCE_DIR should be constructed by going up 3 levels from current_dir
        # and then joining with 'resource'
        parts = RESOURCE_DIR.split(os.sep)
        assert "resource" in parts

    @patch("os.path.dirname")
    @patch("os.path.abspath")
    def test_current_dir_construction_mocked(self, mock_abspath, mock_dirname):
        """Test current_dir construction with mocked os functions."""
        mock_abspath.return_value = "/mocked/path/constant.py"
        mock_dirname.return_value = "/mocked/path"

        # Re-import to test with mocked functions
        import importlib

        from src.main.app.libs.constant import constant

        importlib.reload(constant)

        mock_abspath.assert_called()
        mock_dirname.assert_called()


class TestStringConstants:
    """Test suite for string constants."""

    def test_env_constant(self):
        """Test ENV constant."""
        assert ENV == "env"
        assert isinstance(ENV, str)

    def test_config_file_constant(self):
        """Test CONFIG_FILE constant."""
        assert CONFIG_FILE == "config_file"
        assert isinstance(CONFIG_FILE, str)

    def test_authorization_constant(self):
        """Test AUTHORIZATION constant."""
        assert AUTHORIZATION == "Authorization"
        assert isinstance(AUTHORIZATION, str)

    def test_config_file_name_constant(self):
        """Test CONFIG_FILE_NAME constant."""
        assert CONFIG_FILE_NAME == "config.yml"
        assert isinstance(CONFIG_FILE_NAME, str)
        assert CONFIG_FILE_NAME.endswith(".yml")

    def test_parent_id_constant(self):
        """Test PARENT_ID constant."""
        assert PARENT_ID == "parent_id"
        assert isinstance(PARENT_ID, str)

    def test_string_constants_immutability(self):
        """Test that string constants are immutable (by convention)."""
        # These should be treated as constants (all uppercase)
        assert ENV.isupper() or ENV.islower()  # env is lowercase
        assert CONFIG_FILE.isupper() or "_" in CONFIG_FILE  # config_file has underscore
        assert AUTHORIZATION[0].isupper()  # Authorization is capitalized
        assert CONFIG_FILE_NAME.endswith(".yml")  # Extension should be lowercase
        assert (
            PARENT_ID.islower() or "_" in PARENT_ID
        )  # parent_id is lowercase with underscore


class TestNumericConstants:
    """Test suite for numeric constants."""

    def test_max_page_size_constant(self):
        """Test MAX_PAGE_SIZE constant."""
        assert MAX_PAGE_SIZE == 1000
        assert isinstance(MAX_PAGE_SIZE, int)
        assert MAX_PAGE_SIZE > 0

    def test_root_parent_id_constant(self):
        """Test ROOT_PARENT_ID constant."""
        assert ROOT_PARENT_ID == 0
        assert isinstance(ROOT_PARENT_ID, int)

    def test_admin_id_constant(self):
        """Test ADMIN_ID constant."""
        assert ADMIN_ID == 9
        assert isinstance(ADMIN_ID, int)
        assert ADMIN_ID > 0

    def test_numeric_constants_types(self):
        """Test that numeric constants have correct types."""
        assert type(MAX_PAGE_SIZE) is int
        assert type(ROOT_PARENT_ID) is int
        assert type(ADMIN_ID) is int

    def test_numeric_constants_values_logical(self):
        """Test that numeric constants have logical values."""
        # MAX_PAGE_SIZE should be reasonable for pagination
        assert 0 < MAX_PAGE_SIZE <= 10000

        # ROOT_PARENT_ID typically should be 0 for root items
        assert ROOT_PARENT_ID >= 0

        # ADMIN_ID should be positive
        assert ADMIN_ID > 0


class TestFilterOperators:
    """Test suite for FilterOperators class."""

    def test_filter_operators_class_exists(self):
        """Test that FilterOperators class exists."""
        assert FilterOperators is not None
        assert hasattr(FilterOperators, "EQ")

    def test_filter_operators_equality(self):
        """Test FilterOperators equality operators."""
        assert FilterOperators.EQ == "EQ"
        assert FilterOperators.NE == "NE"

    def test_filter_operators_comparison(self):
        """Test FilterOperators comparison operators."""
        assert FilterOperators.GT == "GT"
        assert FilterOperators.GE == "GE"
        assert FilterOperators.LT == "LT"
        assert FilterOperators.LE == "LE"

    def test_filter_operators_range(self):
        """Test FilterOperators range operator."""
        assert FilterOperators.BETWEEN == "BETWEEN"

    def test_filter_operators_pattern_matching(self):
        """Test FilterOperators pattern matching operator."""
        assert FilterOperators.LIKE == "LIKE"

    def test_filter_operators_all_strings(self):
        """Test that all FilterOperators values are strings."""
        operators = [
            FilterOperators.EQ,
            FilterOperators.NE,
            FilterOperators.GT,
            FilterOperators.GE,
            FilterOperators.LT,
            FilterOperators.LE,
            FilterOperators.BETWEEN,
            FilterOperators.LIKE,
        ]

        assert all(isinstance(op, str) for op in operators)
        assert all(len(op) > 0 for op in operators)

    def test_filter_operators_uppercase(self):
        """Test that all FilterOperators values are uppercase."""
        operators = [
            FilterOperators.EQ,
            FilterOperators.NE,
            FilterOperators.GT,
            FilterOperators.GE,
            FilterOperators.LT,
            FilterOperators.LE,
            FilterOperators.BETWEEN,
            FilterOperators.LIKE,
        ]

        assert all(op.isupper() for op in operators)

    def test_filter_operators_uniqueness(self):
        """Test that all FilterOperators values are unique."""
        operators = [
            FilterOperators.EQ,
            FilterOperators.NE,
            FilterOperators.GT,
            FilterOperators.GE,
            FilterOperators.LT,
            FilterOperators.LE,
            FilterOperators.BETWEEN,
            FilterOperators.LIKE,
        ]

        assert len(operators) == len(set(operators))

    def test_filter_operators_logical_meaning(self):
        """Test that FilterOperators have logical meanings."""
        # Equality operators
        assert "EQ" in FilterOperators.EQ  # Equal
        assert "NE" in FilterOperators.NE  # Not Equal

        # Comparison operators
        assert "GT" in FilterOperators.GT  # Greater Than
        assert "GE" in FilterOperators.GE  # Greater or Equal
        assert "LT" in FilterOperators.LT  # Less Than
        assert "LE" in FilterOperators.LE  # Less or Equal

        # Range and pattern operators
        assert "BETWEEN" in FilterOperators.BETWEEN
        assert "LIKE" in FilterOperators.LIKE

    def test_filter_operators_class_attributes(self):
        """Test FilterOperators class attributes."""
        # Test that all expected attributes exist
        expected_attributes = ["EQ", "NE", "GT", "GE", "LT", "LE", "BETWEEN", "LIKE"]

        for attr in expected_attributes:
            assert hasattr(FilterOperators, attr)
            assert isinstance(getattr(FilterOperators, attr), str)

    def test_filter_operators_no_unexpected_attributes(self):
        """Test that FilterOperators doesn't have unexpected attributes."""
        # Get all attributes that don't start with underscore
        attributes = [attr for attr in dir(FilterOperators) if not attr.startswith("_")]
        expected_attributes = ["EQ", "NE", "GT", "GE", "LT", "LE", "BETWEEN", "LIKE"]

        # Should only have expected attributes
        assert set(attributes) == set(expected_attributes)


class TestConstantUsageScenarios:
    """Test practical usage scenarios of constants."""

    def test_resource_dir_usage(self):
        """Test RESOURCE_DIR usage scenarios."""
        # Should be usable for file path construction
        config_path = os.path.join(RESOURCE_DIR, CONFIG_FILE_NAME)
        assert isinstance(config_path, str)
        assert CONFIG_FILE_NAME in config_path

    def test_filter_operators_usage_in_conditions(self):
        """Test FilterOperators usage in conditional logic."""

        def apply_filter(operator, value1, value2):
            if operator == FilterOperators.EQ:
                return value1 == value2
            elif operator == FilterOperators.NE:
                return value1 != value2
            elif operator == FilterOperators.GT:
                return value1 > value2
            elif operator == FilterOperators.GE:
                return value1 >= value2
            elif operator == FilterOperators.LT:
                return value1 < value2
            elif operator == FilterOperators.LE:
                return value1 <= value2
            else:
                return False

        # Test all operators
        assert apply_filter(FilterOperators.EQ, 5, 5) is True
        assert apply_filter(FilterOperators.NE, 5, 3) is True
        assert apply_filter(FilterOperators.GT, 5, 3) is True
        assert apply_filter(FilterOperators.GE, 5, 5) is True
        assert apply_filter(FilterOperators.LT, 3, 5) is True
        assert apply_filter(FilterOperators.LE, 5, 5) is True

    def test_pagination_constants_usage(self):
        """Test pagination-related constants usage."""

        def validate_page_size(size):
            return 1 <= size <= MAX_PAGE_SIZE

        def is_root_item(parent_id):
            return parent_id == ROOT_PARENT_ID

        def is_admin_user(user_id):
            return user_id == ADMIN_ID

        # Test validation functions
        assert validate_page_size(10) is True
        assert validate_page_size(1000) is True
        assert validate_page_size(1001) is False
        assert validate_page_size(0) is False

        assert is_root_item(0) is True
        assert is_root_item(1) is False

        assert is_admin_user(9) is True
        assert is_admin_user(10) is False

    def test_authorization_header_usage(self):
        """Test AUTHORIZATION constant usage in headers."""

        def get_auth_header(token):
            return {AUTHORIZATION: f"Bearer {token}"}

        def extract_token(headers):
            auth_header = headers.get(AUTHORIZATION, "")
            if auth_header.startswith("Bearer "):
                return auth_header[7:]  # Remove "Bearer " prefix
            return None

        # Test header functions
        headers = get_auth_header("test_token_123")
        assert headers[AUTHORIZATION] == "Bearer test_token_123"

        token = extract_token(headers)
        assert token == "test_token_123"

        # Test with missing header
        empty_headers = {}
        assert extract_token(empty_headers) is None

    def test_config_file_usage(self):
        """Test config file constants usage."""

        def get_config_path(config_dir):
            return os.path.join(config_dir, CONFIG_FILE_NAME)

        def get_default_config_path():
            return os.path.join(RESOURCE_DIR, CONFIG_FILE_NAME)

        # Test config path functions
        custom_path = get_config_path("/custom/config")
        assert custom_path.endswith(CONFIG_FILE_NAME)
        assert "/custom/config" in custom_path

        default_path = get_default_config_path()
        assert default_path.endswith(CONFIG_FILE_NAME)
        assert "resource" in default_path.lower()


class TestConstantIntegrity:
    """Test the integrity and consistency of constants."""

    def test_path_constants_consistency(self):
        """Test that path-related constants are consistent."""
        # current_dir should be a parent of RESOURCE_DIR construction
        assert isinstance(current_dir, str)
        assert isinstance(RESOURCE_DIR, str)

        # Both should be absolute paths
        assert os.path.isabs(current_dir)
        assert os.path.isabs(RESOURCE_DIR)

    def test_id_constants_consistency(self):
        """Test that ID-related constants are consistent."""
        # All ID constants should be integers
        assert isinstance(ROOT_PARENT_ID, int)
        assert isinstance(ADMIN_ID, int)

        # ROOT_PARENT_ID should be different from ADMIN_ID
        assert ROOT_PARENT_ID != ADMIN_ID

        # ROOT_PARENT_ID should typically be 0 or -1
        assert ROOT_PARENT_ID in [0, -1]

    def test_size_constants_consistency(self):
        """Test that size-related constants are consistent."""
        assert isinstance(MAX_PAGE_SIZE, int)
        assert MAX_PAGE_SIZE > 0

        # Should be a reasonable page size limit
        assert 100 <= MAX_PAGE_SIZE <= 10000

    def test_string_constants_consistency(self):
        """Test that string constants are consistent."""
        # File name should have appropriate extension
        assert CONFIG_FILE_NAME.endswith((".yml", ".yaml", ".json", ".toml"))

        # Header name should follow HTTP convention
        assert AUTHORIZATION[0].isupper()  # First letter capitalized
        assert " " not in AUTHORIZATION  # No spaces in header names

        # Environment and config constants should be reasonable
        assert len(ENV) > 0
        assert len(CONFIG_FILE) > 0

    def test_filter_operators_completeness(self):
        """Test that FilterOperators covers common comparison operations."""
        # Should have basic equality operators
        assert hasattr(FilterOperators, "EQ")
        assert hasattr(FilterOperators, "NE")

        # Should have all comparison operators
        assert hasattr(FilterOperators, "GT")
        assert hasattr(FilterOperators, "GE")
        assert hasattr(FilterOperators, "LT")
        assert hasattr(FilterOperators, "LE")

        # Should have range and pattern operators
        assert hasattr(FilterOperators, "BETWEEN")
        assert hasattr(FilterOperators, "LIKE")

        # Values should follow consistent naming convention
        operators = [
            getattr(FilterOperators, attr)
            for attr in dir(FilterOperators)
            if not attr.startswith("_")
        ]
        assert all(op.isupper() for op in operators)
        assert all(isinstance(op, str) for op in operators)
