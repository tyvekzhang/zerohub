# SPDX-License-Identifier: MIT

import tempfile
from pathlib import Path
from unittest.mock import patch

import pytest

from src.main.app.libs.utils.file_util import (
    PathFinder,
    _default_finder,
    ensure_dir,
    find_project_root,
    get_file_dir,
    get_file_path,
    get_project_path,
    get_resource_dir,
    get_utils_dir,
)


class TestPathFinder:
    """Test suite for PathFinder class."""

    def test_init_with_default_path(self):
        """Test PathFinder initialization with default path."""
        finder = PathFinder()
        assert isinstance(finder.base_path, Path)
        assert finder.base_path.is_absolute()

    def test_init_with_custom_path(self):
        """Test PathFinder initialization with custom path."""
        custom_path = Path("/tmp")
        finder = PathFinder(custom_path)
        assert finder.base_path == custom_path

    def test_init_with_string_path(self):
        """Test PathFinder initialization with string path."""
        finder = PathFinder("/tmp")
        assert finder.base_path == Path("/tmp")

    def test_find_upward_success(self):
        """Test successful upward search for a target."""
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)

            # Create a nested directory structure
            nested_dir = temp_path / "level1" / "level2" / "level3"
            nested_dir.mkdir(parents=True)

            # Create target file at level1
            target_file = temp_path / "level1" / "target.txt"
            target_file.write_text("test")

            # Search from level3
            finder = PathFinder(nested_dir)
            result = finder.find_upward("target.txt")

            assert result.resolve() == target_file.resolve()

    def test_find_upward_not_found(self):
        """Test upward search when target is not found."""
        with tempfile.TemporaryDirectory() as temp_dir:
            finder = PathFinder(temp_dir)

            with pytest.raises(FileNotFoundError, match="'nonexistent.txt' not found"):
                finder.find_upward("nonexistent.txt", max_depth=3)

    def test_find_upward_with_custom_start_path(self):
        """Test upward search with custom start path."""
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)

            # Create nested structure
            nested_dir = temp_path / "nested"
            nested_dir.mkdir()

            # Create target file
            target_file = temp_path / "target.txt"
            target_file.write_text("test")

            finder = PathFinder()
            result = finder.find_upward("target.txt", start_path=nested_dir)

            # Use samefile to compare paths on Windows (handles 8.3 name issues)
            assert result.samefile(target_file)

    def test_find_upward_directory_target(self):
        """Test upward search for directory target."""
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)

            # Create nested directory
            nested_dir = temp_path / "level1" / "level2"
            nested_dir.mkdir(parents=True)

            # Create target directory
            target_dir = temp_path / "target_dir"
            target_dir.mkdir()

            finder = PathFinder(nested_dir)
            result = finder.find_upward("target_dir")

            # Use samefile to compare paths on Windows (handles 8.3 name issues)
            assert result.samefile(target_dir)

    def test_find_upward_max_depth_reached(self):
        """Test upward search when max depth is reached."""
        with tempfile.TemporaryDirectory() as temp_dir:
            deep_path = Path(temp_dir) / "a" / "b" / "c" / "d" / "e"
            deep_path.mkdir(parents=True)

            finder = PathFinder(deep_path)

            with pytest.raises(FileNotFoundError):
                finder.find_upward("nonexistent.txt", max_depth=2)

    def test_find_upward_caching(self):
        """Test that find_upward results are cached."""
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            target_file = temp_path / "target.txt"
            target_file.write_text("test")

            finder = PathFinder(temp_path)

            # First call
            result1 = finder.find_upward("target.txt")

            # Second call should return cached result
            result2 = finder.find_upward("target.txt")

            assert result1 == result2

    def test_find_project_root_with_default_markers(self):
        """Test finding project root with default markers."""
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)

            # Create pyproject.toml
            pyproject_file = temp_path / "pyproject.toml"
            pyproject_file.write_text("[project]\nname = 'test'")

            # Create nested directory
            nested_dir = temp_path / "src" / "app"
            nested_dir.mkdir(parents=True)

            finder = PathFinder(nested_dir)
            result = finder.find_project_root()

            # Use samefile to compare paths on Windows (handles 8.3 name issues)
            assert result.samefile(temp_path)

    def test_find_project_root_with_custom_markers(self):
        """Test finding project root with custom markers."""
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)

            # Create custom marker
            marker_file = temp_path / "custom.marker"
            marker_file.write_text("marker")

            nested_dir = temp_path / "nested"
            nested_dir.mkdir()

            finder = PathFinder(nested_dir)
            result = finder.find_project_root("custom.marker")

            # Use samefile to compare paths on Windows (handles 8.3 name issues)
            assert result.samefile(temp_path)

    def test_find_project_root_with_multiple_markers(self):
        """Test finding project root with multiple markers."""
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)

            # Create setup.py (second marker in default list)
            setup_file = temp_path / "setup.py"
            setup_file.write_text("from setuptools import setup")

            nested_dir = temp_path / "nested"
            nested_dir.mkdir()

            finder = PathFinder(nested_dir)
            result = finder.find_project_root()

            # Use samefile to compare paths on Windows (handles 8.3 name issues)
            assert result.samefile(temp_path)

    def test_find_project_root_no_marker_found(self):
        """Test finding project root when no marker is found."""
        with tempfile.TemporaryDirectory() as temp_dir:
            finder = PathFinder(temp_dir)

            with pytest.raises(FileNotFoundError, match="No project root marker found"):
                finder.find_project_root(["nonexistent.marker"])

    def test_find_project_root_directory_marker(self):
        """Test finding project root with directory marker like .git."""
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)

            # Create .git directory
            git_dir = temp_path / ".git"
            git_dir.mkdir()

            nested_dir = temp_path / "src"
            nested_dir.mkdir()

            finder = PathFinder(nested_dir)
            result = finder.find_project_root([".git"])

            # Use samefile to compare paths on Windows (handles 8.3 name issues)
            assert result.samefile(git_dir)  # Returns the .git directory itself

    def test_project_root_property_caching(self):
        """Test that project_root property is cached."""
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            pyproject_file = temp_path / "pyproject.toml"
            pyproject_file.write_text("[project]\nname = 'test'")

            finder = PathFinder(temp_path)

            # Access property multiple times
            root1 = finder.project_root
            root2 = finder.project_root

            # Use samefile to compare paths on Windows (handles 8.3 name issues)
            assert root1.samefile(root2) and root1.samefile(temp_path)

    def test_get_resource_path(self):
        """Test getting resource path relative to project root."""
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            pyproject_file = temp_path / "pyproject.toml"
            pyproject_file.write_text("[project]\nname = 'test'")

            finder = PathFinder(temp_path)
            result = finder.get_resource_path("data", "file.txt")

            expected = temp_path / "data" / "file.txt"
            # Compare resolved paths to handle Windows 8.3 name issues
            assert result.resolve() == expected.resolve()


class TestModuleFunctions:
    """Test suite for module-level convenience functions."""

    def test_get_utils_dir(self):
        """Test get_utils_dir function."""
        result = get_utils_dir()
        assert isinstance(result, str)
        assert result.endswith("utils")

        # Should be cached - test multiple calls
        result2 = get_utils_dir()
        assert result == result2

    def test_get_resource_dir_with_existing_resource(self):
        """Test get_resource_dir when resource directory exists."""
        with patch.object(_default_finder, "find_project_root") as mock_find_root:
            with tempfile.TemporaryDirectory() as temp_dir:
                temp_path = Path(temp_dir)
                resource_dir = temp_path / "resource"
                resource_dir.mkdir()

                mock_find_root.return_value = temp_path

                # Clear cache
                get_resource_dir.cache_clear()

                result = get_resource_dir()
                assert result == str(resource_dir)

    def test_get_resource_dir_fallback(self):
        """Test get_resource_dir fallback logic."""
        with patch.object(_default_finder, "find_project_root") as mock_find_root:
            with tempfile.TemporaryDirectory() as temp_dir:
                temp_path = Path(temp_dir)
                # Don't create resource directory to trigger fallback

                mock_find_root.return_value = temp_path

                # Clear cache
                get_resource_dir.cache_clear()

                result = get_resource_dir()
                assert isinstance(result, str)
                assert result.endswith("resource")

    def test_get_resource_dir_exception_fallback(self):
        """Test get_resource_dir when exception occurs."""
        with patch.object(
            _default_finder, "find_project_root", side_effect=FileNotFoundError
        ):
            # Clear cache
            get_resource_dir.cache_clear()

            result = get_resource_dir()
            assert isinstance(result, str)
            assert result.endswith("resource")

    def test_get_file_dir(self):
        """Test get_file_dir function."""
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            test_file = temp_path / "test.txt"
            test_file.write_text("test")

            with patch.object(_default_finder, "find_upward", return_value=test_file):
                result = get_file_dir("test.txt")
                assert result == str(temp_path)

    def test_get_file_dir_with_directory(self):
        """Test get_file_dir when marker is a directory."""
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            test_dir = temp_path / "test_dir"
            test_dir.mkdir()

            with patch.object(_default_finder, "find_upward", return_value=test_dir):
                result = get_file_dir("test_dir")
                assert result == str(test_dir)

    def test_get_file_path(self):
        """Test get_file_path function."""
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            test_file = temp_path / "test.txt"
            test_file.write_text("test")

            with patch.object(_default_finder, "find_upward", return_value=test_file):
                result = get_file_path("test.txt")
                assert result == str(test_file)

    def test_find_project_root_function(self):
        """Test find_project_root function."""
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            pyproject_file = temp_path / "pyproject.toml"
            pyproject_file.write_text("[project]\nname = 'test'")

            with patch.object(
                _default_finder, "find_project_root", return_value=temp_path
            ):
                result = find_project_root()
                assert result == temp_path

    def test_get_project_path(self):
        """Test get_project_path function."""
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)

            with patch.object(_default_finder, "get_resource_path") as mock_get_path:
                expected_path = temp_path / "data" / "file.txt"
                mock_get_path.return_value = expected_path

                result = get_project_path("data", "file.txt")
                assert result == expected_path
                mock_get_path.assert_called_once_with("data", "file.txt")

    def test_ensure_dir_creates_directory(self):
        """Test ensure_dir creates directory if it doesn't exist."""
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            new_dir = temp_path / "new_directory"

            result = ensure_dir(new_dir)

            assert new_dir.exists()
            assert new_dir.is_dir()
            assert result == new_dir

    def test_ensure_dir_with_existing_directory(self):
        """Test ensure_dir with existing directory."""
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)

            result = ensure_dir(temp_path)

            assert temp_path.exists()
            assert result == temp_path

    def test_ensure_dir_with_string_path(self):
        """Test ensure_dir with string path."""
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            new_dir_str = str(temp_path / "string_directory")

            result = ensure_dir(new_dir_str)

            assert Path(new_dir_str).exists()
            assert isinstance(result, Path)

    def test_ensure_dir_creates_parent_directories(self):
        """Test ensure_dir creates parent directories."""
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            nested_dir = temp_path / "parent" / "child" / "grandchild"

            result = ensure_dir(nested_dir)

            assert nested_dir.exists()
            assert nested_dir.is_dir()
            assert result == nested_dir


class TestDefaultFinder:
    """Test suite for the default finder instance."""

    def test_default_finder_exists(self):
        """Test that default finder instance exists."""
        assert _default_finder is not None
        assert isinstance(_default_finder, PathFinder)

    def test_default_finder_base_path(self):
        """Test default finder base path."""
        assert isinstance(_default_finder.base_path, Path)
        assert _default_finder.base_path.is_absolute()


class TestEdgeCases:
    """Test suite for edge cases and error conditions."""

    def test_pathfinder_with_none_base_path(self):
        """Test PathFinder behavior with None base_path parameter."""
        finder = PathFinder(None)
        assert isinstance(finder.base_path, Path)

    def test_find_upward_at_filesystem_root(self):
        """Test find_upward behavior when reaching filesystem root."""
        # This test might behave differently on different systems
        finder = PathFinder(Path("/"))

        with pytest.raises(FileNotFoundError):
            finder.find_upward("nonexistent_file_at_root", max_depth=5)

    def test_find_project_root_with_empty_markers_list(self):
        """Test find_project_root with empty markers list."""
        finder = PathFinder()

        with pytest.raises(FileNotFoundError):
            finder.find_project_root([])

    @pytest.mark.parametrize("marker_type", ["file", "directory"])
    def test_find_project_root_marker_types(self, marker_type):
        """Parametrized test for different marker types."""
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)

            if marker_type == "file":
                marker = temp_path / "marker.txt"
                marker.write_text("test")
                expected_root = temp_path
            else:
                marker = temp_path / "marker_dir"
                marker.mkdir()
                expected_root = marker

            nested_dir = temp_path / "nested"
            nested_dir.mkdir()

            finder = PathFinder(nested_dir)
            result = finder.find_project_root([marker.name])

            # Use samefile to compare paths on Windows (handles 8.3 name issues)
            assert result.samefile(expected_root)
