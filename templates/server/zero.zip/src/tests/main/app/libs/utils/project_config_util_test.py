# SPDX-License-Identifier: MIT

import tempfile
from pathlib import Path
from unittest.mock import patch

import pytest

from src.main.app.libs.utils.project_config_util import (
    DbConnectionInfo,
    ProjectInfo,
    get_alembic_db_info,
    get_db_dialect,
    get_db_url,
    get_sqlite_db_path,
)


class TestDbConnectionInfo:
    """Test suite for DbConnectionInfo namedtuple."""

    def test_db_connection_info_creation(self):
        """Test DbConnectionInfo creation with all fields."""
        db_info = DbConnectionInfo(
            driver="postgresql",
            username="testuser",
            password="testpass",
            host="localhost",
            port="5432",
            dbname="testdb",
            full_url="postgresql://testuser:testpass@localhost:5432/testdb",
        )

        assert db_info.driver == "postgresql"
        assert db_info.username == "testuser"
        assert db_info.password == "testpass"
        assert db_info.host == "localhost"
        assert db_info.port == "5432"
        assert db_info.dbname == "testdb"
        assert (
            db_info.full_url == "postgresql://testuser:testpass@localhost:5432/testdb"
        )

    def test_db_connection_info_fields_access(self):
        """Test accessing DbConnectionInfo fields by name and index."""
        db_info = DbConnectionInfo("mysql", "user", "pass", "host", "3306", "db", "url")

        # Access by field name
        assert db_info.driver == "mysql"
        assert db_info.username == "user"

        # Access by index
        assert db_info[0] == "mysql"
        assert db_info[1] == "user"


class TestGetAlembicDbInfo:
    """Test suite for get_alembic_db_info function."""

    def test_get_alembic_db_info_postgresql(self):
        """Test parsing PostgreSQL connection URL."""
        config_content = """
[alembic]
sqlalchemy.url = postgresql://user:pass@localhost:5432/dbname
"""

        with tempfile.NamedTemporaryFile(mode="w", suffix=".ini", delete=False) as f:
            f.write(config_content)
            config_path = f.name

        try:
            db_info = get_alembic_db_info(config_path)

            assert db_info.driver == "postgresql"
            assert db_info.username == "user"
            assert db_info.password == "pass"
            assert db_info.host == "localhost"
            assert db_info.port == "5432"
            assert db_info.dbname == "dbname"
            assert db_info.full_url == "postgresql://user:pass@localhost:5432/dbname"
        finally:
            Path(config_path).unlink()

    def test_get_alembic_db_info_mysql(self):
        """Test parsing MySQL connection URL."""
        config_content = """
[alembic]
sqlalchemy.url = mysql+pymysql://root:password@127.0.0.1:3306/mydb
"""

        with tempfile.NamedTemporaryFile(mode="w", suffix=".ini", delete=False) as f:
            f.write(config_content)
            config_path = f.name

        try:
            db_info = get_alembic_db_info(config_path)

            assert db_info.driver == "mysql+pymysql"
            assert db_info.username == "root"
            assert db_info.password == "password"
            assert db_info.host == "127.0.0.1"
            assert db_info.port == "3306"
            assert db_info.dbname == "mydb"
        finally:
            Path(config_path).unlink()

    def test_get_alembic_db_info_sqlite(self):
        """Test parsing SQLite connection URL."""
        config_content = """
[alembic]
sqlalchemy.url = sqlite:///./data/app.db
"""

        with tempfile.NamedTemporaryFile(mode="w", suffix=".ini", delete=False) as f:
            f.write(config_content)
            config_path = f.name

        try:
            db_info = get_alembic_db_info(config_path)

            assert db_info.driver == "sqlite"
            assert db_info.username == ""
            assert db_info.password == ""
            assert db_info.host == "localhost"  # Default value
            assert db_info.port == ""
            assert db_info.dbname == "./data/app.db"
        finally:
            Path(config_path).unlink()

    def test_get_alembic_db_info_minimal_url(self):
        """Test parsing minimal database URL."""
        config_content = """
[alembic]
sqlalchemy.url = sqlite:///test.db
"""

        with tempfile.NamedTemporaryFile(mode="w", suffix=".ini", delete=False) as f:
            f.write(config_content)
            config_path = f.name

        try:
            db_info = get_alembic_db_info(config_path)

            assert db_info.driver == "sqlite"
            assert db_info.host == "localhost"
            assert db_info.dbname == "test.db"
        finally:
            Path(config_path).unlink()

    def test_get_alembic_db_info_file_not_found(self):
        """Test KeyError when config file doesn't exist (configparser doesn't raise FileNotFoundError)."""
        # configparser.read() doesn't raise FileNotFoundError for missing files,
        # it just returns an empty config, which then fails the sqlalchemy.url check
        with pytest.raises(KeyError, match="sqlalchemy.url not found"):
            get_alembic_db_info("nonexistent.ini")

    def test_get_alembic_db_info_missing_sqlalchemy_url(self):
        """Test KeyError when sqlalchemy.url is missing."""
        config_content = """
[alembic]
script_location = alembic
"""

        with tempfile.NamedTemporaryFile(mode="w", suffix=".ini", delete=False) as f:
            f.write(config_content)
            config_path = f.name

        try:
            with pytest.raises(KeyError, match="sqlalchemy.url not found"):
                get_alembic_db_info(config_path)
        finally:
            Path(config_path).unlink()

    def test_get_alembic_db_info_invalid_url_format(self):
        """Test ValueError for invalid URL format."""
        config_content = """
[alembic]
sqlalchemy.url = invalid_url_format
"""

        with tempfile.NamedTemporaryFile(mode="w", suffix=".ini", delete=False) as f:
            f.write(config_content)
            config_path = f.name

        try:
            with pytest.raises(ValueError, match="Invalid database URL format"):
                get_alembic_db_info(config_path)
        finally:
            Path(config_path).unlink()

    def test_get_alembic_db_info_url_without_path(self):
        """Test ValueError for URL without database path."""
        config_content = """
[alembic]
sqlalchemy.url = postgresql://user:pass@localhost:5432
"""

        with tempfile.NamedTemporaryFile(mode="w", suffix=".ini", delete=False) as f:
            f.write(config_content)
            config_path = f.name

        try:
            with pytest.raises(ValueError, match="Invalid database URL format"):
                get_alembic_db_info(config_path)
        finally:
            Path(config_path).unlink()

    def test_get_alembic_db_info_with_special_characters(self):
        """Test parsing URL with special characters in password."""
        config_content = """
[alembic]
sqlalchemy.url = postgresql://user:p@ssw0rd!@localhost:5432/dbname
"""

        with tempfile.NamedTemporaryFile(mode="w", suffix=".ini", delete=False) as f:
            f.write(config_content)
            config_path = f.name

        try:
            db_info = get_alembic_db_info(config_path)

            assert db_info.username == "user"
            assert db_info.password == "p@ssw0rd!"
            assert db_info.host == "localhost"
        finally:
            Path(config_path).unlink()


class TestGetDbUrl:
    """Test suite for get_db_url function."""

    @patch("src.main.app.libs.utils.project_config_util.get_alembic_db_info")
    @patch("src.main.app.libs.utils.project_config_util.file_util.get_file_path")
    def test_get_db_url(self, mock_get_file_path, mock_get_alembic_db_info):
        """Test get_db_url function."""
        mock_get_file_path.return_value = "/path/to/alembic.ini"
        mock_db_info = DbConnectionInfo(
            driver="postgresql",
            username="user",
            password="pass",
            host="localhost",
            port="5432",
            dbname="testdb",
            full_url="postgresql://user:pass@localhost:5432/testdb",
        )
        mock_get_alembic_db_info.return_value = mock_db_info

        result = get_db_url()

        assert result == "postgresql://user:pass@localhost:5432/testdb"
        mock_get_file_path.assert_called_once_with("alembic.ini")
        mock_get_alembic_db_info.assert_called_once_with("/path/to/alembic.ini")


class TestGetSqliteDbPath:
    """Test suite for get_sqlite_db_path function."""

    @patch("src.main.app.libs.utils.project_config_util.get_db_url")
    @patch("src.main.app.libs.utils.project_config_util.get_resource_dir")
    def test_get_sqlite_db_path_windows_style(
        self, mock_get_resource_dir, mock_get_db_url
    ):
        """Test get_sqlite_db_path with Windows-style path."""
        mock_get_db_url.return_value = "sqlite:///C:\\path\\to\\database.db"
        mock_get_resource_dir.return_value = "/resource/dir"

        result = get_sqlite_db_path()

        expected = "sqlite+aiosqlite:////resource/dir/alembic/db/database.db"
        assert result == expected

    @patch("src.main.app.libs.utils.project_config_util.get_db_url")
    @patch("src.main.app.libs.utils.project_config_util.get_resource_dir")
    def test_get_sqlite_db_path_unix_style(
        self, mock_get_resource_dir, mock_get_db_url
    ):
        """Test get_sqlite_db_path with Unix-style path."""
        mock_get_db_url.return_value = "sqlite:///./data/database.db"
        mock_get_resource_dir.return_value = "/resource/dir"

        result = get_sqlite_db_path()

        expected = "sqlite+aiosqlite:////resource/dir/alembic/db/database.db"
        assert result == expected

    @patch("src.main.app.libs.utils.project_config_util.get_db_url")
    def test_get_sqlite_db_path_empty_url(self, mock_get_db_url):
        """Test get_sqlite_db_path with empty URL."""
        mock_get_db_url.return_value = ""

        with pytest.raises(ValueError, match="Invalid database URL"):
            get_sqlite_db_path()

    @patch("src.main.app.libs.utils.project_config_util.get_db_url")
    def test_get_sqlite_db_path_whitespace_url(self, mock_get_db_url):
        """Test get_sqlite_db_path with whitespace-only URL."""
        mock_get_db_url.return_value = "   "

        with pytest.raises(ValueError, match="Invalid database URL"):
            get_sqlite_db_path()


class TestGetDbDialect:
    """Test suite for get_db_dialect function."""

    @patch("src.main.app.libs.utils.project_config_util.get_db_url")
    def test_get_db_dialect_postgresql(self, mock_get_db_url):
        """Test get_db_dialect with PostgreSQL URL."""
        mock_get_db_url.return_value = "postgresql://user:pass@localhost:5432/db"

        result = get_db_dialect()
        assert result == "postgresql"

    @patch("src.main.app.libs.utils.project_config_util.get_db_url")
    def test_get_db_dialect_mysql(self, mock_get_db_url):
        """Test get_db_dialect with MySQL URL."""
        mock_get_db_url.return_value = "mysql+pymysql://user:pass@localhost:3306/db"

        result = get_db_dialect()
        assert result == "mysql"

    @patch("src.main.app.libs.utils.project_config_util.get_db_url")
    def test_get_db_dialect_sqlite(self, mock_get_db_url):
        """Test get_db_dialect with SQLite URL."""
        mock_get_db_url.return_value = "sqlite:///./data/app.db"

        result = get_db_dialect()
        assert result == "sqlite"

    @patch("src.main.app.libs.utils.project_config_util.get_db_url")
    def test_get_db_dialect_with_driver_suffix(self, mock_get_db_url):
        """Test get_db_dialect with driver suffix."""
        mock_get_db_url.return_value = (
            "postgresql+asyncpg://user:pass@localhost:5432/db"
        )

        result = get_db_dialect()
        assert result == "postgresql"

    @patch("src.main.app.libs.utils.project_config_util.get_db_url")
    def test_get_db_dialect_unsupported_database(self, mock_get_db_url):
        """Test get_db_dialect with unsupported database."""
        mock_get_db_url.return_value = "oracle://user:pass@localhost:1521/db"

        with pytest.raises(RuntimeError, match="Unsupported database type: oracle"):
            get_db_dialect()

    @patch("src.main.app.libs.utils.project_config_util.get_db_url")
    def test_get_db_dialect_malformed_url(self, mock_get_db_url):
        """Test get_db_dialect with malformed URL."""
        mock_get_db_url.return_value = "invalid_url_format"

        # URL without '://' will be treated as unsupported database type
        with pytest.raises(
            RuntimeError, match="Unsupported database type: invalid_url_format"
        ):
            get_db_dialect()

    @patch("src.main.app.libs.utils.project_config_util.get_db_url")
    def test_get_db_dialect_empty_scheme(self, mock_get_db_url):
        """Test get_db_dialect with URL missing scheme."""
        mock_get_db_url.return_value = "://user:pass@localhost:5432/db"

        # Empty scheme will be caught as unsupported database type
        with pytest.raises(RuntimeError, match="Unsupported database type"):
            get_db_dialect()


class TestProjectInfo:
    """Test suite for ProjectInfo class."""

    def test_project_info_init_with_all_parameters(self):
        """Test ProjectInfo initialization with all parameters."""
        project_info = ProjectInfo(
            name="test-project",
            version="1.0.0",
            description="Test description",
            authors=["Author 1", "Author 2"],
        )

        assert project_info.name == "test-project"
        assert project_info.version == "1.0.0"
        assert project_info.description == "Test description"
        assert project_info.authors == ["Author 1", "Author 2"]

    def test_project_info_init_with_minimal_parameters(self):
        """Test ProjectInfo initialization with minimal parameters."""
        project_info = ProjectInfo(name="test", version="1.0.0")

        assert project_info.name == "test"
        assert project_info.version == "1.0.0"
        assert project_info.description == ""
        assert project_info.authors == []

    def test_project_info_init_with_none_values(self):
        """Test ProjectInfo initialization with None values."""
        project_info = ProjectInfo(
            name="test", version="1.0.0", description=None, authors=None
        )

        assert project_info.description == ""
        assert project_info.authors == []

    def test_from_pyproject_valid_file(self):
        """Test loading from valid pyproject.toml file."""
        toml_content = """
[project]
name = "test-project"
version = "1.0.0"
description = "Test description"
authors = [
    { name = "John Doe", email = "john@example.com" },
    { name = "Jane Smith", email = "jane@example.com" }
]
"""

        with tempfile.NamedTemporaryFile(mode="w", suffix=".toml", delete=False) as f:
            f.write(toml_content)
            temp_path = f.name

        try:
            project_info = ProjectInfo.from_pyproject(temp_path)

            assert project_info.name == "test-project"
            assert project_info.version == "1.0.0"
            assert project_info.description == "Test description"
            assert project_info.authors == ["John Doe", "Jane Smith"]
        finally:
            Path(temp_path).unlink()

    def test_from_pyproject_file_not_found(self):
        """Test FileNotFoundError when pyproject.toml doesn't exist."""
        with pytest.raises(FileNotFoundError, match="nonexistent.toml does not exist"):
            ProjectInfo.from_pyproject("nonexistent.toml")

    def test_from_pyproject_missing_project_section(self):
        """Test loading when project section is missing."""
        toml_content = """
[tool.pytest]
testpaths = ["tests"]
"""

        with tempfile.NamedTemporaryFile(mode="w", suffix=".toml", delete=False) as f:
            f.write(toml_content)
            temp_path = f.name

        try:
            project_info = ProjectInfo.from_pyproject(temp_path)

            assert project_info.name == ""
            assert project_info.version == ""
            assert project_info.description == ""
            assert project_info.authors == []
        finally:
            Path(temp_path).unlink()

    def test_from_pyproject_authors_without_names(self):
        """Test loading with authors missing name fields."""
        toml_content = """
[project]
name = "test"
version = "1.0.0"
authors = [
    { email = "noname@example.com" },
    { name = "John Doe", email = "john@example.com" },
    "invalid_author_format"
]
"""

        with tempfile.NamedTemporaryFile(mode="w", suffix=".toml", delete=False) as f:
            f.write(toml_content)
            temp_path = f.name

        try:
            project_info = ProjectInfo.from_pyproject(temp_path)

            assert project_info.authors == ["", "John Doe"]
        finally:
            Path(temp_path).unlink()

    def test_as_dict(self):
        """Test converting ProjectInfo to dictionary."""
        project_info = ProjectInfo(
            name="test",
            version="1.0.0",
            description="Test description",
            authors=["Author"],
        )

        result = project_info.as_dict()
        expected = {
            "name": "test",
            "version": "1.0.0",
            "description": "Test description",
            "authors": ["Author"],
        }

        assert result == expected

    def test_str_representation(self):
        """Test string representation of ProjectInfo."""
        project_info = ProjectInfo(
            name="test-project", version="2.0.0", description="Amazing project"
        )

        result = str(project_info)
        expected = "test-project v2.0.0 — Amazing project"

        assert result == expected

    def test_str_representation_empty_description(self):
        """Test string representation with empty description."""
        project_info = ProjectInfo(name="test", version="1.0.0", description="")

        result = str(project_info)
        expected = "test v1.0.0 — "

        assert result == expected

    @patch("src.main.app.libs.utils.project_config_util.tomllib.__name__", "tomllib")
    def test_from_pyproject_with_tomllib(self):
        """Test loading with tomllib (binary mode)."""
        toml_content = """
[project]
name = "tomllib-test"
version = "1.0.0"
"""

        with tempfile.NamedTemporaryFile(mode="w", suffix=".toml", delete=False) as f:
            f.write(toml_content)
            temp_path = f.name

        try:
            project_info = ProjectInfo.from_pyproject(temp_path)

            assert project_info.name == "tomllib-test"
            assert project_info.version == "1.0.0"
        finally:
            Path(temp_path).unlink()

    @pytest.mark.parametrize(
        "name,version,description",
        [
            ("simple", "1.0.0", "Simple project"),
            ("complex-name", "2.1.0-beta", "Complex project with special chars"),
            ("", "", ""),
        ],
    )
    def test_parametrized_project_info(self, name, version, description):
        """Parametrized test for ProjectInfo creation."""
        project_info = ProjectInfo(name=name, version=version, description=description)

        assert project_info.name == name
        assert project_info.version == version
        assert project_info.description == description
