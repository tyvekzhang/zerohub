# SPDX-License-Identifier: MIT
"""Comprehensive unit tests for schema module."""

import json
from typing import List

import pytest
from pydantic import ValidationError

from src.main.app.libs.enums.base_error_code import ExceptionCode
from src.main.app.libs.schema.response import (
    DEFAULT_FAIL_CODE,
    DEFAULT_SUCCESS_CODE,
    DEFAULT_SUCCESS_MSG,
    HttpResponse,
)
from src.main.app.libs.schema.schema import (
    CurrentUser,
    ListResult,
    PaginationRequest,
    SortItem,
    UserCredential,
)


class TestListResult:
    """Test suite for ListResult schema."""

    def test_list_result_creation_empty(self):
        """Test creating empty ListResult."""
        result = ListResult[str]()

        assert result.records == []
        assert result.total == 0

    def test_list_result_creation_with_data(self):
        """Test creating ListResult with data."""
        records = ["item1", "item2", "item3"]
        result = ListResult[str](records=records, total=100)

        assert result.records == records
        assert result.total == 100

    def test_list_result_type_safety(self):
        """Test ListResult type safety with different types."""
        # String type
        str_result = ListResult[str](records=["a", "b"], total=2)
        assert all(isinstance(item, str) for item in str_result.records)

        # Integer type
        int_result = ListResult[int](records=[1, 2, 3], total=3)
        assert all(isinstance(item, int) for item in int_result.records)

        # Dict type
        dict_result = ListResult[dict](records=[{"id": 1}, {"id": 2}], total=2)
        assert all(isinstance(item, dict) for item in dict_result.records)

    def test_list_result_serialization(self):
        """Test ListResult JSON serialization."""
        result = ListResult[dict](records=[{"id": 1, "name": "test"}], total=1)

        json_str = result.model_dump_json()
        data = json.loads(json_str)

        assert data["records"] == [{"id": 1, "name": "test"}]
        assert data["total"] == 1

    def test_list_result_deserialization(self):
        """Test ListResult JSON deserialization."""
        data = {"records": [{"id": 1}, {"id": 2}], "total": 2}

        result = ListResult[dict](**data)

        assert result.records == [{"id": 1}, {"id": 2}]
        assert result.total == 2

    def test_list_result_default_factory(self):
        """Test that records field uses default_factory."""
        result = ListResult[str](total=5)

        assert result.records == []
        assert result.total == 5

    def test_list_result_validation(self):
        """Test ListResult validation."""
        # Valid data
        result = ListResult[int](records=[1, 2, 3], total=3)
        assert len(result.records) == 3

        # Invalid total type
        with pytest.raises(ValidationError):
            ListResult[int](records=[1, 2], total="invalid")


class TestUserCredential:
    """Test suite for UserCredential schema."""

    def test_user_credential_creation(self):
        """Test creating UserCredential with all fields."""
        credential = UserCredential(
            access_token="access_token_123",
            expired_in=3600,
            refresh_token="refresh_token_456",
        )

        assert credential.access_token == "access_token_123"
        assert credential.expired_in == 3600
        assert credential.refresh_token == "refresh_token_456"

    def test_user_credential_default_expired_in(self):
        """Test UserCredential with default expired_in value."""
        credential = UserCredential(access_token="token", refresh_token="refresh")

        assert credential.expired_in == 7200  # Default value

    def test_user_credential_validation(self):
        """Test UserCredential validation."""
        # Valid creation
        credential = UserCredential(
            access_token="valid_token", refresh_token="valid_refresh"
        )
        assert credential.access_token == "valid_token"

        # Missing required fields
        with pytest.raises(ValidationError):
            UserCredential(access_token="token")  # Missing refresh_token

        with pytest.raises(ValidationError):
            UserCredential(refresh_token="refresh")  # Missing access_token

    def test_user_credential_serialization(self):
        """Test UserCredential JSON serialization."""
        credential = UserCredential(
            access_token="test_access", expired_in=1800, refresh_token="test_refresh"
        )

        json_str = credential.model_dump_json()
        data = json.loads(json_str)

        assert data["access_token"] == "test_access"
        assert data["expired_in"] == 1800
        assert data["refresh_token"] == "test_refresh"

    def test_user_credential_deserialization(self):
        """Test UserCredential JSON deserialization."""
        data = {
            "access_token": "jwt_token",
            "expired_in": 7200,
            "refresh_token": "refresh_jwt",
        }

        credential = UserCredential(**data)

        assert credential.access_token == "jwt_token"
        assert credential.expired_in == 7200
        assert credential.refresh_token == "refresh_jwt"

    def test_user_credential_type_validation(self):
        """Test UserCredential type validation."""
        # Invalid expired_in type
        with pytest.raises(ValidationError):
            UserCredential(
                access_token="token", expired_in="invalid", refresh_token="refresh"
            )


class TestCurrentUser:
    """Test suite for CurrentUser schema."""

    def test_current_user_creation(self):
        """Test creating CurrentUser."""
        user = CurrentUser(user_id=123)

        assert user.user_id == 123

    def test_current_user_validation(self):
        """Test CurrentUser validation."""
        # Valid creation
        user = CurrentUser(user_id=456)
        assert user.user_id == 456

        # Missing required field
        with pytest.raises(ValidationError):
            CurrentUser()

        # Invalid type
        with pytest.raises(ValidationError):
            CurrentUser(user_id="invalid")

    def test_current_user_serialization(self):
        """Test CurrentUser JSON serialization."""
        user = CurrentUser(user_id=789)

        json_str = user.model_dump_json()
        data = json.loads(json_str)

        assert data["user_id"] == 789

    def test_current_user_deserialization(self):
        """Test CurrentUser JSON deserialization."""
        data = {"user_id": 999}

        user = CurrentUser(**data)

        assert user.user_id == 999

    def test_current_user_zero_user_id(self):
        """Test CurrentUser with zero user_id."""
        user = CurrentUser(user_id=0)
        assert user.user_id == 0

    def test_current_user_negative_user_id(self):
        """Test CurrentUser with negative user_id."""
        user = CurrentUser(user_id=-1)
        assert user.user_id == -1


class TestSortItem:
    """Test suite for SortItem schema."""

    def test_sort_item_creation(self):
        """Test creating SortItem."""
        sort_item = SortItem(field="name", order="asc")

        assert sort_item.field == "name"
        assert sort_item.order == "asc"

    def test_sort_item_validation(self):
        """Test SortItem validation."""
        # Valid creation
        sort_item = SortItem(field="created_at", order="desc")
        assert sort_item.field == "created_at"
        assert sort_item.order == "desc"

        # Missing required fields
        with pytest.raises(ValidationError):
            SortItem(field="name")  # Missing order

        with pytest.raises(ValidationError):
            SortItem(order="asc")  # Missing field

    def test_sort_item_serialization(self):
        """Test SortItem JSON serialization."""
        sort_item = SortItem(field="email", order="asc")

        json_str = sort_item.model_dump_json()
        data = json.loads(json_str)

        assert data["field"] == "email"
        assert data["order"] == "asc"

    def test_sort_item_deserialization(self):
        """Test SortItem JSON deserialization."""
        data = {"field": "age", "order": "desc"}

        sort_item = SortItem(**data)

        assert sort_item.field == "age"
        assert sort_item.order == "desc"

    def test_sort_item_different_orders(self):
        """Test SortItem with different order values."""
        asc_sort = SortItem(field="name", order="asc")
        desc_sort = SortItem(field="name", order="desc")

        assert asc_sort.order == "asc"
        assert desc_sort.order == "desc"

    def test_sort_item_complex_field_names(self):
        """Test SortItem with complex field names."""
        # Nested field
        nested_sort = SortItem(field="user.profile.name", order="asc")
        assert nested_sort.field == "user.profile.name"

        # Field with underscore
        underscore_sort = SortItem(field="created_at", order="desc")
        assert underscore_sort.field == "created_at"


class TestPaginationRequest:
    """Test suite for PaginationRequest schema."""

    def test_pagination_request_default_values(self):
        """Test PaginationRequest with default values."""
        pagination = PaginationRequest()

        assert pagination.current == 1
        assert pagination.page_size == 10
        assert pagination.count is True
        assert pagination.sort_str is None

    def test_pagination_request_custom_values(self):
        """Test PaginationRequest with custom values."""
        pagination = PaginationRequest(
            current=2, page_size=20, count=False, sort_str="name:asc,created_at:desc"
        )

        assert pagination.current == 2
        assert pagination.page_size == 20
        assert pagination.count is False
        assert pagination.sort_str == "name:asc,created_at:desc"

    def test_pagination_request_validation_current_page(self):
        """Test PaginationRequest current page validation."""
        # Valid current page
        pagination = PaginationRequest(current=1)
        assert pagination.current == 1

        pagination = PaginationRequest(current=100)
        assert pagination.current == 100

        # Invalid current page (must be > 0)
        with pytest.raises(ValidationError):
            PaginationRequest(current=0)

        with pytest.raises(ValidationError):
            PaginationRequest(current=-1)

    def test_pagination_request_validation_page_size(self):
        """Test PaginationRequest page size validation."""
        # Valid page sizes
        pagination = PaginationRequest(page_size=1)
        assert pagination.page_size == 1

        pagination = PaginationRequest(page_size=1000)
        assert pagination.page_size == 1000

        # Invalid page sizes
        with pytest.raises(ValidationError):
            PaginationRequest(page_size=0)  # Must be >= 1

        with pytest.raises(ValidationError):
            PaginationRequest(page_size=1001)  # Must be <= 1000

        with pytest.raises(ValidationError):
            PaginationRequest(page_size=-5)

    def test_pagination_request_serialization(self):
        """Test PaginationRequest JSON serialization."""
        pagination = PaginationRequest(
            current=3, page_size=50, count=True, sort_str="id:desc"
        )

        json_str = pagination.model_dump_json()
        data = json.loads(json_str)

        assert data["current"] == 3
        assert data["page_size"] == 50
        assert data["count"] is True
        assert data["sort_str"] == "id:desc"

    def test_pagination_request_deserialization(self):
        """Test PaginationRequest JSON deserialization."""
        data = {"current": 5, "page_size": 25, "count": False, "sort_str": "name:asc"}

        pagination = PaginationRequest(**data)

        assert pagination.current == 5
        assert pagination.page_size == 25
        assert pagination.count is False
        assert pagination.sort_str == "name:asc"

    def test_pagination_request_optional_sort_str(self):
        """Test PaginationRequest with None sort_str."""
        pagination = PaginationRequest(sort_str=None)
        assert pagination.sort_str is None

        # Empty string should also work
        pagination = PaginationRequest(sort_str="")
        assert pagination.sort_str == ""


class TestHttpResponse:
    """Test suite for HttpResponse schema."""

    def test_http_response_default_values(self):
        """Test HttpResponse with default values."""
        response = HttpResponse()

        assert response.code == DEFAULT_SUCCESS_CODE
        assert response.message == DEFAULT_SUCCESS_MSG
        assert response.data is None

    def test_http_response_custom_values(self):
        """Test HttpResponse with custom values."""
        data = {"key": "value"}
        response = HttpResponse(code=200, message="OK", data=data)

        assert response.code == 200
        assert response.message == "OK"
        assert response.data == data

    def test_http_response_serialization_with_data(self):
        """Test HttpResponse serialization when data is present."""
        data = {"items": [1, 2, 3], "count": 3}
        response = HttpResponse(code=0, message="success", data=data)

        serialized = response.serialize_model()

        assert serialized["code"] == 0
        assert serialized["message"] == "success"
        assert serialized["data"] == data

    def test_http_response_serialization_without_data(self):
        """Test HttpResponse serialization when data is None."""
        response = HttpResponse(code=0, message="success", data=None)

        serialized = response.serialize_model()

        assert serialized["code"] == 0
        assert serialized["message"] == "success"
        assert "data" not in serialized  # Should be excluded when None

    def test_http_response_success_factory(self):
        """Test HttpResponse.success() factory method."""
        # Success without data
        response = HttpResponse.success()

        assert response.code == DEFAULT_SUCCESS_CODE
        assert response.message == DEFAULT_SUCCESS_MSG
        assert response.data is None

        # Success with data
        data = {"result": "success"}
        response = HttpResponse.success(data=data)

        assert response.code == DEFAULT_SUCCESS_CODE
        assert response.message == DEFAULT_SUCCESS_MSG
        assert response.data == data

        # Success with custom code and message
        response = HttpResponse.success(data="test", code=201, message="Created")

        assert response.code == 201
        assert response.message == "Created"
        assert response.data == "test"

    def test_http_response_fail_factory(self):
        """Test HttpResponse.fail() factory method."""
        # Fail with explicit message (since default str causes validation error)
        response = HttpResponse.fail(message="Error")

        assert response.code == DEFAULT_FAIL_CODE
        assert response.message == "Error"
        assert response.data is None

        # Fail with custom message
        response = HttpResponse.fail(message="Error occurred")

        assert response.code == DEFAULT_FAIL_CODE
        assert response.message == "Error occurred"
        assert response.data is None

        # Fail with custom code and data
        error_data = {"error_type": "validation"}
        response = HttpResponse.fail(
            message="Validation failed", code=400, data=error_data
        )

        assert response.code == 400
        assert response.message == "Validation failed"
        assert response.data == error_data

    def test_http_response_fail_with_error_exception_code(self):
        """Test HttpResponse.fail_with_error() with ExceptionCode."""
        error_code = ExceptionCode(code=404, message="Not found")

        response = HttpResponse.fail_with_error(error=error_code)

        assert response.code == 404
        assert response.message == "Not found"
        assert response.data is None

    def test_http_response_fail_with_error_tuple(self):
        """Test HttpResponse.fail_with_error() with tuple."""
        error_tuple = (500, "Internal server error")

        response = HttpResponse.fail_with_error(error=error_tuple)

        assert response.code == 500
        assert response.message == "Internal server error"
        assert response.data is None

    def test_http_response_fail_with_error_extra_msg(self):
        """Test HttpResponse.fail_with_error() with extra message."""
        error_code = ExceptionCode(code=400, message="Bad request")
        extra_msg = "Invalid email format"

        response = HttpResponse.fail_with_error(error=error_code, extra_msg=extra_msg)

        assert response.code == 400
        assert response.message == "Bad request: Invalid email format"
        assert response.data is None

    def test_http_response_fail_with_error_invalid_type(self):
        """Test HttpResponse.fail_with_error() with invalid error type."""
        invalid_error = "simple string error"

        response = HttpResponse.fail_with_error(error=invalid_error)

        assert response.code == DEFAULT_FAIL_CODE
        assert response.message == "simple string error"
        assert response.data is None

    def test_http_response_fail_with_error_tuple_wrong_length(self):
        """Test HttpResponse.fail_with_error() with tuple of wrong length."""
        invalid_tuple = (400,)  # Missing message

        response = HttpResponse.fail_with_error(error=invalid_tuple)

        assert response.code == DEFAULT_FAIL_CODE
        assert response.message == str(invalid_tuple)
        assert response.data is None

    def test_http_response_type_safety(self):
        """Test HttpResponse type safety with generic types."""
        # String type
        str_response = HttpResponse[str](data="string data")
        assert isinstance(str_response.data, str)

        # List type
        list_response = HttpResponse[list[int]](data=[1, 2, 3])
        assert isinstance(list_response.data, list)

        # Dict type
        dict_response = HttpResponse[dict](data={"key": "value"})
        assert isinstance(dict_response.data, dict)

    def test_http_response_json_serialization(self):
        """Test HttpResponse JSON serialization."""
        data = {"items": ["a", "b"], "total": 2}
        response = HttpResponse(code=200, message="OK", data=data)

        json_str = response.model_dump_json()
        parsed = json.loads(json_str)

        assert parsed["code"] == 200
        assert parsed["message"] == "OK"
        assert parsed["data"] == data

    def test_http_response_model_serializer_none_data(self):
        """Test that model_serializer excludes None data."""
        response = HttpResponse(code=204, message="No Content", data=None)

        # Using model_dump should use the custom serializer
        serialized = response.model_dump()

        assert "data" not in serialized
        assert serialized == {"code": 204, "message": "No Content"}


class TestSchemaIntegration:
    """Integration tests for schema interactions."""

    def test_list_result_with_user_credentials(self):
        """Test ListResult containing UserCredential objects."""
        credentials = [
            UserCredential(access_token="token1", refresh_token="refresh1"),
            UserCredential(access_token="token2", refresh_token="refresh2"),
        ]

        result = ListResult[UserCredential](records=credentials, total=2)

        assert len(result.records) == 2
        assert all(isinstance(cred, UserCredential) for cred in result.records)
        assert result.total == 2

    def test_http_response_with_list_result(self):
        """Test HttpResponse containing ListResult."""
        users = [CurrentUser(user_id=1), CurrentUser(user_id=2)]
        list_result = ListResult[CurrentUser](records=users, total=10)

        response = HttpResponse.success(data=list_result)

        assert response.code == DEFAULT_SUCCESS_CODE
        assert isinstance(response.data, ListResult)
        assert len(response.data.records) == 2

    def test_pagination_with_sort_items(self):
        """Test using PaginationRequest with SortItem objects."""
        # This would be in a real API where sort_str is parsed into SortItem objects
        pagination = PaginationRequest(
            current=2, page_size=20, sort_str="name:asc,created_at:desc"
        )

        # Simulate parsing sort_str into SortItem objects
        sort_items = [
            SortItem(field="name", order="asc"),
            SortItem(field="created_at", order="desc"),
        ]

        assert pagination.current == 2
        assert pagination.page_size == 20
        assert len(sort_items) == 2
        assert sort_items[0].field == "name"
        assert sort_items[1].order == "desc"

    def test_error_response_with_validation_errors(self):
        """Test creating error responses for validation errors."""
        try:
            # This should raise ValidationError
            PaginationRequest(current=0, page_size=2000)
        except ValidationError as e:
            error_response = HttpResponse.fail(
                message="Validation failed",
                code=422,
                data={"validation_errors": str(e.errors())},
            )

            assert error_response.code == 422
            assert "Validation failed" in error_response.message
            assert "validation_errors" in error_response.data

    def test_complete_api_response_workflow(self):
        """Test complete API response workflow with all schemas."""
        # Simulate API endpoint that returns paginated user list
        users = [CurrentUser(user_id=1), CurrentUser(user_id=2), CurrentUser(user_id=3)]

        # Create list result
        list_result = ListResult[CurrentUser](records=users, total=100)

        # Create success response
        response = HttpResponse.success(
            data=list_result, message="Users retrieved successfully"
        )

        # Serialize to JSON (simulating API response)
        json_data = response.model_dump()

        assert json_data["code"] == 0
        assert json_data["message"] == "Users retrieved successfully"
        assert json_data["data"]["total"] == 100
        assert len(json_data["data"]["records"]) == 3
        assert json_data["data"]["records"][0]["user_id"] == 1
