# SPDX-License-Identifier: MIT
"""Abstract base class for Cache"""

from abc import ABC, abstractmethod
from typing import Any, Union


class Cache(ABC):
    @abstractmethod
    async def get(self, key: str) -> Any:
        """Retrieve a value by key from the cache."""

        raise NotImplementedError

    @abstractmethod
    async def set(self, key: str, value: Any, timeout=None) -> None:
        """Set the value of a key in the cache with an optional timeout."""

        raise NotImplementedError

    @abstractmethod
    async def delete(self, key: str) -> None:
        """Delete a key from the cache."""

        raise NotImplementedError

    @abstractmethod
    async def exists(self, key: str) -> bool:
        """Check if a key exists in the cache."""

        raise NotImplementedError

    # List operations
    @abstractmethod
    async def lpush(self, key: str, *values: Any) -> int:
        """Push one or more values to the left (head) of a list.

        Args:
            key: The list key
            values: Values to push

        Returns:
            The length of the list after the push operation
        """
        raise NotImplementedError

    @abstractmethod
    async def rpush(self, key: str, *values: Any) -> int:
        """Push one or more values to the right (tail) of a list.

        Args:
            key: The list key
            values: Values to push

        Returns:
            The length of the list after the push operation
        """
        raise NotImplementedError

    @abstractmethod
    async def lpop(self, key: str, count: int = 1) -> Union[Any, list[Any], None]:
        """Remove and return elements from the left (head) of a list.

        Args:
            key: The list key
            count: Number of elements to pop

        Returns:
            Single element if count=1, list of elements if count>1, None if list is empty
        """
        raise NotImplementedError

    @abstractmethod
    async def rpop(self, key: str, count: int = 1) -> Union[Any, list[Any], None]:
        """Remove and return elements from the right (tail) of a list.

        Args:
            key: The list key
            count: Number of elements to pop

        Returns:
            Single element if count=1, list of elements if count>1, None if list is empty
        """
        raise NotImplementedError

    @abstractmethod
    async def llen(self, key: str) -> int:
        """Get the length of a list.

        Args:
            key: The list key

        Returns:
            The length of the list, 0 if the key doesn't exist
        """
        raise NotImplementedError

    @abstractmethod
    async def lindex(self, key: str, index: int) -> Any:
        """Get an element from a list by its index.

        Args:
            key: The list key
            index: The index (0-based, negative values count from the end)

        Returns:
            The element at the specified index, None if index is out of range
        """
        raise NotImplementedError

    @abstractmethod
    async def lrange(self, key: str, start: int = 0, end: int = -1) -> list[Any]:
        """Get a range of elements from a list.

        Args:
            key: The list key
            start: Start index (0-based, inclusive)
            end: End index (0-based, inclusive, -1 means the last element)

        Returns:
            List of elements in the specified range
        """
        raise NotImplementedError

    @abstractmethod
    async def lset(self, key: str, index: int, value: Any) -> bool:
        """Set the value of an element in a list by its index.

        Args:
            key: The list key
            index: The index to set
            value: The new value

        Returns:
            True if successful, False if index is out of range
        """
        raise NotImplementedError

    @abstractmethod
    async def lrem(self, key: str, count: int, value: Any) -> int:
        """Remove elements from a list.

        Args:
            key: The list key
            count: Number of elements to remove (0 = all, >0 = from head, <0 = from tail)
            value: The value to remove

        Returns:
            The number of elements removed
        """
        raise NotImplementedError

    @abstractmethod
    async def ltrim(self, key: str, start: int, end: int) -> bool:
        """Trim a list to the specified range.

        Args:
            key: The list key
            start: Start index (inclusive)
            end: End index (inclusive)

        Returns:
            True if successful
        """
        raise NotImplementedError
