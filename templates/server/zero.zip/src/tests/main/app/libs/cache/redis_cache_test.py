# SPDX-License-Identifier: MIT

from unittest.mock import AsyncMock, Mock, patch

import pytest

# Try to import RedisCache and related components
try:
    from src.main.app.libs.cache.redis_cache import RedisCache, RedisManager

    REDIS_AVAILABLE = True
except (ImportError, RuntimeError):
    REDIS_AVAILABLE = False
    RedisCache = None
    RedisManager = None


@pytest.mark.skipif(not REDIS_AVAILABLE, reason="Redis module not available")
class TestRedisCache:
    """Test suite for RedisCache implementation."""

    @pytest.fixture
    def mock_redis_client(self):
        """Create a mock Redis client."""
        return AsyncMock()

    @pytest.fixture
    def redis_cache(self, mock_redis_client):
        """Create a RedisCache instance with mock client."""
        # Mock the redis module check to bypass the availability check
        with patch("src.main.app.libs.cache.redis_cache.redis", True):
            return RedisCache(mock_redis_client)

    # Basic cache operations tests
    @pytest.mark.asyncio
    async def test_get_operation(self, redis_cache, mock_redis_client):
        """Test get operation."""
        mock_redis_client.get.return_value = "test_value"

        result = await redis_cache.get("test_key")

        assert result == "test_value"
        mock_redis_client.get.assert_called_once_with("test_key")

    @pytest.mark.asyncio
    async def test_set_operation_without_timeout(self, redis_cache, mock_redis_client):
        """Test set operation without timeout."""
        await redis_cache.set("test_key", "test_value")

        mock_redis_client.set.assert_called_once_with("test_key", "test_value")

    @pytest.mark.asyncio
    async def test_set_operation_with_timeout(self, redis_cache, mock_redis_client):
        """Test set operation with timeout."""
        await redis_cache.set("test_key", "test_value", timeout=60)

        mock_redis_client.setex.assert_called_once_with("test_key", 60, "test_value")

    @pytest.mark.asyncio
    async def test_delete_operation(self, redis_cache, mock_redis_client):
        """Test delete operation."""
        mock_redis_client.delete.return_value = 1

        result = await redis_cache.delete("test_key")

        assert result == 1
        mock_redis_client.delete.assert_called_once_with("test_key")

    @pytest.mark.asyncio
    async def test_exists_operation(self, redis_cache, mock_redis_client):
        """Test exists operation."""
        mock_redis_client.exists.return_value = 1

        result = await redis_cache.exists("test_key")

        assert result == 1
        mock_redis_client.exists.assert_called_once_with("test_key")

    # List operations tests
    @pytest.mark.asyncio
    async def test_lpush_operation(self, redis_cache, mock_redis_client):
        """Test lpush operation."""
        mock_redis_client.lpush.return_value = 3

        result = await redis_cache.lpush("test_list", "value1", "value2", "value3")

        assert result == 3
        mock_redis_client.lpush.assert_called_once_with(
            "test_list", "value1", "value2", "value3"
        )

    @pytest.mark.asyncio
    async def test_rpush_operation(self, redis_cache, mock_redis_client):
        """Test rpush operation."""
        mock_redis_client.rpush.return_value = 2

        result = await redis_cache.rpush("test_list", "value1", "value2")

        assert result == 2
        mock_redis_client.rpush.assert_called_once_with("test_list", "value1", "value2")

    @pytest.mark.asyncio
    async def test_lpop_single_element(self, redis_cache, mock_redis_client):
        """Test lpop single element."""
        mock_redis_client.lpop.return_value = "value1"

        result = await redis_cache.lpop("test_list")

        assert result == "value1"
        mock_redis_client.lpop.assert_called_once_with("test_list")

    @pytest.mark.asyncio
    async def test_lpop_multiple_elements(self, redis_cache, mock_redis_client):
        """Test lpop multiple elements."""
        mock_redis_client.lpop.return_value = ["value1", "value2"]

        result = await redis_cache.lpop("test_list", count=2)

        assert result == ["value1", "value2"]
        mock_redis_client.lpop.assert_called_once_with("test_list", 2)

    @pytest.mark.asyncio
    async def test_rpop_single_element(self, redis_cache, mock_redis_client):
        """Test rpop single element."""
        mock_redis_client.rpop.return_value = "value3"

        result = await redis_cache.rpop("test_list")

        assert result == "value3"
        mock_redis_client.rpop.assert_called_once_with("test_list")

    @pytest.mark.asyncio
    async def test_rpop_multiple_elements(self, redis_cache, mock_redis_client):
        """Test rpop multiple elements."""
        mock_redis_client.rpop.return_value = ["value3", "value2"]

        result = await redis_cache.rpop("test_list", count=2)

        assert result == ["value3", "value2"]
        mock_redis_client.rpop.assert_called_once_with("test_list", 2)

    @pytest.mark.asyncio
    async def test_llen_operation(self, redis_cache, mock_redis_client):
        """Test llen operation."""
        mock_redis_client.llen.return_value = 5

        result = await redis_cache.llen("test_list")

        assert result == 5
        mock_redis_client.llen.assert_called_once_with("test_list")

    @pytest.mark.asyncio
    async def test_lindex_operation(self, redis_cache, mock_redis_client):
        """Test lindex operation."""
        mock_redis_client.lindex.return_value = "value2"

        result = await redis_cache.lindex("test_list", 1)

        assert result == "value2"
        mock_redis_client.lindex.assert_called_once_with("test_list", 1)

    @pytest.mark.asyncio
    async def test_lrange_operation(self, redis_cache, mock_redis_client):
        """Test lrange operation."""
        mock_redis_client.lrange.return_value = ["value1", "value2", "value3"]

        result = await redis_cache.lrange("test_list", 0, 2)

        assert result == ["value1", "value2", "value3"]
        mock_redis_client.lrange.assert_called_once_with("test_list", 0, 2)

    @pytest.mark.asyncio
    async def test_lrange_default_parameters(self, redis_cache, mock_redis_client):
        """Test lrange with default parameters."""
        mock_redis_client.lrange.return_value = ["value1", "value2"]

        result = await redis_cache.lrange("test_list")

        assert result == ["value1", "value2"]
        mock_redis_client.lrange.assert_called_once_with("test_list", 0, -1)

    @pytest.mark.asyncio
    async def test_lset_successful(self, redis_cache, mock_redis_client):
        """Test lset successful operation."""
        mock_redis_client.lset.return_value = None  # Redis lset returns None on success

        result = await redis_cache.lset("test_list", 1, "new_value")

        assert result is True
        mock_redis_client.lset.assert_called_once_with("test_list", 1, "new_value")

    @pytest.mark.asyncio
    async def test_lset_with_exception(self, redis_cache, mock_redis_client):
        """Test lset operation that raises exception."""
        mock_redis_client.lset.side_effect = Exception("Index out of range")

        result = await redis_cache.lset("test_list", 10, "new_value")

        assert result is False
        mock_redis_client.lset.assert_called_once_with("test_list", 10, "new_value")

    @pytest.mark.asyncio
    async def test_lrem_operation(self, redis_cache, mock_redis_client):
        """Test lrem operation."""
        mock_redis_client.lrem.return_value = 2

        result = await redis_cache.lrem("test_list", 0, "value_to_remove")

        assert result == 2
        mock_redis_client.lrem.assert_called_once_with(
            "test_list", 0, "value_to_remove"
        )

    @pytest.mark.asyncio
    async def test_ltrim_successful(self, redis_cache, mock_redis_client):
        """Test ltrim successful operation."""
        mock_redis_client.ltrim.return_value = (
            None  # Redis ltrim returns None on success
        )

        result = await redis_cache.ltrim("test_list", 1, 3)

        assert result is True
        mock_redis_client.ltrim.assert_called_once_with("test_list", 1, 3)

    @pytest.mark.asyncio
    async def test_ltrim_with_exception(self, redis_cache, mock_redis_client):
        """Test ltrim operation that raises exception."""
        mock_redis_client.ltrim.side_effect = Exception("Operation failed")

        result = await redis_cache.ltrim("test_list", 1, 3)

        assert result is False
        mock_redis_client.ltrim.assert_called_once_with("test_list", 1, 3)

    # Constructor tests
    def test_redis_cache_constructor_without_redis_module(self):
        """Test RedisCache constructor when redis module is not available."""
        mock_client = Mock()

        with patch("src.main.app.libs.cache.redis_cache.redis", None):
            with pytest.raises(RuntimeError, match="Redis module is not available"):
                RedisCache(mock_client)

    def test_redis_cache_constructor_with_redis_module(self, mock_redis_client):
        """Test RedisCache constructor when redis module is available."""
        with patch("src.main.app.libs.cache.redis_cache.redis", True):
            cache = RedisCache(mock_redis_client)
            assert cache.redis_client == mock_redis_client


@pytest.mark.skipif(not REDIS_AVAILABLE, reason="Redis module not available")
class TestRedisManager:
    """Test suite for RedisManager singleton."""

    def setup_method(self):
        """Reset RedisManager state before each test."""
        RedisManager._instance = None
        RedisManager._connection_pool = None

    @pytest.mark.asyncio
    async def test_get_instance_creates_singleton(self):
        """Test that get_instance creates a singleton instance."""
        with patch("src.main.app.libs.cache.redis_cache.redis") as mock_redis_module:
            with patch(
                "src.main.app.libs.cache.redis_cache.load_config"
            ) as mock_load_config:
                # Mock configuration
                mock_config = Mock()
                mock_config.database.cache_pass = "password"
                mock_config.database.cache_host = "localhost"
                mock_config.database.cache_port = 6379
                mock_config.database.db_num = 0
                mock_load_config.return_value = mock_config

                # Mock Redis components
                mock_pool = Mock()
                mock_redis_module.ConnectionPool.from_url.return_value = mock_pool
                mock_redis_instance = AsyncMock()
                mock_redis_module.Redis.from_pool = AsyncMock(
                    return_value=mock_redis_instance
                )

                # First call
                instance1 = await RedisManager.get_instance()

                # Second call should return same instance
                instance2 = await RedisManager.get_instance()

                assert instance1 == instance2
                assert instance1 == mock_redis_instance

                # Verify connection pool was created only once
                mock_redis_module.ConnectionPool.from_url.assert_called_once()

    @pytest.mark.asyncio
    async def test_get_instance_handles_missing_redis_module(self):
        """Test that get_instance handles missing redis module properly."""
        with patch("src.main.app.libs.cache.redis_cache.redis", None):
            with pytest.raises(RuntimeError, match="Redis module is not available"):
                await RedisManager.get_instance()

    @pytest.mark.asyncio
    async def test_get_instance_creates_connection_pool_with_correct_url(self):
        """Test that get_instance creates connection pool with correct URL."""
        with patch("src.main.app.libs.cache.redis_cache.redis") as mock_redis_module:
            with patch(
                "src.main.app.libs.cache.redis_cache.load_config"
            ) as mock_load_config:
                # Mock configuration
                mock_config = Mock()
                mock_config.database.cache_pass = "test_password"
                mock_config.database.cache_host = "redis.example.com"
                mock_config.database.cache_port = 6380
                mock_config.database.db_num = 2
                mock_load_config.return_value = mock_config

                # Mock Redis components
                mock_pool = Mock()
                mock_redis_module.ConnectionPool.from_url.return_value = mock_pool
                mock_redis_instance = AsyncMock()
                mock_redis_module.Redis.from_pool = AsyncMock(
                    return_value=mock_redis_instance
                )

                await RedisManager.get_instance()

                expected_url = "redis://:test_password@redis.example.com:6380/2"
                mock_redis_module.ConnectionPool.from_url.assert_called_once_with(
                    expected_url, decode_responses=True
                )

    @pytest.mark.asyncio
    async def test_get_instance_thread_safety(self):
        """Test that get_instance is thread-safe using the lock."""
        import asyncio

        with patch("src.main.app.libs.cache.redis_cache.redis") as mock_redis_module:
            with patch(
                "src.main.app.libs.cache.redis_cache.load_config"
            ) as mock_load_config:
                # Mock configuration
                mock_config = Mock()
                mock_config.database.cache_pass = "password"
                mock_config.database.cache_host = "localhost"
                mock_config.database.cache_port = 6379
                mock_config.database.db_num = 0
                mock_load_config.return_value = mock_config

                # Mock Redis components
                mock_pool = Mock()
                mock_redis_module.ConnectionPool.from_url.return_value = mock_pool
                mock_redis_instance = AsyncMock()
                mock_redis_module.Redis.from_pool = AsyncMock(
                    return_value=mock_redis_instance
                )

                # Create multiple concurrent calls
                tasks = [RedisManager.get_instance() for _ in range(5)]
                instances = await asyncio.gather(*tasks)

                # All instances should be the same
                assert all(instance == instances[0] for instance in instances)

                # Connection pool should be created only once
                mock_redis_module.ConnectionPool.from_url.assert_called_once()


class TestRedisNotAvailable:
    """Test behavior when Redis is not available."""

    def test_redis_cache_import_failure(self):
        """Test that the module handles Redis import failure gracefully."""
        # This test verifies that the module can be imported even when Redis is not available
        # The actual import behavior is already tested by the module structure
        assert True  # If we reach here, the import didn't fail catastrophically

    @pytest.mark.skipif(REDIS_AVAILABLE, reason="Redis is available, test not needed")
    def test_redis_not_available_skip_behavior(self):
        """Test that tests are properly skipped when Redis is not available."""
        # This test only runs when Redis is NOT available
        # It verifies our skip logic works correctly
        assert not REDIS_AVAILABLE
