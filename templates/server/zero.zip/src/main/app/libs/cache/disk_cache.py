# SPDX-License-Identifier: MIT
"""Simple in-memory page cache implementation"""

import json
from typing import Any, Union

import diskcache

from src.main.app.libs.cache.base_cache import Cache


class PageCache(Cache):
    def __init__(self):
        self.cache = diskcache.Cache()

    async def get(self, key: str) -> Any:
        """Retrieve a value by key from the in-memory cache."""
        return self.cache.get(key)

    async def set(self, key: str, value: Any, timeout: int = None) -> None:
        """Set the value for a key in the in-memory cache."""
        if timeout:
            self.cache.set(key, value, timeout)
        else:
            self.cache.set(key, value)

    async def delete(self, key: str) -> None:
        """Delete a key from the in-memory cache."""
        if key in self.cache:
            self.cache.delete(key)

    async def exists(self, key: str) -> bool:
        """Check if a key exists in the in-memory cache."""
        if key in self.cache:
            return True
        return False

    # List operations - implemented using JSON serialization
    def _get_list(self, key: str) -> list[Any]:
        """Helper method to get a list from cache, creating empty list if not exists."""
        data = self.cache.get(key)
        if data is None:
            return []
        if isinstance(data, str):
            try:
                return json.loads(data)
            except (json.JSONDecodeError, TypeError):
                return []
        elif isinstance(data, list):
            return data
        else:
            return []

    def _set_list(self, key: str, value: list[Any], timeout: int = None) -> None:
        """Helper method to store a list in cache."""
        serialized = json.dumps(value)
        if timeout:
            self.cache.set(key, serialized, timeout)
        else:
            self.cache.set(key, serialized)

    async def lpush(self, key: str, *values: Any) -> int:
        """Push one or more values to the left (head) of a list."""
        current_list = self._get_list(key)
        # Insert each value at the beginning (left), one by one
        for value in values:
            current_list.insert(0, value)
        self._set_list(key, current_list)
        return len(current_list)

    async def rpush(self, key: str, *values: Any) -> int:
        """Push one or more values to the right (tail) of a list."""
        current_list = self._get_list(key)
        current_list.extend(values)
        self._set_list(key, current_list)
        return len(current_list)

    async def lpop(self, key: str, count: int = 1) -> Union[Any, list[Any], None]:
        """Remove and return elements from the left (head) of a list."""
        current_list = self._get_list(key)
        if not current_list:
            return None

        if count == 1:
            result = current_list.pop(0)
            self._set_list(key, current_list)
            return result
        else:
            result = []
            for _ in range(min(count, len(current_list))):
                if current_list:
                    result.append(current_list.pop(0))
            self._set_list(key, current_list)
            return result if result else None

    async def rpop(self, key: str, count: int = 1) -> Union[Any, list[Any], None]:
        """Remove and return elements from the right (tail) of a list."""
        current_list = self._get_list(key)
        if not current_list:
            return None

        if count == 1:
            result = current_list.pop()
            self._set_list(key, current_list)
            return result
        else:
            result = []
            for _ in range(min(count, len(current_list))):
                if current_list:
                    result.append(current_list.pop())
            self._set_list(key, current_list)
            return result[::-1] if result else None  # Reverse to match Redis behavior

    async def llen(self, key: str) -> int:
        """Get the length of a list."""
        current_list = self._get_list(key)
        return len(current_list)

    async def lindex(self, key: str, index: int) -> Any:
        """Get an element from a list by its index."""
        current_list = self._get_list(key)
        try:
            return current_list[index]
        except IndexError:
            return None

    async def lrange(self, key: str, start: int = 0, end: int = -1) -> list[Any]:
        """Get a range of elements from a list."""
        current_list = self._get_list(key)
        if not current_list:
            return []

        # Handle negative indices
        if end == -1:
            end = len(current_list) - 1

        try:
            return current_list[start : end + 1]
        except IndexError:
            return []

    async def lset(self, key: str, index: int, value: Any) -> bool:
        """Set the value of an element in a list by its index."""
        current_list = self._get_list(key)
        try:
            current_list[index] = value
            self._set_list(key, current_list)
            return True
        except IndexError:
            return False

    async def lrem(self, key: str, count: int, value: Any) -> int:
        """Remove elements from a list."""
        current_list = self._get_list(key)
        removed_count = 0

        if count == 0:
            # Remove all occurrences
            original_length = len(current_list)
            current_list[:] = [item for item in current_list if item != value]
            removed_count = original_length - len(current_list)
        elif count > 0:
            # Remove from head
            i = 0
            while i < len(current_list) and removed_count < count:
                if current_list[i] == value:
                    current_list.pop(i)
                    removed_count += 1
                else:
                    i += 1
        else:
            # Remove from tail
            count = abs(count)
            i = len(current_list) - 1
            while i >= 0 and removed_count < count:
                if current_list[i] == value:
                    current_list.pop(i)
                    removed_count += 1
                i -= 1

        self._set_list(key, current_list)
        return removed_count

    async def ltrim(self, key: str, start: int, end: int) -> bool:
        """Trim a list to the specified range."""
        current_list = self._get_list(key)
        try:
            if end == -1:
                end = len(current_list) - 1
            trimmed_list = current_list[start : end + 1]
            self._set_list(key, trimmed_list)
            return True
        except Exception:
            return False
