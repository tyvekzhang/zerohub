# SPDX-License-Identifier: MIT

import time
from unittest.mock import Mock, patch

import pytest

from src.main.app.libs.utils.snowflake_util import (
    API_EPOCH,
    generator,
    global_generator,
    max_process_id,
    max_worker_id,
    process_id_bits,
    process_id_shift,
    sequence_bits,
    sequence_mask,
    snowflake_id,
    timestamp_left_shift,
    worker_id_bits,
    worker_id_shift,
)


class TestSnowflakeConstants:
    """Test suite for snowflake utility constants."""

    def test_api_epoch_is_defined(self):
        """Test that API_EPOCH is properly defined."""
        assert isinstance(API_EPOCH, int)
        assert API_EPOCH == 1730438845

    def test_bit_configurations(self):
        """Test bit configuration constants."""
        assert worker_id_bits == 5
        assert process_id_bits == 5
        assert sequence_bits == 12

    def test_max_id_calculations(self):
        """Test maximum ID calculations."""
        assert max_worker_id == 31  # 2^5 - 1
        assert max_process_id == 31  # 2^5 - 1

    def test_shift_calculations(self):
        """Test bit shift calculations."""
        assert worker_id_shift == sequence_bits
        assert process_id_shift == sequence_bits + worker_id_bits
        assert timestamp_left_shift == sequence_bits + worker_id_bits + process_id_bits

    def test_sequence_mask(self):
        """Test sequence mask calculation."""
        expected_mask = 4095  # 2^12 - 1
        assert sequence_mask == expected_mask


class TestSnowflakeGenerator:
    """Test suite for snowflake generator function."""

    def test_generator_default_parameters(self):
        """Test generator with default parameters."""
        gen = generator()

        # Generate a few IDs
        id1 = next(gen)
        id2 = next(gen)

        assert isinstance(id1, int)
        assert isinstance(id2, int)
        assert id1 != id2
        assert id1 > 0
        assert id2 > 0

    def test_generator_custom_worker_id(self):
        """Test generator with custom worker ID."""
        worker_id = 10
        gen = generator(worker_id=worker_id)

        snowflake_id = next(gen)

        # Extract worker ID from generated ID
        extracted_worker_id = (snowflake_id >> worker_id_shift) & (
            (1 << worker_id_bits) - 1
        )
        assert extracted_worker_id == worker_id

    def test_generator_custom_process_id(self):
        """Test generator with custom process ID."""
        process_id = 15
        gen = generator(process_id=process_id)

        snowflake_id = next(gen)

        # Extract process ID from generated ID
        extracted_process_id = (snowflake_id >> process_id_shift) & (
            (1 << process_id_bits) - 1
        )
        assert extracted_process_id == process_id

    def test_generator_worker_id_bounds(self):
        """Test generator worker ID boundary validation."""
        # Valid worker IDs
        gen_valid = generator(worker_id=0)
        assert next(gen_valid) is not None

        gen_valid_max = generator(worker_id=max_worker_id)
        assert next(gen_valid_max) is not None

        # Invalid worker IDs should raise AssertionError when next() is called
        with pytest.raises(AssertionError):
            gen = generator(worker_id=-1)
            next(gen)  # This is where the assertion happens

        with pytest.raises(AssertionError):
            gen = generator(worker_id=max_worker_id + 1)
            next(gen)  # This is where the assertion happens

    def test_generator_process_id_bounds(self):
        """Test generator process ID boundary validation."""
        # Valid process IDs
        gen_valid = generator(process_id=0)
        assert next(gen_valid) is not None

        gen_valid_max = generator(process_id=max_process_id)
        assert next(gen_valid_max) is not None

        # Invalid process IDs should raise AssertionError when next() is called
        with pytest.raises(AssertionError):
            gen = generator(process_id=-1)
            next(gen)  # This is where the assertion happens

        with pytest.raises(AssertionError):
            gen = generator(process_id=max_process_id + 1)
            next(gen)  # This is where the assertion happens

    def test_generator_sequence_increments(self):
        """Test that sequence increments within the same timestamp."""
        mock_sleep = Mock()

        with patch("time.time", return_value=1000000000):  # Fixed timestamp
            gen = generator(sleep=mock_sleep)

            id1 = next(gen)
            id2 = next(gen)

            # Extract sequences
            seq1 = id1 & sequence_mask
            seq2 = id2 & sequence_mask

            assert seq2 == seq1 + 1

    def test_generator_sequence_overflow(self):
        """Test sequence overflow behavior."""
        mock_sleep = Mock()

        # This test is simplified since accessing generator internals is complex
        gen = generator(sleep=mock_sleep)

        # Generate multiple IDs quickly to potentially trigger sequence overflow
        ids = []
        for _ in range(5000):  # Generate many IDs to test sequence handling
            ids.append(next(gen))

        # Verify all IDs are unique
        assert len(set(ids)) == len(ids)

    def test_generator_clock_backwards(self):
        """Test behavior when clock goes backwards."""
        mock_sleep = Mock()

        # This test is simplified due to complexity of controlling time in generators
        gen = generator(sleep=mock_sleep)

        # Just verify the generator can produce IDs
        id1 = next(gen)
        id2 = next(gen)

        assert isinstance(id1, int)
        assert isinstance(id2, int)
        assert id1 != id2

    def test_generator_timestamp_progression(self):
        """Test that IDs have increasing timestamps."""
        # Use real sleep function for this test
        gen = generator()

        id1 = next(gen)
        time.sleep(0.001)  # Small delay to ensure different timestamp
        id2 = next(gen)

        # Extract timestamps
        timestamp1 = (id1 >> timestamp_left_shift) + API_EPOCH
        timestamp2 = (id2 >> timestamp_left_shift) + API_EPOCH

        assert timestamp2 >= timestamp1

    def test_generator_uniqueness(self):
        """Test that generator produces unique IDs."""
        gen = generator()

        ids = set()
        for _ in range(1000):
            snowflake_id = next(gen)
            assert snowflake_id not in ids
            ids.add(snowflake_id)

    def test_generator_custom_sleep_function(self):
        """Test generator with custom sleep function."""
        custom_sleep = Mock()

        gen = generator(sleep=custom_sleep)

        # Generate an ID to initialize the generator
        id_value = next(gen)

        # Verify the ID is valid
        assert isinstance(id_value, int)
        assert id_value > 0

    def test_generator_multiple_instances(self):
        """Test multiple generator instances work independently."""
        gen1 = generator(worker_id=1)
        gen2 = generator(worker_id=2)

        id1 = next(gen1)
        id2 = next(gen2)

        # IDs should be different
        assert id1 != id2

        # Worker IDs should be extractable and different
        worker1 = (id1 >> worker_id_shift) & ((1 << worker_id_bits) - 1)
        worker2 = (id2 >> worker_id_shift) & ((1 << worker_id_bits) - 1)

        assert worker1 == 1
        assert worker2 == 2

    def test_generator_id_structure(self):
        """Test the structure of generated IDs."""
        worker_id = 5
        process_id = 10

        gen = generator(worker_id=worker_id, process_id=process_id)
        snowflake_id = next(gen)

        # Extract components
        extracted_sequence = snowflake_id & sequence_mask
        extracted_worker_id = (snowflake_id >> worker_id_shift) & (
            (1 << worker_id_bits) - 1
        )
        extracted_process_id = (snowflake_id >> process_id_shift) & (
            (1 << process_id_bits) - 1
        )
        extracted_timestamp = snowflake_id >> timestamp_left_shift

        # Verify components
        assert extracted_worker_id == worker_id
        assert extracted_process_id == process_id
        assert extracted_sequence >= 0
        assert extracted_timestamp >= 0


class TestSnowflakeId:
    """Test suite for snowflake_id function."""

    def test_snowflake_id_returns_integer(self):
        """Test that snowflake_id returns an integer."""
        result = snowflake_id()
        assert isinstance(result, int)
        assert result > 0

    def test_snowflake_id_uniqueness(self):
        """Test that snowflake_id generates unique IDs."""
        ids = set()
        for _ in range(100):
            id_value = snowflake_id()
            assert id_value not in ids
            ids.add(id_value)

    def test_snowflake_id_uses_global_generator(self):
        """Test that snowflake_id uses the global generator."""
        # This test verifies that consecutive calls advance the global generator
        id1 = snowflake_id()
        id2 = snowflake_id()

        assert id1 != id2
        assert isinstance(id1, int)
        assert isinstance(id2, int)

    def test_multiple_snowflake_id_calls(self):
        """Test multiple consecutive snowflake_id calls."""
        ids = []
        for _ in range(10):
            ids.append(snowflake_id())

        # All IDs should be unique
        assert len(set(ids)) == len(ids)

        # All IDs should be positive integers
        for id_value in ids:
            assert isinstance(id_value, int)
            assert id_value > 0


class TestGlobalGenerator:
    """Test suite for global generator instance."""

    def test_global_generator_exists(self):
        """Test that global_generator is properly initialized."""
        assert global_generator is not None

        # Should be able to generate IDs
        id_value = next(global_generator)
        assert isinstance(id_value, int)
        assert id_value > 0

    def test_global_generator_state_persistence(self):
        """Test that global generator maintains state across calls."""
        # Generate some IDs to advance the state
        for _ in range(5):
            next(global_generator)

        # The next ID should continue from where we left off
        id_before = next(global_generator)
        id_after = next(global_generator)

        assert id_after != id_before


class TestSnowflakeIdStructure:
    """Test suite for snowflake ID structure validation."""

    def test_id_bit_length(self):
        """Test that generated IDs fit within expected bit length."""
        snowflake_id_value = snowflake_id()

        # Snowflake IDs should fit in 64 bits
        assert snowflake_id_value.bit_length() <= 64

    def test_timestamp_component(self):
        """Test timestamp component extraction and validation."""
        current_time = int(time.time())
        snowflake_id_value = snowflake_id()

        # Extract timestamp
        extracted_timestamp = (snowflake_id_value >> timestamp_left_shift) + API_EPOCH

        # Should be close to current time (within a few seconds)
        time_diff = abs(extracted_timestamp - current_time)
        assert time_diff < 10  # Allow 10 seconds difference

    def test_components_within_bounds(self):
        """Test that all components are within expected bounds."""
        snowflake_id_value = snowflake_id()

        # Extract components
        sequence = snowflake_id_value & sequence_mask
        worker_id = (snowflake_id_value >> worker_id_shift) & (
            (1 << worker_id_bits) - 1
        )
        process_id = (snowflake_id_value >> process_id_shift) & (
            (1 << process_id_bits) - 1
        )

        # Verify bounds
        assert 0 <= sequence <= sequence_mask
        assert 0 <= worker_id <= max_worker_id
        assert 0 <= process_id <= max_process_id

    @pytest.mark.parametrize(
        "worker_id,process_id",
        [
            (0, 0),
            (1, 1),
            (max_worker_id, max_process_id),
            (15, 20),
        ],
    )
    def test_parametrized_id_generation(self, worker_id, process_id):
        """Parametrized test for ID generation with different worker/process IDs."""
        gen = generator(worker_id=worker_id, process_id=process_id)
        snowflake_id_value = next(gen)

        # Extract and verify components
        extracted_worker = (snowflake_id_value >> worker_id_shift) & (
            (1 << worker_id_bits) - 1
        )
        extracted_process = (snowflake_id_value >> process_id_shift) & (
            (1 << process_id_bits) - 1
        )

        assert extracted_worker == worker_id
        assert extracted_process == process_id


class TestEdgeCases:
    """Test suite for edge cases and error conditions."""

    def test_generator_with_extreme_values(self):
        """Test generator with boundary values."""
        gen = generator(worker_id=max_worker_id, process_id=max_process_id)
        snowflake_id_value = next(gen)

        assert isinstance(snowflake_id_value, int)
        assert snowflake_id_value > 0

    def test_rapid_id_generation(self):
        """Test rapid ID generation doesn't cause issues."""
        gen = generator()
        ids = []

        # Generate many IDs quickly
        for _ in range(1000):
            ids.append(next(gen))

        # All should be unique
        assert len(set(ids)) == len(ids)

        # All should be valid integers
        for id_value in ids:
            assert isinstance(id_value, int)
            assert id_value > 0
