"""Export offline openapi symbols"""

from .offline import register_offline_openapi

__all__ = [register_offline_openapi]
