# SPDX-License-Identifier: MIT

import json
import tempfile
from unittest.mock import MagicMock, Mock, patch

import pytest

from src.main.app.libs.cache.disk_cache import PageCache


class TestPageCache:
    """Test suite for PageCache (disk cache) implementation."""

    @pytest.fixture
    def cache(self):
        """Create a PageCache instance for testing."""
        return PageCache()

    @pytest.fixture
    def temp_cache(self):
        """Create a PageCache instance with temporary directory."""
        with tempfile.TemporaryDirectory() as temp_dir:
            with patch("diskcache.Cache") as mock_cache_class:
                mock_cache = MagicMock()
                mock_cache_class.return_value = mock_cache
                cache = PageCache()
                cache.cache = mock_cache
                yield cache, mock_cache

    # Basic cache operations tests
    @pytest.mark.asyncio
    async def test_get_operation(self, cache):
        """Test get operation."""
        # Mock the cache get method
        cache.cache.get = Mock(return_value="test_value")

        result = await cache.get("test_key")

        assert result == "test_value"
        cache.cache.get.assert_called_once_with("test_key")

    @pytest.mark.asyncio
    async def test_set_operation_without_timeout(self, cache):
        """Test set operation without timeout."""
        cache.cache.set = Mock()

        await cache.set("test_key", "test_value")

        cache.cache.set.assert_called_once_with("test_key", "test_value")

    @pytest.mark.asyncio
    async def test_set_operation_with_timeout(self, cache):
        """Test set operation with timeout."""
        cache.cache.set = Mock()

        await cache.set("test_key", "test_value", timeout=60)

        cache.cache.set.assert_called_once_with("test_key", "test_value", 60)

    @pytest.mark.asyncio
    async def test_delete_operation_existing_key(self, cache):
        """Test delete operation with existing key."""
        # Use a real cache for this test
        real_cache = PageCache()

        # Set a value first
        await real_cache.set("test_key", "test_value")

        # Verify it exists
        exists_before = await real_cache.exists("test_key")
        assert exists_before is True

        # Delete it
        await real_cache.delete("test_key")

        # Verify it's gone
        exists_after = await real_cache.exists("test_key")
        assert exists_after is False

    @pytest.mark.asyncio
    async def test_delete_operation_nonexistent_key(self, cache):
        """Test delete operation with nonexistent key."""
        # Use a real cache for this test
        real_cache = PageCache()

        # Try to delete a non-existent key (should not raise error)
        await real_cache.delete("nonexistent_key")

        # Verify it still doesn't exist
        exists = await real_cache.exists("nonexistent_key")
        assert exists is False

    @pytest.mark.asyncio
    async def test_exists_true(self, cache):
        """Test exists operation returning True."""
        # Use a real cache for this test
        real_cache = PageCache()

        # Set a value first
        await real_cache.set("test_key", "test_value")

        # Check if it exists
        result = await real_cache.exists("test_key")

        assert result is True

    @pytest.mark.asyncio
    async def test_exists_false(self, cache):
        """Test exists operation returning False."""
        # Use a real cache for this test
        real_cache = PageCache()

        # Check for a non-existent key
        result = await real_cache.exists("nonexistent_key")

        assert result is False

    # Helper methods tests
    def test_get_list_with_json_string(self, cache):
        """Test _get_list with valid JSON string."""
        test_list = ["value1", "value2", "value3"]
        cache.cache.get = Mock(return_value=json.dumps(test_list))

        result = cache._get_list("test_key")

        assert result == test_list

    def test_get_list_with_list_data(self, cache):
        """Test _get_list with direct list data."""
        test_list = ["value1", "value2", "value3"]
        cache.cache.get = Mock(return_value=test_list)

        result = cache._get_list("test_key")

        assert result == test_list

    def test_get_list_with_invalid_json(self, cache):
        """Test _get_list with invalid JSON string."""
        cache.cache.get = Mock(return_value="invalid json string")

        result = cache._get_list("test_key")

        assert result == []

    def test_get_list_with_non_list_data(self, cache):
        """Test _get_list with non-list data."""
        cache.cache.get = Mock(return_value="not a list")

        result = cache._get_list("test_key")

        assert result == []

    def test_get_list_with_nonexistent_key(self, cache):
        """Test _get_list with nonexistent key."""
        cache.cache.get = Mock(return_value=None)

        result = cache._get_list("test_key")

        assert result == []

    def test_set_list_without_timeout(self, cache):
        """Test _set_list without timeout."""
        test_list = ["value1", "value2"]
        cache.cache.set = Mock()

        cache._set_list("test_key", test_list)

        cache.cache.set.assert_called_once_with("test_key", json.dumps(test_list))

    def test_set_list_with_timeout(self, cache):
        """Test _set_list with timeout."""
        test_list = ["value1", "value2"]
        cache.cache.set = Mock()

        cache._set_list("test_key", test_list, timeout=60)

        cache.cache.set.assert_called_once_with("test_key", json.dumps(test_list), 60)

    # List operations tests
    @pytest.mark.asyncio
    async def test_lpush_empty_list(self, cache):
        """Test lpush on empty list."""
        cache._get_list = Mock(return_value=[])
        cache._set_list = Mock()

        result = await cache.lpush("test_list", "value1", "value2")

        assert result == 2
        cache._set_list.assert_called_once_with("test_list", ["value2", "value1"])

    @pytest.mark.asyncio
    async def test_lpush_existing_list(self, cache):
        """Test lpush on existing list."""
        cache._get_list = Mock(return_value=["existing"])
        cache._set_list = Mock()

        result = await cache.lpush("test_list", "new1", "new2")

        assert result == 3
        cache._set_list.assert_called_once_with(
            "test_list", ["new2", "new1", "existing"]
        )

    @pytest.mark.asyncio
    async def test_rpush_empty_list(self, cache):
        """Test rpush on empty list."""
        cache._get_list = Mock(return_value=[])
        cache._set_list = Mock()

        result = await cache.rpush("test_list", "value1", "value2")

        assert result == 2
        cache._set_list.assert_called_once_with("test_list", ["value1", "value2"])

    @pytest.mark.asyncio
    async def test_rpush_existing_list(self, cache):
        """Test rpush on existing list."""
        cache._get_list = Mock(return_value=["existing"])
        cache._set_list = Mock()

        result = await cache.rpush("test_list", "new1", "new2")

        assert result == 3
        cache._set_list.assert_called_once_with(
            "test_list", ["existing", "new1", "new2"]
        )

    @pytest.mark.asyncio
    async def test_lpop_single_from_list(self, cache):
        """Test lpop single element from list."""
        cache._get_list = Mock(return_value=["first", "second", "third"])
        cache._set_list = Mock()

        result = await cache.lpop("test_list")

        assert result == "first"
        cache._set_list.assert_called_once_with("test_list", ["second", "third"])

    @pytest.mark.asyncio
    async def test_lpop_multiple_from_list(self, cache):
        """Test lpop multiple elements from list."""
        cache._get_list = Mock(return_value=["first", "second", "third", "fourth"])
        cache._set_list = Mock()

        result = await cache.lpop("test_list", count=2)

        assert result == ["first", "second"]
        cache._set_list.assert_called_once_with("test_list", ["third", "fourth"])

    @pytest.mark.asyncio
    async def test_lpop_from_empty_list(self, cache):
        """Test lpop from empty list."""
        cache._get_list = Mock(return_value=[])

        result = await cache.lpop("test_list")

        assert result is None

    @pytest.mark.asyncio
    async def test_lpop_more_than_available(self, cache):
        """Test lpop more elements than available."""
        cache._get_list = Mock(return_value=["only"])
        cache._set_list = Mock()

        result = await cache.lpop("test_list", count=3)

        assert result == ["only"]
        cache._set_list.assert_called_once_with("test_list", [])

    @pytest.mark.asyncio
    async def test_rpop_single_from_list(self, cache):
        """Test rpop single element from list."""
        cache._get_list = Mock(return_value=["first", "second", "third"])
        cache._set_list = Mock()

        result = await cache.rpop("test_list")

        assert result == "third"
        cache._set_list.assert_called_once_with("test_list", ["first", "second"])

    @pytest.mark.asyncio
    async def test_rpop_multiple_from_list(self, cache):
        """Test rpop multiple elements from list."""
        cache._get_list = Mock(return_value=["first", "second", "third", "fourth"])
        cache._set_list = Mock()

        result = await cache.rpop("test_list", count=2)

        # rpop pops from right, so fourth then third, but result is reversed
        assert result == ["third", "fourth"]  # Reversed to match Redis behavior
        cache._set_list.assert_called_once_with("test_list", ["first", "second"])

    @pytest.mark.asyncio
    async def test_rpop_from_empty_list(self, cache):
        """Test rpop from empty list."""
        cache._get_list = Mock(return_value=[])

        result = await cache.rpop("test_list")

        assert result is None

    @pytest.mark.asyncio
    async def test_llen_empty_list(self, cache):
        """Test llen on empty list."""
        cache._get_list = Mock(return_value=[])

        result = await cache.llen("test_list")

        assert result == 0

    @pytest.mark.asyncio
    async def test_llen_with_elements(self, cache):
        """Test llen on list with elements."""
        cache._get_list = Mock(return_value=["a", "b", "c"])

        result = await cache.llen("test_list")

        assert result == 3

    @pytest.mark.asyncio
    async def test_lindex_valid_positive_index(self, cache):
        """Test lindex with valid positive index."""
        cache._get_list = Mock(return_value=["a", "b", "c"])

        result = await cache.lindex("test_list", 1)

        assert result == "b"

    @pytest.mark.asyncio
    async def test_lindex_valid_negative_index(self, cache):
        """Test lindex with valid negative index."""
        cache._get_list = Mock(return_value=["a", "b", "c"])

        result = await cache.lindex("test_list", -1)

        assert result == "c"

    @pytest.mark.asyncio
    async def test_lindex_invalid_index(self, cache):
        """Test lindex with invalid index."""
        cache._get_list = Mock(return_value=["a", "b", "c"])

        result = await cache.lindex("test_list", 10)

        assert result is None

    @pytest.mark.asyncio
    async def test_lrange_full_range(self, cache):
        """Test lrange with full range."""
        test_list = ["a", "b", "c", "d", "e"]
        cache._get_list = Mock(return_value=test_list)

        result = await cache.lrange("test_list")

        assert result == test_list

    @pytest.mark.asyncio
    async def test_lrange_partial_range(self, cache):
        """Test lrange with partial range."""
        cache._get_list = Mock(return_value=["a", "b", "c", "d", "e"])

        result = await cache.lrange("test_list", 1, 3)

        assert result == ["b", "c", "d"]

    @pytest.mark.asyncio
    async def test_lrange_with_negative_end(self, cache):
        """Test lrange with negative end index."""
        test_list = ["a", "b", "c", "d", "e"]
        cache._get_list = Mock(return_value=test_list)

        result = await cache.lrange("test_list", 0, -1)

        assert result == test_list

    @pytest.mark.asyncio
    async def test_lrange_empty_list(self, cache):
        """Test lrange on empty list."""
        cache._get_list = Mock(return_value=[])

        result = await cache.lrange("test_list")

        assert result == []

    @pytest.mark.asyncio
    async def test_lset_valid_index(self, cache):
        """Test lset with valid index."""
        cache._get_list = Mock(return_value=["a", "b", "c"])
        cache._set_list = Mock()

        result = await cache.lset("test_list", 1, "new_value")

        assert result is True
        cache._set_list.assert_called_once_with("test_list", ["a", "new_value", "c"])

    @pytest.mark.asyncio
    async def test_lset_invalid_index(self, cache):
        """Test lset with invalid index."""
        cache._get_list = Mock(return_value=["a", "b", "c"])

        result = await cache.lset("test_list", 10, "new_value")

        assert result is False

    @pytest.mark.asyncio
    async def test_lrem_remove_all_occurrences(self, cache):
        """Test lrem removing all occurrences."""
        cache._get_list = Mock(return_value=["a", "b", "a", "c", "a"])
        cache._set_list = Mock()

        result = await cache.lrem("test_list", 0, "a")

        assert result == 3
        cache._set_list.assert_called_once_with("test_list", ["b", "c"])

    @pytest.mark.asyncio
    async def test_lrem_remove_from_head(self, cache):
        """Test lrem removing from head."""
        cache._get_list = Mock(return_value=["a", "b", "a", "c", "a"])
        cache._set_list = Mock()

        result = await cache.lrem("test_list", 2, "a")

        assert result == 2
        cache._set_list.assert_called_once_with("test_list", ["b", "c", "a"])

    @pytest.mark.asyncio
    async def test_lrem_remove_from_tail(self, cache):
        """Test lrem removing from tail."""
        cache._get_list = Mock(return_value=["a", "b", "a", "c", "a"])
        cache._set_list = Mock()

        result = await cache.lrem("test_list", -2, "a")

        assert result == 2
        cache._set_list.assert_called_once_with("test_list", ["a", "b", "c"])

    @pytest.mark.asyncio
    async def test_lrem_element_not_found(self, cache):
        """Test lrem when element is not found."""
        cache._get_list = Mock(return_value=["a", "b", "c"])
        cache._set_list = Mock()

        result = await cache.lrem("test_list", 0, "d")

        assert result == 0
        cache._set_list.assert_called_once_with("test_list", ["a", "b", "c"])

    @pytest.mark.asyncio
    async def test_ltrim_normal_range(self, cache):
        """Test ltrim with normal range."""
        cache._get_list = Mock(return_value=["a", "b", "c", "d", "e"])
        cache._set_list = Mock()

        result = await cache.ltrim("test_list", 1, 3)

        assert result is True
        cache._set_list.assert_called_once_with("test_list", ["b", "c", "d"])

    @pytest.mark.asyncio
    async def test_ltrim_with_negative_end(self, cache):
        """Test ltrim with negative end index."""
        cache._get_list = Mock(return_value=["a", "b", "c", "d", "e"])
        cache._set_list = Mock()

        result = await cache.ltrim("test_list", 1, -1)

        assert result is True
        cache._set_list.assert_called_once_with("test_list", ["b", "c", "d", "e"])

    @pytest.mark.asyncio
    async def test_ltrim_exception_handling(self, cache):
        """Test ltrim exception handling."""
        # Use a mock that won't raise an exception during _get_list
        cache._get_list = Mock(return_value=["a", "b", "c"])
        cache._set_list = Mock(side_effect=Exception("Test exception"))

        result = await cache.ltrim("test_list", 1, 3)

        assert result is False

    # Integration tests
    @pytest.mark.asyncio
    async def test_list_operations_integration(self, cache):
        """Test integration of multiple list operations."""
        # Use a real cache instance for integration testing
        real_cache = PageCache()

        # Build a list using various operations
        await real_cache.rpush("queue", "task1", "task2")
        await real_cache.lpush("queue", "urgent_task")

        # Check current state
        length = await real_cache.llen("queue")
        assert length == 3

        current_list = await real_cache.lrange("queue")
        assert current_list == ["urgent_task", "task1", "task2"]

        # Process tasks
        first_task = await real_cache.lpop("queue")
        assert first_task == "urgent_task"

        # Add more tasks
        await real_cache.rpush("queue", "task3", "task4")

        # Check final state
        final_list = await real_cache.lrange("queue")
        assert final_list == ["task1", "task2", "task3", "task4"]

        # Trim to keep only first 2
        await real_cache.ltrim("queue", 0, 1)
        trimmed_list = await real_cache.lrange("queue")
        assert trimmed_list == ["task1", "task2"]
