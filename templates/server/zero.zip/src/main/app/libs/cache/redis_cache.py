# SPDX-License-Identifier: MIT
"""Redis cache implementation"""

import asyncio
from typing import Any, Optional, Union

from loguru import logger

from src.main.app.libs.cache.base_cache import Cache

try:
    import redis.asyncio as redis
except ModuleNotFoundError:
    logger.error(
        "Cannot find redis module, please install it via `uv add redis[hiredis]`"
    )
    redis = None
except Exception:
    logger.error("Error importing redis module")
    redis = None

from src.main.app.libs.config.config_manager import load_config


class RedisCache(Cache):
    def __init__(self, redis_client):
        if redis is None:
            raise RuntimeError(
                "Redis module is not available. Please install it via 'uv add redis[hiredis]'"
            )
        self.redis_client = redis_client

    async def get(self, key: str) -> Any:
        """Retrieve a value by key from Redis."""
        return await self.redis_client.get(key)

    async def set(self, key: str, value: Any, timeout=None):
        """Set the value of a key in Redis with timeout."""
        if timeout:
            await self.redis_client.setex(key, timeout, value)
        else:
            await self.redis_client.set(key, value)

    async def delete(self, key: str):
        """Delete a key from Redis."""
        return await self.redis_client.delete(key)

    async def exists(self, key: str):
        """Check if a key exists in Redis."""
        return await self.redis_client.exists(key)

    # List operations
    async def lpush(self, key: str, *values: Any) -> int:
        """Push one or more values to the left (head) of a list."""
        return await self.redis_client.lpush(key, *values)

    async def rpush(self, key: str, *values: Any) -> int:
        """Push one or more values to the right (tail) of a list."""
        return await self.redis_client.rpush(key, *values)

    async def lpop(self, key: str, count: int = 1) -> Union[Any, list[Any], None]:
        """Remove and return elements from the left (head) of a list."""
        if count == 1:
            return await self.redis_client.lpop(key)
        else:
            return await self.redis_client.lpop(key, count)

    async def rpop(self, key: str, count: int = 1) -> Union[Any, list[Any], None]:
        """Remove and return elements from the right (tail) of a list."""
        if count == 1:
            return await self.redis_client.rpop(key)
        else:
            return await self.redis_client.rpop(key, count)

    async def llen(self, key: str) -> int:
        """Get the length of a list."""
        return await self.redis_client.llen(key)

    async def lindex(self, key: str, index: int) -> Any:
        """Get an element from a list by its index."""
        return await self.redis_client.lindex(key, index)

    async def lrange(self, key: str, start: int = 0, end: int = -1) -> list[Any]:
        """Get a range of elements from a list."""
        return await self.redis_client.lrange(key, start, end)

    async def lset(self, key: str, index: int, value: Any) -> bool:
        """Set the value of an element in a list by its index."""
        try:
            await self.redis_client.lset(key, index, value)
            return True
        except Exception:
            return False

    async def lrem(self, key: str, count: int, value: Any) -> int:
        """Remove elements from a list."""
        return await self.redis_client.lrem(key, count, value)

    async def ltrim(self, key: str, start: int, end: int) -> bool:
        """Trim a list to the specified range."""
        try:
            await self.redis_client.ltrim(key, start, end)
            return True
        except Exception:
            return False


class RedisManager:
    _instance: Optional["redis.Redis"] = None
    _connection_pool: Optional["redis.ConnectionPool"] = None
    _lock = asyncio.Lock()

    @classmethod
    async def get_instance(cls) -> "redis.Redis":
        """
        Get redis instance
        """
        if redis is None:
            raise RuntimeError(
                "Redis module is not available. Please install it via 'uv add redis[hiredis]'"
            )

        if cls._instance is None:
            async with cls._lock:
                if cls._connection_pool is None:
                    database = load_config().database
                    cls._connection_pool = redis.ConnectionPool.from_url(
                        f"redis://:{database.cache_pass}@{database.cache_host}:{database.cache_port}/{database.db_num}",
                        decode_responses=True,
                    )
                if cls._instance is None:
                    cls._instance = await redis.Redis.from_pool(cls._connection_pool)
        return cls._instance
