# SPDX-License-Identifier: MIT

from abc import ABC

import pytest

from src.main.app.libs.cache.base_cache import Cache


class TestBaseCacheInterface:
    """Test suite for the abstract Cache base class."""

    def test_cache_is_abstract(self):
        """Test that Cache cannot be instantiated directly."""
        with pytest.raises(TypeError):
            Cache()

    def test_cache_abstract_methods(self):
        """Test that all required methods are defined as abstract."""
        abstract_methods = Cache.__abstractmethods__

        expected_methods = {
            "get",
            "set",
            "delete",
            "exists",
            "lpush",
            "rpush",
            "lpop",
            "rpop",
            "llen",
            "lindex",
            "lrange",
            "lset",
            "lrem",
            "ltrim",
        }

        assert abstract_methods == expected_methods

    def test_cache_inheritance(self):
        """Test that Cache is properly defined as an ABC."""
        assert issubclass(Cache, ABC)
        assert hasattr(Cache, "__abstractmethods__")

    def test_basic_cache_methods_exist(self):
        """Test that basic cache methods are defined."""
        basic_methods = ["get", "set", "delete", "exists"]
        for method in basic_methods:
            assert hasattr(Cache, method)
            assert callable(getattr(Cache, method))

    def test_list_operation_methods_exist(self):
        """Test that list operation methods are defined."""
        list_methods = [
            "lpush",
            "rpush",
            "lpop",
            "rpop",
            "llen",
            "lindex",
            "lrange",
            "lset",
            "lrem",
            "ltrim",
        ]
        for method in list_methods:
            assert hasattr(Cache, method)
            assert callable(getattr(Cache, method))

    def test_method_signatures(self):
        """Test that methods have correct signatures."""
        # Test get method
        get_method = Cache.get
        assert get_method.__annotations__.get("key") == str

        # Test set method
        set_method = Cache.set
        assert set_method.__annotations__.get("key") == str

        # Test exists method
        exists_method = Cache.exists
        assert exists_method.__annotations__.get("return") == bool

    def test_concrete_implementation_requirements(self):
        """Test that a concrete implementation must implement all abstract methods."""

        class IncompleteCache(Cache):
            async def get(self, key: str):
                return None

            async def set(self, key: str, value, timeout=None):
                pass

            # Missing other required methods

        with pytest.raises(TypeError):
            IncompleteCache()

    def test_complete_implementation_works(self):
        """Test that a complete implementation can be instantiated."""

        class CompleteCache(Cache):
            async def get(self, key: str):
                return None

            async def set(self, key: str, value, timeout=None):
                pass

            async def delete(self, key: str):
                pass

            async def exists(self, key: str) -> bool:
                return False

            async def lpush(self, key: str, *values):
                return 0

            async def rpush(self, key: str, *values):
                return 0

            async def lpop(self, key: str, count: int = 1):
                return None

            async def rpop(self, key: str, count: int = 1):
                return None

            async def llen(self, key: str) -> int:
                return 0

            async def lindex(self, key: str, index: int):
                return None

            async def lrange(self, key: str, start: int = 0, end: int = -1):
                return []

            async def lset(self, key: str, index: int, value) -> bool:
                return False

            async def lrem(self, key: str, count: int, value) -> int:
                return 0

            async def ltrim(self, key: str, start: int, end: int) -> bool:
                return False

        # Should not raise any exception
        cache = CompleteCache()
        assert isinstance(cache, Cache)
