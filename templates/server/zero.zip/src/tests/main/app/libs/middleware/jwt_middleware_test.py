# SPDX-License-Identifier: MIT
"""Comprehensive unit tests for JWT middleware."""

import asyncio
import http
from unittest.mock import Mock, patch

import pytest
from fastapi import Request
from jwt.exceptions import PyJWTError
from starlette.responses import JSONResponse

from src.main.app.libs.middleware.jwt_middleware import jwt_middleware


class TestJWTMiddleware:
    """Test suite for JWT middleware authentication."""

    @pytest.fixture
    def mock_request(self):
        """Create a mock FastAPI request object."""
        request = Mock(spec=Request)
        request.url = Mock()
        request.headers = {}
        return request

    @pytest.fixture
    def mock_call_next(self):
        """Create a mock call_next function."""

        async def call_next(request):
            response = Mock()
            response.status_code = 200
            response.headers = {}
            return response

        return call_next

    @pytest.fixture
    def mock_configs(self):
        """Mock server and security configurations."""
        with (
            patch(
                "src.main.app.libs.middleware.jwt_middleware.server_config"
            ) as server_cfg,
            patch(
                "src.main.app.libs.middleware.jwt_middleware.security_config"
            ) as security_cfg,
        ):
            server_cfg.api_prefix = "/api/v1"
            security_cfg.enable = True
            security_cfg.enable_swagger = True
            security_cfg.white_list_routes = "/api/v1/auth/login, /api/v1/health"
            yield server_cfg, security_cfg

    @pytest.mark.asyncio
    async def test_swagger_path_allowed_when_enabled(
        self, mock_request, mock_call_next, mock_configs
    ):
        """Test that Swagger paths are allowed when Swagger is enabled."""
        server_cfg, security_cfg = mock_configs
        security_cfg.enable_swagger = True

        mock_request.url.path = "/docs.json"

        response = await jwt_middleware(mock_request, mock_call_next)

        assert response.status_code == 200

    @pytest.mark.asyncio
    async def test_swagger_path_forbidden_when_disabled(
        self, mock_request, mock_call_next, mock_configs
    ):
        """Test that Swagger paths are forbidden when Swagger is disabled."""
        server_cfg, security_cfg = mock_configs
        security_cfg.enable_swagger = False

        mock_request.url.path = "/docs.json"

        response = await jwt_middleware(mock_request, mock_call_next)

        assert isinstance(response, JSONResponse)
        assert response.status_code == http.HTTPStatus.FORBIDDEN

    @pytest.mark.asyncio
    async def test_api_path_with_json_extension_allowed(
        self, mock_request, mock_call_next, mock_configs
    ):
        """Test that API paths with .json extension are allowed."""
        server_cfg, security_cfg = mock_configs
        security_cfg.enable_swagger = True

        mock_request.url.path = "/api/v1/users.json"

        response = await jwt_middleware(mock_request, mock_call_next)

        assert response.status_code == 200

    @pytest.mark.asyncio
    async def test_whitelist_route_bypasses_auth(
        self, mock_request, mock_call_next, mock_configs
    ):
        """Test that whitelisted routes bypass authentication."""
        server_cfg, security_cfg = mock_configs

        mock_request.url.path = "/api/v1/auth/login"

        response = await jwt_middleware(mock_request, mock_call_next)

        assert response.status_code == 200

    @pytest.mark.asyncio
    async def test_security_disabled_bypasses_auth(
        self, mock_request, mock_call_next, mock_configs
    ):
        """Test that requests bypass auth when security is disabled."""
        server_cfg, security_cfg = mock_configs
        security_cfg.enable = False

        mock_request.url.path = "/api/v1/users"

        response = await jwt_middleware(mock_request, mock_call_next)

        assert response.status_code == 200

    @pytest.mark.asyncio
    async def test_missing_authorization_header(
        self, mock_request, mock_call_next, mock_configs
    ):
        """Test handling of missing Authorization header."""
        server_cfg, security_cfg = mock_configs
        security_cfg.enable = True

        mock_request.url.path = "/api/v1/users"
        mock_request.headers = {}

        with patch(
            "src.main.app.libs.middleware.jwt_middleware.constant"
        ) as mock_constant:
            mock_constant.AUTHORIZATION = "Authorization"

            response = await jwt_middleware(mock_request, mock_call_next)

            assert isinstance(response, JSONResponse)
            assert response.status_code == http.HTTPStatus.UNAUTHORIZED

    @pytest.mark.asyncio
    async def test_valid_token_success(
        self, mock_request, mock_call_next, mock_configs
    ):
        """Test successful authentication with valid token."""
        server_cfg, security_cfg = mock_configs
        security_cfg.enable = True

        mock_request.url.path = "/api/v1/users"
        mock_request.headers = {"Authorization": "Bearer valid_token_123"}

        with (
            patch(
                "src.main.app.libs.middleware.jwt_middleware.constant"
            ) as mock_constant,
            patch(
                "src.main.app.libs.middleware.jwt_middleware.security"
            ) as mock_security,
            patch(
                "src.main.app.libs.middleware.jwt_middleware.current_user_id"
            ) as mock_ctx,
        ):
            mock_constant.AUTHORIZATION = "Authorization"
            mock_security.validate_token.return_value = True
            mock_security.get_user_id.return_value = 123
            mock_ctx.set.return_value = "token_ctx"
            mock_ctx.reset = Mock()

            response = await jwt_middleware(mock_request, mock_call_next)

            assert response.status_code == 200
            mock_security.validate_token.assert_called_once_with("valid_token_123")
            mock_security.get_user_id.assert_called_once_with("valid_token_123")
            mock_ctx.set.assert_called_once_with(123)
            mock_ctx.reset.assert_called_once_with("token_ctx")

    @pytest.mark.asyncio
    async def test_invalid_token_error(
        self, mock_request, mock_call_next, mock_configs
    ):
        """Test handling of invalid JWT token."""
        server_cfg, security_cfg = mock_configs
        security_cfg.enable = True

        mock_request.url.path = "/api/v1/users"
        mock_request.headers = {"Authorization": "Bearer invalid_token"}

        with (
            patch(
                "src.main.app.libs.middleware.jwt_middleware.constant"
            ) as mock_constant,
            patch(
                "src.main.app.libs.middleware.jwt_middleware.security"
            ) as mock_security,
            patch("src.main.app.libs.middleware.jwt_middleware.logger") as mock_logger,
        ):
            mock_constant.AUTHORIZATION = "Authorization"
            mock_security.validate_token.side_effect = PyJWTError("Invalid token")

            response = await jwt_middleware(mock_request, mock_call_next)

            assert isinstance(response, JSONResponse)
            assert response.status_code == http.HTTPStatus.UNAUTHORIZED
            mock_logger.error.assert_called_once()

    @pytest.mark.asyncio
    async def test_token_extraction_from_bearer_format(
        self, mock_request, mock_call_next, mock_configs
    ):
        """Test correct token extraction from Bearer format."""
        server_cfg, security_cfg = mock_configs
        security_cfg.enable = True

        mock_request.url.path = "/api/v1/users"
        mock_request.headers = {
            "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9"
        }

        with (
            patch(
                "src.main.app.libs.middleware.jwt_middleware.constant"
            ) as mock_constant,
            patch(
                "src.main.app.libs.middleware.jwt_middleware.security"
            ) as mock_security,
            patch(
                "src.main.app.libs.middleware.jwt_middleware.current_user_id"
            ) as mock_ctx,
        ):
            mock_constant.AUTHORIZATION = "Authorization"
            mock_security.validate_token.return_value = True
            mock_security.get_user_id.return_value = 456
            mock_ctx.set.return_value = "token_ctx"
            mock_ctx.reset = Mock()

            response = await jwt_middleware(mock_request, mock_call_next)

            assert response.status_code == 200
            mock_security.validate_token.assert_called_once_with(
                "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9"
            )

    @pytest.mark.asyncio
    async def test_context_reset_on_exception(
        self, mock_request, mock_call_next, mock_configs
    ):
        """Test that context is properly reset even when call_next raises exception."""
        server_cfg, security_cfg = mock_configs
        security_cfg.enable = True

        mock_request.url.path = "/api/v1/users"
        mock_request.headers = {"Authorization": "Bearer valid_token"}

        async def failing_call_next(request):
            raise ValueError("Something went wrong")

        with (
            patch(
                "src.main.app.libs.middleware.jwt_middleware.constant"
            ) as mock_constant,
            patch(
                "src.main.app.libs.middleware.jwt_middleware.security"
            ) as mock_security,
            patch(
                "src.main.app.libs.middleware.jwt_middleware.current_user_id"
            ) as mock_ctx,
        ):
            mock_constant.AUTHORIZATION = "Authorization"
            mock_security.validate_token.return_value = True
            mock_security.get_user_id.return_value = 789
            mock_ctx.set.return_value = "token_ctx"
            mock_ctx.reset = Mock()

            with pytest.raises(ValueError):
                await jwt_middleware(mock_request, failing_call_next)

            mock_ctx.reset.assert_called_once_with("token_ctx")

    @pytest.mark.asyncio
    async def test_no_context_reset_when_no_token_set(
        self, mock_request, mock_call_next, mock_configs
    ):
        """Test that context reset is not called when no token was set."""
        server_cfg, security_cfg = mock_configs
        security_cfg.enable = True

        mock_request.url.path = "/api/v1/users"
        mock_request.headers = {}

        with (
            patch(
                "src.main.app.libs.middleware.jwt_middleware.constant"
            ) as mock_constant,
            patch(
                "src.main.app.libs.middleware.jwt_middleware.current_user_id"
            ) as mock_ctx,
        ):
            mock_constant.AUTHORIZATION = "Authorization"
            mock_ctx.reset = Mock()

            response = await jwt_middleware(mock_request, mock_call_next)

            assert isinstance(response, JSONResponse)
            assert response.status_code == http.HTTPStatus.UNAUTHORIZED
            mock_ctx.reset.assert_not_called()

    @pytest.mark.asyncio
    async def test_complex_url_path_handling(
        self, mock_request, mock_call_next, mock_configs
    ):
        """Test handling of complex URL paths with API prefix."""
        server_cfg, security_cfg = mock_configs
        security_cfg.enable = True
        security_cfg.white_list_routes = "/api/v1/auth/login, /api/v1/health"

        # Test URL that contains API prefix multiple times
        mock_request.url.path = "/api/v1/users/api/v1/profile"
        mock_request.headers = {"Authorization": "Bearer valid_token"}

        with (
            patch(
                "src.main.app.libs.middleware.jwt_middleware.constant"
            ) as mock_constant,
            patch(
                "src.main.app.libs.middleware.jwt_middleware.security"
            ) as mock_security,
            patch(
                "src.main.app.libs.middleware.jwt_middleware.current_user_id"
            ) as mock_ctx,
        ):
            mock_constant.AUTHORIZATION = "Authorization"
            mock_security.validate_token.return_value = True
            mock_security.get_user_id.return_value = 999
            mock_ctx.set.return_value = "token_ctx"
            mock_ctx.reset = Mock()

            response = await jwt_middleware(mock_request, mock_call_next)

            assert response.status_code == 200

    @pytest.mark.asyncio
    async def test_whitelist_with_spaces_in_config(
        self, mock_request, mock_call_next, mock_configs
    ):
        """Test that whitelist routes work with spaces in configuration."""
        server_cfg, security_cfg = mock_configs
        security_cfg.white_list_routes = (
            " /api/v1/auth/login , /api/v1/health , /api/v1/status "
        )

        mock_request.url.path = "/api/v1/status"

        response = await jwt_middleware(mock_request, mock_call_next)

        assert response.status_code == 200

    @pytest.mark.asyncio
    async def test_print_headers_debug(
        self, mock_request, mock_call_next, mock_configs
    ):
        """Test that headers are printed for debugging (as per original code)."""
        server_cfg, security_cfg = mock_configs
        security_cfg.enable = True

        mock_request.url.path = "/api/v1/users"
        mock_request.headers = {
            "Authorization": "Bearer test_token",
            "User-Agent": "TestAgent",
        }

        with (
            patch(
                "src.main.app.libs.middleware.jwt_middleware.constant"
            ) as mock_constant,
            patch(
                "src.main.app.libs.middleware.jwt_middleware.security"
            ) as mock_security,
            patch(
                "src.main.app.libs.middleware.jwt_middleware.current_user_id"
            ) as mock_ctx,
            patch("builtins.print") as mock_print,
        ):
            mock_constant.AUTHORIZATION = "Authorization"
            mock_security.validate_token.return_value = True
            mock_security.get_user_id.return_value = 111
            mock_ctx.set.return_value = "token_ctx"
            mock_ctx.reset = Mock()

            response = await jwt_middleware(mock_request, mock_call_next)

            assert response.status_code == 200
            mock_print.assert_called_once_with(mock_request.headers)

    @pytest.mark.asyncio
    async def test_path_without_api_prefix(
        self, mock_request, mock_call_next, mock_configs
    ):
        """Test handling of paths that don't contain the API prefix."""
        server_cfg, security_cfg = mock_configs
        security_cfg.enable_swagger = True

        mock_request.url.path = "/health"  # No API prefix

        response = await jwt_middleware(mock_request, mock_call_next)

        assert response.status_code == 200

    @pytest.mark.asyncio
    async def test_auth_error_code_responses(
        self, mock_request, mock_call_next, mock_configs
    ):
        """Test that proper AuthErrorCode responses are returned."""
        server_cfg, security_cfg = mock_configs
        security_cfg.enable = True
        security_cfg.enable_swagger = False

        # Test OPENAPI_FORBIDDEN error
        mock_request.url.path = "/docs.json"

        with patch(
            "src.main.app.libs.middleware.jwt_middleware.AuthErrorCode"
        ) as mock_auth_error:
            mock_auth_error.OPENAPI_FORBIDDEN.code = 40300
            mock_auth_error.OPENAPI_FORBIDDEN.message = "OpenAPI access forbidden"

            response = await jwt_middleware(mock_request, mock_call_next)

            assert isinstance(response, JSONResponse)
            assert response.status_code == http.HTTPStatus.FORBIDDEN

        # Test MISSING_TOKEN error
        mock_request.url.path = "/api/v1/users"
        mock_request.headers = {}

        with (
            patch(
                "src.main.app.libs.middleware.jwt_middleware.constant"
            ) as mock_constant,
            patch(
                "src.main.app.libs.middleware.jwt_middleware.AuthErrorCode"
            ) as mock_auth_error,
        ):
            mock_constant.AUTHORIZATION = "Authorization"
            mock_auth_error.MISSING_TOKEN.code = 40100
            mock_auth_error.MISSING_TOKEN.message = "Authorization token missing"

            response = await jwt_middleware(mock_request, mock_call_next)

            assert isinstance(response, JSONResponse)
            assert response.status_code == http.HTTPStatus.UNAUTHORIZED


class TestJWTMiddlewareIntegration:
    """Integration tests for JWT middleware with real-like scenarios."""

    @pytest.mark.asyncio
    async def test_concurrent_requests_handling(self):
        """Test middleware behavior with concurrent requests."""

        async def mock_call_next(request):
            # Simulate some async work
            await asyncio.sleep(0.01)
            response = Mock()
            response.status_code = 200
            response.headers = {}
            return response

        # Create shared mocks outside to avoid conflicts
        with (
            patch(
                "src.main.app.libs.middleware.jwt_middleware.server_config"
            ) as server_cfg,
            patch(
                "src.main.app.libs.middleware.jwt_middleware.security_config"
            ) as security_cfg,
            patch(
                "src.main.app.libs.middleware.jwt_middleware.constant"
            ) as mock_constant,
            patch(
                "src.main.app.libs.middleware.jwt_middleware.security"
            ) as mock_security,
            patch(
                "src.main.app.libs.middleware.jwt_middleware.current_user_id"
            ) as mock_ctx,
        ):
            # Configure shared mocks
            server_cfg.api_prefix = "/api/v1"
            security_cfg.enable = True
            security_cfg.enable_swagger = True
            security_cfg.white_list_routes = ""
            mock_constant.AUTHORIZATION = "Authorization"
            mock_security.validate_token.return_value = True

            # Create a shared mock token
            mock_token = Mock()
            mock_ctx.set.return_value = mock_token
            mock_ctx.reset = Mock()

            async def make_request(user_id):
                request = Mock(spec=Request)
                request.url = Mock()
                request.url.path = "/api/v1/users"
                request.headers = {"Authorization": f"Bearer token_{user_id}"}

                # Configure user-specific mock
                mock_security.get_user_id.return_value = user_id

                return await jwt_middleware(request, mock_call_next)

            # Make multiple concurrent requests
            tasks = [make_request(i) for i in range(5)]
            responses = await asyncio.gather(*tasks)

            # All should succeed
            assert all(response.status_code == 200 for response in responses)

    @pytest.mark.asyncio
    async def test_request_lifecycle_complete(self):
        """Test complete request lifecycle through middleware."""
        request = Mock(spec=Request)
        request.url = Mock()
        request.url.path = "/api/v1/protected-resource"
        request.headers = {"Authorization": "Bearer jwt_token_abc123"}

        call_count = 0

        async def mock_call_next(req):
            nonlocal call_count
            call_count += 1
            response = Mock()
            response.status_code = 201
            response.headers = {"Content-Type": "application/json"}
            return response

        with (
            patch(
                "src.main.app.libs.middleware.jwt_middleware.server_config"
            ) as server_cfg,
            patch(
                "src.main.app.libs.middleware.jwt_middleware.security_config"
            ) as security_cfg,
            patch(
                "src.main.app.libs.middleware.jwt_middleware.constant"
            ) as mock_constant,
            patch(
                "src.main.app.libs.middleware.jwt_middleware.security"
            ) as mock_security,
            patch(
                "src.main.app.libs.middleware.jwt_middleware.current_user_id"
            ) as mock_ctx,
            patch("builtins.print"),
        ):
            server_cfg.api_prefix = "/api/v1"
            security_cfg.enable = True
            security_cfg.enable_swagger = True
            security_cfg.white_list_routes = "/api/v1/auth/login"
            mock_constant.AUTHORIZATION = "Authorization"
            mock_security.validate_token.return_value = True
            mock_security.get_user_id.return_value = 42
            ctx_token = Mock()  # Create a proper mock token object
            mock_ctx.set.return_value = ctx_token
            mock_ctx.reset = Mock()

            response = await jwt_middleware(request, mock_call_next)

            # Verify complete lifecycle
            assert call_count == 1  # Call next was invoked
            assert response.status_code == 201
            mock_security.validate_token.assert_called_once_with("jwt_token_abc123")
            mock_security.get_user_id.assert_called_once_with("jwt_token_abc123")
            mock_ctx.set.assert_called_once_with(42)
            mock_ctx.reset.assert_called_once_with(ctx_token)
