# SPDX-License-Identifier: MIT
"""Auth exception for the application."""

from typing import Any, Optional

from src.main.app.enums.auth_error_code import AuthErrorCode
from src.main.app.libs.exception import HTTPException


class AuthException(HTTPException):
    code: AuthErrorCode
    message: Optional[str] = None
    details: Optional[Any] = None
