# SPDX-License-Identifier: MIT
"""Business exception for the application."""

from typing import Any, Optional

from src.main.app.libs.enums import ExceptionCode
from src.main.app.libs.exception import HTTPException


class BusinessException(HTTPException):
    def __init__(
        self,
        code: ExceptionCode,
        message: Optional[str] = None,
        details: Optional[Any] = None,
    ):
        super().__init__(code=code, message=message, details=details)
