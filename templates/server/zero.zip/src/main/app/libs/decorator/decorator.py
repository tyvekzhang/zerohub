# SPDX-License-Identifier: MIT
"""Decorator module for making decorators."""

from typing import Type

from src.main.app.libs.config.config_registry import BaseConfig, ConfigRegistry


# Decorator for easy registration
def config_class(name: str):
    """
    Decorator to register a configuration class.

    Args:
        name: The name to register the configuration under

    Usage:
        @config_class("my_config")
        class MyConfig(BaseConfig):
            pass
    """

    def decorator(cls: Type[BaseConfig]):
        ConfigRegistry.register(name, cls)
        return cls

    return decorator
