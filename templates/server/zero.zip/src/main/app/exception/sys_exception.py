# SPDX-License-Identifier: MIT
"""System exception for the application."""

from typing import Any, Optional

from src.main.app.enums.sys_error_code import SystemErrorCode
from src.main.app.libs.exception import HTTPException


class SystemException(HTTPException):
    code: SystemErrorCode
    message: Optional[str] = None
    details: Optional[Any] = None
