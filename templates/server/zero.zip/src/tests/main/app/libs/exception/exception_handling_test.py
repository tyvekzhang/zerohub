# SPDX-License-Identifier: MIT
"""Comprehensive unit tests for exception handling module."""

import json
from http import HTTPStatus
from unittest.mock import AsyncMock, Mock, patch

import pytest
from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse, Response
from jwt import PyJWTError
from pydantic_core._pydantic_core import ValidationError
from starlette.exceptions import HTTPException as StarletteHTTPException

from src.main.app.libs.enums.base_error_code import ExceptionCode
from src.main.app.libs.exception import exception_handler
from src.main.app.libs.exception.custom_exception import HTTPException
from src.main.app.libs.exception.exception_manager import register_exception_handlers


class TestHTTPException:
    """Test suite for custom HTTPException."""

    def test_http_exception_creation(self):
        """Test creating HTTPException with ExceptionCode."""
        error_code = ExceptionCode(code=404, message="Not found")

        exc = HTTPException(code=error_code)

        assert exc.code == error_code
        assert exc.message == "Not found"
        assert exc.details is None

    def test_http_exception_with_custom_message(self):
        """Test HTTPException with custom message."""
        error_code = ExceptionCode(code=400, message="Bad request")
        custom_message = "Custom error message"

        exc = HTTPException(code=error_code, message=custom_message)

        assert exc.code == error_code
        assert exc.message == custom_message
        assert exc.details is None

    def test_http_exception_with_details(self):
        """Test HTTPException with additional details."""
        error_code = ExceptionCode(code=422, message="Validation error")
        details = {"field": "email", "issue": "invalid format"}

        exc = HTTPException(code=error_code, details=details)

        assert exc.code == error_code
        assert exc.message == "Validation error"
        assert exc.details == details

    def test_http_exception_message_defaults_to_code_message(self):
        """Test that message defaults to code.message when None."""
        error_code = ExceptionCode(code=500, message="Internal error")

        exc = HTTPException(code=error_code, message=None)

        assert exc.message == "Internal error"

    def test_http_exception_post_init_called(self):
        """Test that __post_init__ is called during initialization."""
        error_code = ExceptionCode(code=401, message="Unauthorized")

        with patch.object(HTTPException, "__post_init__") as mock_post_init:
            exc = HTTPException(code=error_code)
            mock_post_init.assert_called_once()

    def test_http_exception_inheritance(self):
        """Test that HTTPException inherits from Exception."""
        error_code = ExceptionCode(code=403, message="Forbidden")
        exc = HTTPException(code=error_code)

        assert isinstance(exc, Exception)


class TestExceptionManager:
    """Test suite for exception manager."""

    @pytest.fixture
    def mock_app(self):
        """Create a mock FastAPI app."""
        app = Mock(spec=FastAPI)
        app.add_exception_handler = Mock()
        return app

    def test_register_exception_handlers(self, mock_app):
        """Test registering all exception handlers."""
        register_exception_handlers(mock_app)

        # Verify all handlers are registered
        expected_calls = [
            (Exception, exception_handler.global_exception_handler),
            (ValidationError, exception_handler.validation_exception_handler),
            (HTTPException, exception_handler.custom_exception_handler),
            (StarletteHTTPException, exception_handler.custom_http_exception_handler),
            (
                RequestValidationError,
                exception_handler.request_validation_exception_handler,
            ),
            (PyJWTError, exception_handler.jwt_exception_handler),
        ]

        assert mock_app.add_exception_handler.call_count == len(expected_calls)

        # Check that all expected exception types are registered
        registered_types = [
            call[0][0] for call in mock_app.add_exception_handler.call_args_list
        ]
        expected_types = [call[0] for call in expected_calls]

        for expected_type in expected_types:
            assert expected_type in registered_types

    def test_register_exception_handlers_with_real_app(self):
        """Test registering handlers with a real FastAPI app."""
        app = FastAPI()

        # Should not raise any exceptions
        register_exception_handlers(app)

        # Verify handlers are actually registered
        assert len(app.exception_handlers) >= 6


class TestExtractRequestData:
    """Test suite for extract_request_data function."""

    @pytest.fixture
    def mock_request(self):
        """Create a mock request object."""
        request = Mock(spec=Request)
        request.headers = {}
        return request

    @pytest.mark.asyncio
    async def test_extract_json_data(self, mock_request):
        """Test extracting JSON data from request."""
        json_data = {"key": "value", "number": 123}
        mock_request.headers = {"content-type": "application/json"}
        mock_request.json = AsyncMock(return_value=json_data)

        result = await exception_handler.extract_request_data(mock_request)

        assert result["json"] == json_data
        mock_request.json.assert_called_once()

    @pytest.mark.asyncio
    async def test_extract_form_data(self, mock_request):
        """Test extracting form data from request."""
        form_data = {"username": "test", "password": "secret"}
        mock_form = Mock()
        mock_form.items.return_value = form_data.items()

        mock_request.headers = {"content-type": "application/x-www-form-urlencoded"}
        mock_request.form = AsyncMock(return_value=mock_form)

        result = await exception_handler.extract_request_data(mock_request)

        assert result["form"] == form_data
        mock_request.form.assert_called_once()

    @pytest.mark.asyncio
    async def test_extract_multipart_form_data(self, mock_request):
        """Test extracting multipart form data from request."""
        # Mock file upload
        mock_file = Mock()
        mock_file.filename = "test.txt"

        form_items = [("field1", "value1"), ("file", mock_file)]
        mock_form = Mock()
        mock_form.items.return_value = form_items

        mock_request.headers = {"content-type": "multipart/form-data"}
        mock_request.form = AsyncMock(return_value=mock_form)

        result = await exception_handler.extract_request_data(mock_request)

        assert result["form"]["field1"] == "value1"
        assert "<file: test.txt>" in result["form"]["file"]

    @pytest.mark.asyncio
    async def test_extract_body_data(self, mock_request):
        """Test extracting raw body data from request."""
        body_text = "raw body content"
        mock_request.headers = {"content-type": "text/plain"}
        mock_request.body = AsyncMock(return_value=body_text.encode())

        result = await exception_handler.extract_request_data(mock_request)

        assert result["body"] == body_text
        mock_request.body.assert_called_once()

    @pytest.mark.asyncio
    async def test_extract_binary_body_data(self, mock_request):
        """Test extracting binary body data from request."""
        # Use binary data that will cause UnicodeDecodeError
        binary_data = b"\x80\x81\x82\x83"  # Invalid UTF-8 sequences
        mock_request.headers = {"content-type": "application/octet-stream"}
        mock_request.body = AsyncMock(return_value=binary_data)

        result = await exception_handler.extract_request_data(mock_request)

        # The binary data should be formatted as a special string
        expected_body = f"<binary: {len(binary_data)} bytes>"
        assert result["body"] == expected_body

    @pytest.mark.asyncio
    async def test_extract_data_with_exception(self, mock_request):
        """Test handling exceptions during data extraction."""
        mock_request.headers = {"content-type": "application/json"}
        mock_request.json = AsyncMock(side_effect=Exception("JSON parse error"))

        result = await exception_handler.extract_request_data(mock_request)

        assert "Failed to parse request data" in result["error"]

    @pytest.mark.asyncio
    async def test_extract_empty_request(self, mock_request):
        """Test extracting data from empty request."""
        mock_request.headers = {}
        mock_request.body = AsyncMock(return_value=b"")

        result = await exception_handler.extract_request_data(mock_request)

        # Should return empty dict or minimal data
        assert isinstance(result, dict)


class TestCollectRequestInfo:
    """Test suite for collect_request_info function."""

    def test_collect_basic_request_info(self):
        """Test collecting basic request information."""
        mock_request = Mock(spec=Request)
        mock_request.url.path = "/api/users"
        mock_request.method = "GET"
        mock_request.query_params = {"page": "1", "size": "10"}
        mock_request.headers = {"Authorization": "Bearer token", "User-Agent": "test"}
        mock_request.client.host = "127.0.0.1"
        mock_request.client.port = 8080

        result = exception_handler.collect_request_info(mock_request)

        assert result["path"] == "/api/users"
        assert result["method"] == "GET"
        assert result["query_params"] == {"page": "1", "size": "10"}
        assert result["headers"]["Authorization"] == "Bearer token"
        assert result["client"] == "127.0.0.1:8080"

    def test_collect_request_info_no_client(self):
        """Test collecting request info when client is None."""
        mock_request = Mock(spec=Request)
        mock_request.url.path = "/api/test"
        mock_request.method = "POST"
        mock_request.query_params = {}
        mock_request.headers = {}
        mock_request.client = None

        result = exception_handler.collect_request_info(mock_request)

        assert result["path"] == "/api/test"
        assert result["method"] == "POST"
        assert result["client"] is None


class TestLogException:
    """Test suite for log_exception function."""

    def test_log_exception_called_with_logger(self):
        """Test that log_exception uses logger.error."""
        exc = ValueError("Test exception")
        request_info = {"path": "/test", "method": "GET"}

        with patch(
            "src.main.app.libs.exception.exception_handler.logger"
        ) as mock_logger:
            exception_handler.log_exception(exc, request_info)

            mock_logger.error.assert_called_once()

            # Check that the log message contains expected information
            log_message = mock_logger.error.call_args[0][0]
            assert "ValueError" in log_message
            assert "Test exception" in log_message
            assert "/test" in log_message

    def test_log_exception_includes_traceback(self):
        """Test that log_exception includes traceback information."""
        exc = RuntimeError("Runtime error")
        request_info = {"path": "/error", "method": "POST"}

        with (
            patch(
                "src.main.app.libs.exception.exception_handler.logger"
            ) as mock_logger,
            patch(
                "src.main.app.libs.exception.exception_handler.traceback"
            ) as mock_traceback,
        ):
            mock_traceback.format_exc.return_value = "Traceback details..."

            exception_handler.log_exception(exc, request_info)

            mock_traceback.format_exc.assert_called_once()
            log_message = mock_logger.error.call_args[0][0]
            assert "Traceback details..." in log_message


class TestBuildErrorResponse:
    """Test suite for build_error_response function."""

    @pytest.fixture
    def mock_config(self):
        """Mock configuration."""
        with patch(
            "src.main.app.libs.exception.exception_handler.config"
        ) as mock_config:
            mock_config.server.debug = False
            yield mock_config

    @pytest.fixture
    def mock_request(self):
        """Create a mock request."""
        return Mock(spec=Request)

    def test_build_error_response_production_mode(self, mock_config, mock_request):
        """Test building error response in production mode."""
        exc = ValueError("Sensitive error details")
        mock_config.server.debug = False

        with patch(
            "src.main.app.libs.exception.exception_handler.is_body_allowed_for_status_code",
            return_value=True,
        ):
            response = exception_handler.build_error_response(exc, mock_request, 500)

            assert isinstance(response, JSONResponse)
            assert response.status_code == 200  # JSONResponse default

            # In production, should use generic message
            content = json.loads(response.body)
            assert content["error"]["message"] == "Internal server error"

    def test_build_error_response_debug_mode(self, mock_config, mock_request):
        """Test building error response in debug mode."""
        exc = ValueError("Detailed error message")
        mock_config.server.debug = True

        with patch(
            "src.main.app.libs.exception.exception_handler.is_body_allowed_for_status_code",
            return_value=True,
        ):
            response = exception_handler.build_error_response(exc, mock_request, 500)

            content = json.loads(response.body)
            assert content["error"]["message"] == "Detailed error message"

    def test_build_error_response_no_body_allowed(self, mock_config, mock_request):
        """Test building error response when body is not allowed."""
        exc = ValueError("Error")

        with patch(
            "src.main.app.libs.exception.exception_handler.is_body_allowed_for_status_code",
            return_value=False,
        ):
            response = exception_handler.build_error_response(exc, mock_request, 204)

            assert isinstance(response, Response)
            assert response.status_code == 204

    def test_build_error_response_with_headers(self, mock_config, mock_request):
        """Test building error response with custom headers."""
        exc = ValueError("Error")
        headers = {"X-Custom-Header": "custom-value"}

        with patch(
            "src.main.app.libs.exception.exception_handler.is_body_allowed_for_status_code",
            return_value=False,
        ):
            response = exception_handler.build_error_response(
                exc, mock_request, 500, headers
            )

            assert response.headers.get("X-Custom-Header") == "custom-value"


class TestExceptionHandlers:
    """Test suite for specific exception handlers."""

    @pytest.fixture
    def mock_request(self):
        """Create a mock request."""
        request = Mock(spec=Request)
        request.url.path = "/test"
        request.method = "GET"
        request.query_params = {}
        request.headers = {}
        request.client = None
        return request

    @pytest.mark.asyncio
    async def test_global_exception_handler(self, mock_request):
        """Test global exception handler."""
        exc = RuntimeError("Unexpected error")

        with (
            patch(
                "src.main.app.libs.exception.exception_handler.extract_request_data",
                return_value={},
            ),
            patch("src.main.app.libs.exception.exception_handler.log_exception"),
            patch(
                "src.main.app.libs.exception.exception_handler.build_error_response"
            ) as mock_build,
        ):
            mock_build.return_value = JSONResponse(content={"error": "mocked"})

            response = await exception_handler.global_exception_handler(
                mock_request, exc
            )

            mock_build.assert_called_once()
            assert isinstance(response, JSONResponse)

    @pytest.mark.asyncio
    async def test_validation_exception_handler(self, mock_request):
        """Test validation exception handler."""
        # Create a mock ValidationError
        exc = Mock(spec=ValidationError)
        exc.errors.return_value = [{"field": "email", "message": "invalid"}]

        with (
            patch(
                "src.main.app.libs.exception.exception_handler.extract_request_data",
                return_value={},
            ),
            patch("src.main.app.libs.exception.exception_handler.log_exception"),
        ):
            response = await exception_handler.validation_exception_handler(
                mock_request, exc
            )

            assert isinstance(response, JSONResponse)
            content = json.loads(response.body)
            assert content["error"]["code"] == HTTPStatus.INTERNAL_SERVER_ERROR.value

    @pytest.mark.asyncio
    async def test_custom_exception_handler_auth_error(self, mock_request):
        """Test custom exception handler with auth error."""
        error_code = ExceptionCode(code=HTTPStatus.UNAUTHORIZED, message="Unauthorized")
        exc = HTTPException(code=error_code)

        with (
            patch(
                "src.main.app.libs.exception.exception_handler.extract_request_data",
                return_value={},
            ),
            patch("src.main.app.libs.exception.exception_handler.log_exception"),
        ):
            response = await exception_handler.custom_exception_handler(
                mock_request, exc
            )

            assert isinstance(response, JSONResponse)
            assert response.status_code == HTTPStatus.UNAUTHORIZED.value

    @pytest.mark.asyncio
    async def test_custom_exception_handler_non_auth_error(self, mock_request):
        """Test custom exception handler with non-auth error."""
        error_code = ExceptionCode(code=HTTPStatus.BAD_REQUEST, message="Bad request")
        exc = HTTPException(code=error_code)

        with (
            patch(
                "src.main.app.libs.exception.exception_handler.extract_request_data",
                return_value={},
            ),
            patch("src.main.app.libs.exception.exception_handler.log_exception"),
        ):
            response = await exception_handler.custom_exception_handler(
                mock_request, exc
            )

            assert isinstance(response, JSONResponse)
            content = json.loads(response.body)
            assert content["error"]["code"] == HTTPStatus.BAD_REQUEST

    @pytest.mark.asyncio
    async def test_request_validation_exception_handler(self, mock_request):
        """Test request validation exception handler."""
        exc = Mock(spec=RequestValidationError)
        exc.errors.return_value = [{"field": "name", "message": "required"}]

        with (
            patch(
                "src.main.app.libs.exception.exception_handler.extract_request_data",
                return_value={},
            ),
            patch("src.main.app.libs.exception.exception_handler.log_exception"),
        ):
            response = await exception_handler.request_validation_exception_handler(
                mock_request, exc
            )

            assert isinstance(response, JSONResponse)
            content = json.loads(response.body)
            assert content["error"]["code"] == HTTPStatus.UNPROCESSABLE_ENTITY.value

    @pytest.mark.asyncio
    async def test_custom_http_exception_handler(self, mock_request):
        """Test custom HTTP exception handler."""
        exc = StarletteHTTPException(status_code=404, detail="Not found")

        with (
            patch(
                "src.main.app.libs.exception.exception_handler.extract_request_data",
                return_value={},
            ),
            patch("src.main.app.libs.exception.exception_handler.log_exception"),
            patch(
                "src.main.app.libs.exception.exception_handler.http_exception_handler"
            ) as mock_handler,
        ):
            mock_handler.return_value = JSONResponse(content={"detail": "Not found"})

            response = await exception_handler.custom_http_exception_handler(
                mock_request, exc
            )

            mock_handler.assert_called_once_with(mock_request, exc)

    @pytest.mark.asyncio
    async def test_jwt_exception_handler(self, mock_request):
        """Test JWT exception handler."""
        with (
            patch(
                "src.main.app.libs.exception.exception_handler.extract_request_data",
                return_value={},
            ),
            patch("src.main.app.libs.exception.exception_handler.log_exception"),
        ):
            response = await exception_handler.jwt_exception_handler(mock_request)

            assert isinstance(response, JSONResponse)
            assert response.status_code == HTTPStatus.UNAUTHORIZED.value
            content = json.loads(response.body)
            assert "token has expired" in content["message"].lower()


class TestIsAuthErrorsCode:
    """Test suite for is_auth_errors_code function."""

    def test_is_auth_errors_code_unauthorized(self):
        """Test that UNAUTHORIZED code is recognized as auth error."""
        result = exception_handler.is_auth_errors_code(HTTPStatus.UNAUTHORIZED.value)
        assert result is True

    def test_is_auth_errors_code_non_auth_error(self):
        """Test that non-auth codes are not recognized as auth errors."""
        assert (
            exception_handler.is_auth_errors_code(HTTPStatus.BAD_REQUEST.value) is False
        )
        assert (
            exception_handler.is_auth_errors_code(HTTPStatus.NOT_FOUND.value) is False
        )
        assert (
            exception_handler.is_auth_errors_code(
                HTTPStatus.INTERNAL_SERVER_ERROR.value
            )
            is False
        )

    def test_is_auth_errors_code_forbidden(self):
        """Test that FORBIDDEN code is not recognized as auth error in current implementation."""
        # Note: Current implementation only checks for UNAUTHORIZED
        result = exception_handler.is_auth_errors_code(HTTPStatus.FORBIDDEN.value)
        assert result is False


class TestExceptionHandlingIntegration:
    """Integration tests for exception handling workflow."""

    @pytest.mark.asyncio
    async def test_complete_exception_handling_workflow(self):
        """Test complete exception handling from registration to response."""
        app = FastAPI()
        register_exception_handlers(app)

        # Create a custom exception
        error_code = ExceptionCode(code=400, message="Custom error")
        exc = HTTPException(code=error_code, message="Custom message")

        # Mock request
        request = Mock(spec=Request)
        request.url.path = "/test"
        request.method = "POST"
        request.query_params = {}
        request.headers = {"content-type": "application/json"}
        request.client = None

        with (
            patch(
                "src.main.app.libs.exception.exception_handler.extract_request_data",
                return_value={"json": {"test": "data"}},
            ),
            patch("src.main.app.libs.exception.exception_handler.log_exception"),
        ):
            # Get the registered handler
            handler = app.exception_handlers[HTTPException]
            response = await handler(request, exc)

            assert isinstance(response, JSONResponse)
            content = json.loads(response.body)
            assert content["error"]["code"] == 400
            assert content["error"]["message"] == "Custom message"

    @pytest.mark.asyncio
    async def test_exception_data_extraction_workflow(self):
        """Test that exception handlers properly extract request data."""
        request = Mock(spec=Request)
        request.url.path = "/api/test"
        request.method = "POST"
        request.query_params = {"param": "value"}
        request.headers = {
            "content-type": "application/json",
            "authorization": "Bearer token",
        }
        request.client.host = "192.168.1.1"
        request.client.port = 3000
        request.json = AsyncMock(return_value={"field": "value"})

        exc = ValueError("Test error")

        with (
            patch(
                "src.main.app.libs.exception.exception_handler.log_exception"
            ) as mock_log,
            patch(
                "src.main.app.libs.exception.exception_handler.build_error_response",
                return_value=JSONResponse(content={}),
            ),
        ):
            await exception_handler.global_exception_handler(request, exc)

            # Verify that log_exception was called with comprehensive request info
            mock_log.assert_called_once()
            request_info = mock_log.call_args[0][1]

            assert request_info["path"] == "/api/test"
            assert request_info["method"] == "POST"
            assert request_info["query_params"]["param"] == "value"
            assert "authorization" in request_info["headers"]
            assert request_info["client"] == "192.168.1.1:3000"
            assert request_info["data"]["json"]["field"] == "value"
