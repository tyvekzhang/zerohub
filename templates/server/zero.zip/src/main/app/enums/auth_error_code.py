# SPDX-License-Identifier: MIT
"""Authentication and authorization error codes (20000-29999)."""

from http import HTTPStatus

from src.main.app.libs.enums.base_error_code import ExceptionCode


class AuthErrorCode:
    """Authentication and authorization error codes."""

    AUTH_FAILED = ExceptionCode(
        code=HTTPStatus.UNAUTHORIZED, message="Username or password error"
    )
    TOKEN_EXPIRED = ExceptionCode(
        code=HTTPStatus.UNAUTHORIZED, message="Token has expired"
    )
    OPENAPI_FORBIDDEN = ExceptionCode(
        code=HTTPStatus.FORBIDDEN, message="OpenAPI is not ready"
    )
    MISSING_TOKEN = ExceptionCode(
        code=HTTPStatus.UNAUTHORIZED, message="Authentication token is missing"
    )
