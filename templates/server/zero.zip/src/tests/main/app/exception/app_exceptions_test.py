# SPDX-License-Identifier: MIT
"""Comprehensive unit tests for app-level exception classes."""

from typing import Any, Optional

from src.main.app.enums.auth_error_code import AuthErrorCode
from src.main.app.enums.biz_error_code import BusinessErrorCode
from src.main.app.enums.sys_error_code import SystemErrorCode
from src.main.app.exception.auth_exception import AuthException
from src.main.app.exception.biz_exception import BusinessException
from src.main.app.exception.sys_exception import SystemException
from src.main.app.libs.enums.base_error_code import ExceptionCode
from src.main.app.libs.exception.custom_exception import HTTPException


class TestAuthException:
    """Test suite for AuthException class."""

    def test_auth_exception_inheritance(self):
        """Test that AuthException inherits from HTTPException."""
        assert issubclass(AuthException, HTTPException)

    def test_auth_exception_attributes(self):
        """Test AuthException class attributes."""
        # Create an instance to test inherited attributes
        exception = AuthException(code=AuthErrorCode.AUTH_FAILED)

        # Check that instance has the expected attributes from parent
        assert hasattr(exception, "code")
        assert hasattr(exception, "message")
        assert hasattr(exception, "details")

    def test_auth_exception_type_annotations(self):
        """Test AuthException type annotations."""

        annotations = AuthException.__annotations__

        assert "code" in annotations
        assert annotations["code"] == AuthErrorCode

        assert "message" in annotations
        assert annotations["message"] == Optional[str]

        assert "details" in annotations
        assert annotations["details"] == Optional[Any]

    def test_auth_exception_creation_with_error_code(self):
        """Test creating AuthException with AuthErrorCode."""
        # Test that AuthException can be created (though it's primarily a type annotation class)
        exception = AuthException(code=AuthErrorCode.AUTH_FAILED)

        assert isinstance(exception, AuthException)
        assert isinstance(exception, HTTPException)
        assert exception.code == AuthErrorCode.AUTH_FAILED

    def test_auth_exception_creation_with_message(self):
        """Test creating AuthException with custom message."""
        custom_message = "Custom authentication error"
        exception = AuthException(
            code=AuthErrorCode.TOKEN_EXPIRED, message=custom_message
        )

        assert exception.code == AuthErrorCode.TOKEN_EXPIRED
        assert exception.message == custom_message

    def test_auth_exception_creation_with_details(self):
        """Test creating AuthException with details."""
        details = {"user_id": 123, "attempted_action": "access_admin"}
        exception = AuthException(code=AuthErrorCode.MISSING_TOKEN, details=details)

        assert exception.code == AuthErrorCode.MISSING_TOKEN
        assert exception.details == details

    def test_auth_exception_with_all_parameters(self):
        """Test creating AuthException with all parameters."""
        custom_message = "Detailed auth error"
        details = {"error_context": "login_attempt"}

        exception = AuthException(
            code=AuthErrorCode.OPENAPI_FORBIDDEN,
            message=custom_message,
            details=details,
        )

        assert exception.code == AuthErrorCode.OPENAPI_FORBIDDEN
        assert exception.message == custom_message
        assert exception.details == details

    def test_auth_exception_code_validation(self):
        """Test that AuthException validates code type."""
        # Should work with AuthErrorCode
        exception = AuthException(code=AuthErrorCode.AUTH_FAILED)
        assert exception.code == AuthErrorCode.AUTH_FAILED

        # The actual validation depends on the parent HTTPException implementation

    def test_auth_exception_default_values(self):
        """Test AuthException default values."""
        exception = AuthException(code=AuthErrorCode.AUTH_FAILED)

        # Message should default to None but get set by parent class
        assert exception.message is not None  # Set by parent __post_init__
        assert exception.details is None  # Should remain None


class TestBusinessException:
    """Test suite for BusinessException class."""

    def test_business_exception_inheritance(self):
        """Test that BusinessException inherits from HTTPException."""
        assert issubclass(BusinessException, HTTPException)

    def test_business_exception_init_method(self):
        """Test BusinessException __init__ method."""
        import inspect

        init_signature = inspect.signature(BusinessException.__init__)
        params = list(init_signature.parameters.keys())

        expected_params = ["self", "code", "message", "details"]
        assert params == expected_params

    def test_business_exception_creation(self):
        """Test creating BusinessException."""
        error_code = BusinessErrorCode.USER_NAME_EXISTS
        exception = BusinessException(code=error_code)

        assert isinstance(exception, BusinessException)
        assert isinstance(exception, HTTPException)
        assert exception.code == error_code

    def test_business_exception_creation_with_message(self):
        """Test creating BusinessException with custom message."""
        error_code = BusinessErrorCode.MENU_NAME_EXISTS
        custom_message = "Custom business error message"

        exception = BusinessException(code=error_code, message=custom_message)

        assert exception.code == error_code
        assert exception.message == custom_message

    def test_business_exception_creation_with_details(self):
        """Test creating BusinessException with details."""
        error_code = BusinessErrorCode.RESOURCE_NOT_FOUND
        details = {"resource_type": "user", "resource_id": 123}

        exception = BusinessException(code=error_code, details=details)

        assert exception.code == error_code
        assert exception.details == details

    def test_business_exception_with_all_parameters(self):
        """Test creating BusinessException with all parameters."""
        error_code = BusinessErrorCode.PARAMETER_ERROR
        custom_message = "Invalid parameter provided"
        details = {"parameter": "email", "value": "invalid-email"}

        exception = BusinessException(
            code=error_code, message=custom_message, details=details
        )

        assert exception.code == error_code
        assert exception.message == custom_message
        assert exception.details == details

    def test_business_exception_super_call(self):
        """Test that BusinessException calls parent constructor."""
        error_code = BusinessErrorCode.USER_NAME_EXISTS
        message = "Test message"
        details = {"test": "data"}

        exception = BusinessException(code=error_code, message=message, details=details)

        # Verify that parent initialization was called
        assert hasattr(exception, "code")
        assert hasattr(exception, "message")
        assert hasattr(exception, "details")
        assert exception.code == error_code
        assert exception.message == message
        assert exception.details == details

    def test_business_exception_with_exception_code(self):
        """Test BusinessException with generic ExceptionCode."""
        generic_code = ExceptionCode(code=400, message="Generic business error")

        exception = BusinessException(code=generic_code)

        assert exception.code == generic_code

    def test_business_exception_parameter_types(self):
        """Test BusinessException parameter type annotations."""
        import inspect

        init_signature = inspect.signature(BusinessException.__init__)

        # Check parameter annotations
        code_param = init_signature.parameters["code"]
        message_param = init_signature.parameters["message"]
        details_param = init_signature.parameters["details"]

        assert code_param.annotation == ExceptionCode
        assert message_param.annotation == Optional[str]
        assert details_param.annotation == Optional[Any]

        # Check default values
        assert message_param.default is None
        assert details_param.default is None


class TestSystemException:
    """Test suite for SystemException class."""

    def test_system_exception_inheritance(self):
        """Test that SystemException inherits from HTTPException."""
        assert issubclass(SystemException, HTTPException)

    def test_system_exception_attributes(self):
        """Test SystemException class attributes."""
        # Create an instance to test inherited attributes
        exception = SystemException(code=SystemErrorCode.INTERNAL_ERROR)

        # Check that instance has the expected attributes from parent
        assert hasattr(exception, "code")
        assert hasattr(exception, "message")
        assert hasattr(exception, "details")

    def test_system_exception_type_annotations(self):
        """Test SystemException type annotations."""
        annotations = SystemException.__annotations__

        assert "code" in annotations
        assert annotations["code"] == SystemErrorCode

        assert "message" in annotations
        assert annotations["message"] == Optional[str]

        assert "details" in annotations
        assert annotations["details"] == Optional[Any]

    def test_system_exception_creation(self):
        """Test creating SystemException."""
        exception = SystemException(code=SystemErrorCode.INTERNAL_ERROR)

        assert isinstance(exception, SystemException)
        assert isinstance(exception, HTTPException)
        assert exception.code == SystemErrorCode.INTERNAL_ERROR

    def test_system_exception_creation_with_message(self):
        """Test creating SystemException with custom message."""
        custom_message = "System failure detected"
        exception = SystemException(
            code=SystemErrorCode.INTERNAL_ERROR, message=custom_message
        )

        assert exception.code == SystemErrorCode.INTERNAL_ERROR
        assert exception.message == custom_message

    def test_system_exception_creation_with_details(self):
        """Test creating SystemException with details."""
        details = {"subsystem": "database", "error_type": "connection_timeout"}
        exception = SystemException(
            code=SystemErrorCode.INTERNAL_ERROR, details=details
        )

        assert exception.code == SystemErrorCode.INTERNAL_ERROR
        assert exception.details == details

    def test_system_exception_with_all_parameters(self):
        """Test creating SystemException with all parameters."""
        custom_message = "Critical system error"
        details = {"severity": "critical", "component": "auth_service"}

        exception = SystemException(
            code=SystemErrorCode.INTERNAL_ERROR, message=custom_message, details=details
        )

        assert exception.code == SystemErrorCode.INTERNAL_ERROR
        assert exception.message == custom_message
        assert exception.details == details

    def test_system_exception_default_values(self):
        """Test SystemException default values."""
        exception = SystemException(code=SystemErrorCode.INTERNAL_ERROR)

        # Message should be set by parent class
        assert exception.message is not None
        assert exception.details is None


class TestExceptionClassComparison:
    """Test comparisons and relationships between exception classes."""

    def test_all_exceptions_inherit_from_http_exception(self):
        """Test that all custom exceptions inherit from HTTPException."""
        assert issubclass(AuthException, HTTPException)
        assert issubclass(BusinessException, HTTPException)
        assert issubclass(SystemException, HTTPException)

    def test_exception_class_hierarchy(self):
        """Test exception class hierarchy."""
        # All should inherit from base Exception
        assert issubclass(AuthException, Exception)
        assert issubclass(BusinessException, Exception)
        assert issubclass(SystemException, Exception)

        # All should inherit from HTTPException
        assert issubclass(AuthException, HTTPException)
        assert issubclass(BusinessException, HTTPException)
        assert issubclass(SystemException, HTTPException)

    def test_exception_types_are_distinct(self):
        """Test that exception types are distinct classes."""
        assert AuthException != BusinessException
        assert AuthException != SystemException
        assert BusinessException != SystemException

    def test_exception_instances_are_correct_types(self):
        """Test that exception instances have correct types."""
        auth_exc = AuthException(code=AuthErrorCode.AUTH_FAILED)
        biz_exc = BusinessException(code=BusinessErrorCode.USER_NAME_EXISTS)
        sys_exc = SystemException(code=SystemErrorCode.INTERNAL_ERROR)

        assert isinstance(auth_exc, AuthException)
        assert isinstance(biz_exc, BusinessException)
        assert isinstance(sys_exc, SystemException)

        # All should also be HTTPException
        assert isinstance(auth_exc, HTTPException)
        assert isinstance(biz_exc, HTTPException)
        assert isinstance(sys_exc, HTTPException)

    def test_exception_error_code_compatibility(self):
        """Test that exceptions work with their respective error codes."""
        # AuthException with AuthErrorCode
        auth_exc = AuthException(code=AuthErrorCode.TOKEN_EXPIRED)
        assert auth_exc.code == AuthErrorCode.TOKEN_EXPIRED

        # BusinessException with BusinessErrorCode
        biz_exc = BusinessException(code=BusinessErrorCode.PARAMETER_ERROR)
        assert biz_exc.code == BusinessErrorCode.PARAMETER_ERROR

        # SystemException with SystemErrorCode
        sys_exc = SystemException(code=SystemErrorCode.INTERNAL_ERROR)
        assert sys_exc.code == SystemErrorCode.INTERNAL_ERROR


class TestExceptionUsageScenarios:
    """Test practical usage scenarios for exceptions."""

    def test_auth_exception_usage_scenarios(self):
        """Test AuthException in realistic scenarios."""
        # Login failure
        login_failure = AuthException(
            code=AuthErrorCode.AUTH_FAILED,
            message="Invalid username or password",
            details={"username": "user123", "timestamp": "2024-01-01T10:00:00Z"},
        )

        assert login_failure.code == AuthErrorCode.AUTH_FAILED
        assert "Invalid username" in login_failure.message
        assert login_failure.details["username"] == "user123"

        # Token expiration
        token_expired = AuthException(
            code=AuthErrorCode.TOKEN_EXPIRED,
            message="JWT token has expired",
            details={"token_type": "access", "expired_at": "2024-01-01T12:00:00Z"},
        )

        assert token_expired.code == AuthErrorCode.TOKEN_EXPIRED
        assert token_expired.details["token_type"] == "access"

    def test_business_exception_usage_scenarios(self):
        """Test BusinessException in realistic scenarios."""
        # User already exists
        user_exists = BusinessException(
            code=BusinessErrorCode.USER_NAME_EXISTS,
            message="A user with this username already exists",
            details={
                "username": "john_doe",
                "suggested_alternatives": ["john_doe_2", "john_doe_3"],
            },
        )

        assert user_exists.code == BusinessErrorCode.USER_NAME_EXISTS
        assert "already exists" in user_exists.message
        assert "suggested_alternatives" in user_exists.details

        # Resource not found
        resource_not_found = BusinessException(
            code=BusinessErrorCode.RESOURCE_NOT_FOUND,
            message="The requested user was not found",
            details={"resource_type": "user", "resource_id": 12345},
        )

        assert resource_not_found.code == BusinessErrorCode.RESOURCE_NOT_FOUND
        assert resource_not_found.details["resource_id"] == 12345

    def test_system_exception_usage_scenarios(self):
        """Test SystemException in realistic scenarios."""
        # Database connection failure
        db_failure = SystemException(
            code=SystemErrorCode.INTERNAL_ERROR,
            message="Database connection failed",
            details={
                "error_type": "connection_timeout",
                "database": "postgres",
                "host": "localhost:5432",
                "retry_count": 3,
            },
        )

        assert db_failure.code == SystemErrorCode.INTERNAL_ERROR
        assert "Database connection" in db_failure.message
        assert db_failure.details["retry_count"] == 3

        # Service unavailable
        service_unavailable = SystemException(
            code=SystemErrorCode.INTERNAL_ERROR,
            message="External service is currently unavailable",
            details={"service_name": "payment_processor", "status": "down"},
        )

        assert service_unavailable.details["service_name"] == "payment_processor"

    def test_exception_chaining_scenarios(self):
        """Test exception chaining and context scenarios."""
        # Simulate nested exception handling
        try:
            # This would typically be a database operation
            raise ConnectionError("Database unreachable")
        except ConnectionError as e:
            # Wrap in system exception
            system_exc = SystemException(
                code=SystemErrorCode.INTERNAL_ERROR,
                message="Database operation failed",
                details={"original_error": str(e), "operation": "user_lookup"},
            )

            assert "Database unreachable" in system_exc.details["original_error"]
            assert system_exc.details["operation"] == "user_lookup"

    def test_exception_serialization_scenarios(self):
        """Test exception serialization for API responses."""
        # Create exceptions with various data types
        complex_details = {
            "validation_errors": [
                {"field": "email", "error": "invalid_format"},
                {"field": "age", "error": "out_of_range"},
            ],
            "request_id": "req_123456",
            "timestamp": "2024-01-01T10:00:00Z",
        }

        biz_exc = BusinessException(
            code=BusinessErrorCode.PARAMETER_ERROR,
            message="Multiple validation errors",
            details=complex_details,
        )

        assert len(biz_exc.details["validation_errors"]) == 2
        assert biz_exc.details["request_id"] == "req_123456"


class TestExceptionDocumentation:
    """Test exception class documentation and metadata."""

    def test_exception_module_docstrings(self):
        """Test that exception modules have proper docstrings."""
        import src.main.app.exception.auth_exception as auth_mod
        import src.main.app.exception.biz_exception as biz_mod
        import src.main.app.exception.sys_exception as sys_mod

        assert auth_mod.__doc__ is not None
        assert "Auth exception" in auth_mod.__doc__

        assert biz_mod.__doc__ is not None
        assert "Business exception" in biz_mod.__doc__

        assert sys_mod.__doc__ is not None
        assert "System exception" in sys_mod.__doc__

    def test_exception_class_names(self):
        """Test that exception class names follow conventions."""
        assert AuthException.__name__ == "AuthException"
        assert BusinessException.__name__ == "BusinessException"
        assert SystemException.__name__ == "SystemException"

        # All should end with "Exception"
        assert AuthException.__name__.endswith("Exception")
        assert BusinessException.__name__.endswith("Exception")
        assert SystemException.__name__.endswith("Exception")

    def test_exception_module_paths(self):
        """Test that exceptions are in correct modules."""
        assert AuthException.__module__ == "src.main.app.exception.auth_exception"
        assert BusinessException.__module__ == "src.main.app.exception.biz_exception"
        assert SystemException.__module__ == "src.main.app.exception.sys_exception"
