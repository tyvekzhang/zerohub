# SPDX-License-Identifier: MIT
"""Comprehensive unit tests for DB session middleware."""

import asyncio
from unittest.mock import AsyncMock, Mock, patch

import pytest
from sqlalchemy.engine import Engine
from sqlalchemy.engine.url import URL
from sqlmodel.ext.asyncio.session import AsyncSession
from starlette.requests import Request
from starlette.types import ASGIApp

from src.main.app.libs.middleware.db_session_middleware import (
    SQLAlchemyMiddleware,
    create_middleware_and_session_proxy,
    db,
)


class TestCreateMiddlewareAndSessionProxy:
    """Test the factory function that creates middleware and session proxy."""

    def test_creates_middleware_and_session_classes(self):
        """Test that factory function creates both middleware and session classes."""
        middleware_cls, session_cls = create_middleware_and_session_proxy()

        assert middleware_cls is not None
        assert session_cls is not None
        assert hasattr(middleware_cls, "__init__")
        assert hasattr(middleware_cls, "dispatch")
        assert hasattr(session_cls, "__aenter__")
        assert hasattr(session_cls, "__aexit__")

    def test_creates_independent_instances(self):
        """Test that multiple calls create independent instances."""
        middleware1, session1 = create_middleware_and_session_proxy()
        middleware2, session2 = create_middleware_and_session_proxy()

        # They should be different classes (independent closures)
        assert middleware1 is not middleware2
        assert session1 is not session2


class TestSQLAlchemyMiddleware:
    """Test suite for SQLAlchemy middleware."""

    @pytest.fixture
    def mock_app(self):
        """Create a mock ASGI app."""
        return Mock(spec=ASGIApp)

    @pytest.fixture
    def mock_engine(self):
        """Create a mock async engine."""
        return Mock(spec=Engine)

    def test_init_with_db_url(self, mock_app):
        """Test middleware initialization with database URL."""
        db_url = "postgresql+asyncpg://user:pass@localhost/test"

        with (
            patch(
                "src.main.app.libs.middleware.db_session_middleware.create_async_engine"
            ) as mock_create_engine,
            patch(
                "src.main.app.libs.middleware.db_session_middleware.async_sessionmaker"
            ) as mock_sessionmaker,
        ):
            mock_engine = Mock()
            mock_create_engine.return_value = mock_engine

            middleware = SQLAlchemyMiddleware(
                app=mock_app,
                db_url=db_url,
                engine_args={"pool_size": 10},
                session_args={
                    "autoflush": False
                }, # Use different session arg to avoid conflict
            )

            mock_create_engine.assert_called_once_with(db_url, pool_size=10)
            mock_sessionmaker.assert_called_once_with(
                mock_engine,
                class_=AsyncSession,
                expire_on_commit=False,
                autoflush=False,
            )

    def test_init_with_custom_engine(self, mock_app, mock_engine):
        """Test middleware initialization with custom engine."""
        with patch(
            "src.main.app.libs.middleware.db_session_middleware.async_sessionmaker"
        ) as mock_sessionmaker:
            middleware = SQLAlchemyMiddleware(
                app=mock_app, custom_engine=mock_engine, commit_on_exit=False
            )

            assert middleware.commit_on_exit is False
            mock_sessionmaker.assert_called_once_with(
                mock_engine, class_=AsyncSession, expire_on_commit=False
            )

    def test_init_raises_error_without_db_url_or_engine(self, mock_app):
        """Test that initialization raises ValueError when both db_url and custom_engine are missing."""
        with pytest.raises(
            ValueError, match="You need to pass a db_url or a custom_engine parameter"
        ):
            SQLAlchemyMiddleware(app=mock_app)

    def test_init_with_sqlalchemy_url_object(self, mock_app):
        """Test initialization with SQLAlchemy URL object."""
        url_obj = Mock(spec=URL)

        with (
            patch(
                "src.main.app.libs.middleware.db_session_middleware.create_async_engine"
            ) as mock_create_engine,
            patch(
                "src.main.app.libs.middleware.db_session_middleware.async_sessionmaker"
            ),
        ):
            middleware = SQLAlchemyMiddleware(app=mock_app, db_url=url_obj)

            mock_create_engine.assert_called_once_with(url_obj)

    @pytest.mark.asyncio
    async def test_dispatch_creates_session_context(self, mock_app):
        """Test that dispatch creates and manages session context."""
        request = Mock(spec=Request)

        async def mock_call_next(req):
            response = Mock()
            response.status_code = 200
            return response

        db_url = "sqlite+aiosqlite:///test.db"

        # Create new middleware and session classes for this test
        middleware_cls, session_cls = create_middleware_and_session_proxy()

        with (
            patch(
                "src.main.app.libs.middleware.db_session_middleware.create_async_engine"
            ) as mock_create_engine,
            patch(
                "src.main.app.libs.middleware.db_session_middleware.async_sessionmaker"
            ) as mock_sessionmaker,
        ):
            mock_engine = Mock()
            mock_create_engine.return_value = mock_engine
            mock_session_factory = Mock()
            mock_sessionmaker.return_value = mock_session_factory

            middleware = middleware_cls(app=mock_app, db_url=db_url)

            # Mock the session context manager
            mock_session_context = AsyncMock()
            mock_session_context.__aenter__ = AsyncMock(return_value=session_cls)
            mock_session_context.__aexit__ = AsyncMock(return_value=None)

            with patch.object(
                session_cls, "__new__", return_value=mock_session_context
            ):
                response = await middleware.dispatch(request, mock_call_next)

                assert response.status_code == 200
                mock_session_context.__aenter__.assert_called_once()
                mock_session_context.__aexit__.assert_called_once()


class TestDBSession:
    """Test suite for DBSession context manager."""

    def test_init_default_values(self):
        """Test DBSession initialization with default values."""
        session = db()

        assert session.token is None
        assert session.session_args == {}
        assert session.commit_on_exit is False

    def test_init_custom_values(self):
        """Test DBSession initialization with custom values."""
        session_args = {"autoflush": False}
        session = db(session_args=session_args, commit_on_exit=True)

        assert session.session_args == session_args
        assert session.commit_on_exit is True

    @pytest.mark.asyncio
    async def test_session_property_when_not_initialized(self):
        """Test that session property raises error when not initialized."""
        with pytest.raises(ValueError, match="Session is not initialised"):
            _ = db.session

    @pytest.mark.asyncio
    async def test_aenter_when_session_not_initialized(self):
        """Test that __aenter__ raises error when session factory not initialized."""
        # Create fresh middleware and session classes with no initialization
        middleware_cls, session_cls = create_middleware_and_session_proxy()
        session_instance = session_cls()

        with pytest.raises(ValueError, match="Session is not initialised"):
            async with session_instance:
                pass

    @pytest.mark.asyncio
    async def test_complete_session_lifecycle(self):
        """Test complete session lifecycle with proper setup."""
        # Create fresh middleware and session classes
        middleware_cls, session_cls = create_middleware_and_session_proxy()

        # Mock the session instance and factory
        mock_session_instance = AsyncMock(spec=AsyncSession)
        mock_session_factory = Mock()
        mock_session_factory.return_value = mock_session_instance

        # Initialize middleware first to set up the session factory
        with (
            patch(
                "src.main.app.libs.middleware.db_session_middleware.create_async_engine"
            ),
            patch(
                "src.main.app.libs.middleware.db_session_middleware.async_sessionmaker",
                return_value=mock_session_factory,
            ),
        ):
            mock_app = Mock()
            middleware = middleware_cls(app=mock_app, db_url="sqlite:///test.db")

            # Now test the session context manager directly
            session_context = session_cls(commit_on_exit=True)

            # Manually set the session factory in the closure
            # This simulates what the middleware does
            with patch(
                "src.main.app.libs.middleware.db_session_middleware.create_middleware_and_session_proxy"
            ) as mock_create:
                # Create a working context manager
                mock_context_var = Mock()
                mock_token = "test_token"
                mock_context_var.set.return_value = mock_token
                mock_context_var.get.return_value = mock_session_instance

                # Mock the global variables in the closure
                with patch.dict(
                    "src.main.app.libs.middleware.db_session_middleware.__dict__",
                    {"_Session": mock_session_factory, "_session": mock_context_var},
                ):
                    # Test entering context
                    result = await session_context.__aenter__()
                    assert result == session_cls

                    # Test exiting context successfully
                    await session_context.__aexit__(None, None, None)
                    mock_session_instance.commit.assert_called_once()
                    mock_session_instance.close.assert_called_once()

    @pytest.mark.asyncio
    async def test_session_rollback_on_exception(self):
        """Test that session is rolled back when exception occurs."""
        # Create fresh middleware and session classes
        middleware_cls, session_cls = create_middleware_and_session_proxy()

        mock_session_instance = AsyncMock(spec=AsyncSession)
        mock_session_factory = Mock()
        mock_session_factory.return_value = mock_session_instance

        with (
            patch(
                "src.main.app.libs.middleware.db_session_middleware.create_async_engine"
            ),
            patch(
                "src.main.app.libs.middleware.db_session_middleware.async_sessionmaker",
                return_value=mock_session_factory,
            ),
        ):
            mock_app = Mock()
            middleware = middleware_cls(app=mock_app, db_url="sqlite:///test.db")

            session_context = session_cls(commit_on_exit=True)

            # Mock the context variable
            mock_context_var = Mock()
            mock_token = "test_token"
            mock_context_var.set.return_value = mock_token
            mock_context_var.get.return_value = mock_session_instance

            with patch.dict(
                "src.main.app.libs.middleware.db_session_middleware.__dict__",
                {"_Session": mock_session_factory, "_session": mock_context_var},
            ):
                await session_context.__aenter__()

                # Test exiting with exception
                await session_context.__aexit__(
                    ValueError, ValueError("test error"), None
                )

                mock_session_instance.rollback.assert_called_once()
                mock_session_instance.commit.assert_not_called()
                mock_session_instance.close.assert_called_once()

    @pytest.mark.asyncio
    async def test_session_no_commit_when_disabled(self):
        """Test that session is not committed when commit_on_exit is False."""
        # Create fresh middleware and session classes
        middleware_cls, session_cls = create_middleware_and_session_proxy()

        mock_session_instance = AsyncMock(spec=AsyncSession)
        mock_session_factory = Mock()
        mock_session_factory.return_value = mock_session_instance

        with (
            patch(
                "src.main.app.libs.middleware.db_session_middleware.create_async_engine"
            ),
            patch(
                "src.main.app.libs.middleware.db_session_middleware.async_sessionmaker",
                return_value=mock_session_factory,
            ),
        ):
            mock_app = Mock()
            middleware = middleware_cls(app=mock_app, db_url="sqlite:///test.db")

            session_context = session_cls(commit_on_exit=False)

            mock_context_var = Mock()
            mock_token = "test_token"
            mock_context_var.set.return_value = mock_token
            mock_context_var.get.return_value = mock_session_instance

            with patch.dict(
                "src.main.app.libs.middleware.db_session_middleware.__dict__",
                {"_Session": mock_session_factory, "_session": mock_context_var},
            ):
                await session_context.__aenter__()
                await session_context.__aexit__(None, None, None)

                mock_session_instance.commit.assert_not_called()
                mock_session_instance.rollback.assert_not_called()
                mock_session_instance.close.assert_called_once()


class TestDBSessionMeta:
    """Test the metaclass behavior for DBSession."""

    def test_session_property_access(self):
        """Test that session property is accessible as class property."""
        # This tests the metaclass behavior
        assert hasattr(db.__class__, "session")
        assert isinstance(type(db).session, property)


class TestMiddlewareIntegration:
    """Integration tests for the middleware system."""

    @pytest.mark.asyncio
    async def test_full_request_cycle_with_session(self):
        """Test a complete request cycle with session management."""
        # Create fresh instances
        middleware_cls, session_cls = create_middleware_and_session_proxy()

        request = Mock(spec=Request)
        request.method = "GET"
        request.url = Mock()
        request.url.path = "/api/test"

        session_accessed = False

        async def call_next_with_db_access(req):
            nonlocal session_accessed
            try:
                # This would normally access db.session
                session_accessed = True
                response = Mock()
                response.status_code = 200
                return response
            except Exception:
                # Handle case where session is not properly set up
                response = Mock()
                response.status_code = 500
                return response

        mock_app = Mock(spec=ASGIApp)

        with (
            patch(
                "src.main.app.libs.middleware.db_session_middleware.create_async_engine"
            ) as mock_create_engine,
            patch(
                "src.main.app.libs.middleware.db_session_middleware.async_sessionmaker"
            ) as mock_sessionmaker,
        ):
            mock_engine = Mock()
            mock_create_engine.return_value = mock_engine
            mock_session_factory = AsyncMock()
            mock_sessionmaker.return_value = mock_session_factory

            middleware = middleware_cls(
                app=mock_app,
                db_url="postgresql://test:test@localhost/test",
                commit_on_exit=True,
            )

            # Mock the session context
            mock_session_context = AsyncMock()
            mock_session_context.__aenter__ = AsyncMock(return_value=session_cls)
            mock_session_context.__aexit__ = AsyncMock(return_value=None)

            with patch.object(
                session_cls, "__new__", return_value=mock_session_context
            ):
                response = await middleware.dispatch(request, call_next_with_db_access)

                assert response.status_code == 200
                assert session_accessed

    @pytest.mark.asyncio
    async def test_concurrent_sessions_isolation(self):
        """Test that concurrent requests have isolated sessions."""
        middleware_cls, session_cls = create_middleware_and_session_proxy()

        results = []

        async def simulate_request(request_id):
            """Simulate a request that uses database session."""
            request = Mock(spec=Request)

            async def call_next(req):
                # Simulate some database work
                await asyncio.sleep(0.01)
                response = Mock()
                response.status_code = 200
                response.request_id = request_id
                return response

            mock_app = Mock(spec=ASGIApp)

            with (
                patch(
                    "src.main.app.libs.middleware.db_session_middleware.create_async_engine"
                ),
                patch(
                    "src.main.app.libs.middleware.db_session_middleware.async_sessionmaker"
                ),
            ):
                middleware = middleware_cls(
                    app=mock_app, db_url=f"sqlite:///test_{request_id}.db"
                )

                mock_session_context = AsyncMock()
                mock_session_context.__aenter__ = AsyncMock(return_value=session_cls)
                mock_session_context.__aexit__ = AsyncMock(return_value=None)

                with patch.object(
                    session_cls, "__new__", return_value=mock_session_context
                ):
                    response = await middleware.dispatch(request, call_next)
                    results.append(response.request_id)
                    return response

        # Run multiple concurrent requests
        tasks = [simulate_request(i) for i in range(5)]
        responses = await asyncio.gather(*tasks)

        # All requests should complete successfully
        assert len(responses) == 5
        assert all(r.status_code == 200 for r in responses)
        assert set(results) == {0, 1, 2, 3, 4}

    @pytest.mark.asyncio
    async def test_session_cleanup_on_middleware_exception(self):
        """Test that sessions are properly cleaned up when middleware raises exception."""
        middleware_cls, session_cls = create_middleware_and_session_proxy()

        request = Mock(spec=Request)

        async def failing_call_next(req):
            raise RuntimeError("Request processing failed")

        mock_app = Mock(spec=ASGIApp)

        with (
            patch(
                "src.main.app.libs.middleware.db_session_middleware.create_async_engine"
            ),
            patch(
                "src.main.app.libs.middleware.db_session_middleware.async_sessionmaker"
            ),
        ):
            middleware = middleware_cls(app=mock_app, db_url="sqlite:///test.db")

            mock_session_context = AsyncMock()
            mock_session_context.__aenter__ = AsyncMock(return_value=session_cls)
            mock_session_context.__aexit__ = AsyncMock(return_value=None)

            with patch.object(
                session_cls, "__new__", return_value=mock_session_context
            ):
                with pytest.raises(RuntimeError, match="Request processing failed"):
                    await middleware.dispatch(request, failing_call_next)

                # Session should still be properly cleaned up
                mock_session_context.__aenter__.assert_called_once()
                mock_session_context.__aexit__.assert_called_once()


class TestModuleExports:
    """Test the module-level exports."""

    def test_exported_classes_exist(self):
        """Test that the expected classes are exported at module level."""
        assert SQLAlchemyMiddleware is not None
        assert db is not None
        assert hasattr(SQLAlchemyMiddleware, "__init__")
        assert hasattr(SQLAlchemyMiddleware, "dispatch")
        assert hasattr(db, "__class__")

    def test_db_is_session_proxy_instance(self):
        """Test that db is an instance of the session proxy class."""
        # db should be an instance that provides session access
        assert hasattr(db.__class__, "session")
        # Should have context manager methods
        assert hasattr(db, "__aenter__")
        assert hasattr(db, "__aexit__")


class TestImportFallback:
    """Test the import fallback for older SQLAlchemy versions."""

    def test_async_sessionmaker_import_fallback(self):
        """Test that the fallback import works correctly."""
        # This test verifies the try/except import logic
        # The actual imports are tested by the module loading successfully

        # Test that the module can handle both import scenarios
        with patch("builtins.__import__", side_effect=ImportError):
            # This would test the ImportError case, but since the module
            # is already imported, we can't easily test this without
            # reimporting the module, which could cause issues
            pass

        # If we got here, the import worked (either async_sessionmaker or fallback)
        assert True
