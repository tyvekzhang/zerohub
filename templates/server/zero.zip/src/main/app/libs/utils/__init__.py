# SPDX-License-Identifier: MIT
"""Utility modules for the fast-web application."""