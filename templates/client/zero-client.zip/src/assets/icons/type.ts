export interface IconProps {
  size?: number;
  color?: string;
}
