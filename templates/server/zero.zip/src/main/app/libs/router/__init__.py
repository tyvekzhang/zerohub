"""Export router module."""

from src.main.app.libs.router.router_v1 import register_router

__all__ = [register_router]
