# SPDX-License-Identifier: MIT

import pytest

from src.main.app.libs.utils.str_util import snake_to_title


class TestSnakeToTitle:
    """Test suite for snake_to_title function."""

    def test_basic_snake_case_conversion(self):
        """Test basic snake_case to title conversion."""
        result = snake_to_title("hello_world")
        assert result == "Hello world"

    def test_single_word(self):
        """Test conversion of a single word."""
        result = snake_to_title("hello")
        assert result == "Hello"

    def test_multiple_words(self):
        """Test conversion with multiple words."""
        result = snake_to_title("this_is_a_test")
        assert result == "This is a test"

    def test_empty_string(self):
        """Test conversion of empty string."""
        result = snake_to_title("")
        assert result == ""

    def test_single_underscore(self):
        """Test conversion of single underscore."""
        result = snake_to_title("_")
        assert result == ""

    def test_multiple_underscores(self):
        """Test conversion with multiple consecutive underscores."""
        result = snake_to_title("hello___world")
        assert result == "Hello world"

    def test_leading_underscores(self):
        """Test conversion with leading underscores."""
        result = snake_to_title("__hello_world")
        assert result == "Hello world"

    def test_trailing_underscores(self):
        """Test conversion with trailing underscores."""
        result = snake_to_title("hello_world__")
        assert result == "Hello world"

    def test_leading_and_trailing_underscores(self):
        """Test conversion with both leading and trailing underscores."""
        result = snake_to_title("__hello_world__")
        assert result == "Hello world"

    def test_mixed_case_input(self):
        """Test conversion with mixed case input."""
        result = snake_to_title("Hello_World")
        assert result == "Hello world"

    def test_uppercase_input(self):
        """Test conversion with uppercase input."""
        result = snake_to_title("HELLO_WORLD")
        assert result == "Hello world"

    def test_numbers_in_string(self):
        """Test conversion with numbers in the string."""
        result = snake_to_title("hello_world_123")
        assert result == "Hello world 123"

    def test_numbers_only(self):
        """Test conversion with numbers only."""
        result = snake_to_title("123_456")
        assert result == "123 456"

    def test_special_characters_in_words(self):
        """Test conversion with special characters within words."""
        result = snake_to_title("hello@world_test")
        assert result == "Hello@world test"

    def test_whitespace_in_input(self):
        """Test conversion with whitespace in input."""
        result = snake_to_title("hello world_test")
        assert result == "Hello world test"

    def test_very_long_string(self):
        """Test conversion with a very long string."""
        long_snake = "_".join([f"word{i}" for i in range(10)])
        result = snake_to_title(long_snake)
        expected = "Word0 word1 word2 word3 word4 word5 word6 word7 word8 word9"
        assert result == expected

    def test_single_character_words(self):
        """Test conversion with single character words."""
        result = snake_to_title("a_b_c_d")
        assert result == "A b c d"

    def test_empty_segments(self):
        """Test conversion with empty segments between underscores."""
        result = snake_to_title("hello__world")
        assert result == "Hello world"

    def test_only_underscores(self):
        """Test conversion with only underscores."""
        result = snake_to_title("____")
        assert result == ""

    def test_unicode_characters(self):
        """Test conversion with unicode characters."""
        result = snake_to_title("hello_世界")
        assert result == "Hello 世界"

    def test_accented_characters(self):
        """Test conversion with accented characters."""
        result = snake_to_title("café_naïve")
        assert result == "Café naïve"

    def test_type_error_with_none(self):
        """Test that TypeError is raised when input is None."""
        with pytest.raises(TypeError, match="Input must be a string"):
            snake_to_title(None)

    def test_type_error_with_integer(self):
        """Test that TypeError is raised when input is an integer."""
        with pytest.raises(TypeError, match="Input must be a string"):
            snake_to_title(123)

    def test_type_error_with_list(self):
        """Test that TypeError is raised when input is a list."""
        with pytest.raises(TypeError, match="Input must be a string"):
            snake_to_title(["hello", "world"])

    def test_type_error_with_dict(self):
        """Test that TypeError is raised when input is a dictionary."""
        with pytest.raises(TypeError, match="Input must be a string"):
            snake_to_title({"hello": "world"})

    def test_type_error_with_boolean(self):
        """Test that TypeError is raised when input is a boolean."""
        with pytest.raises(TypeError, match="Input must be a string"):
            snake_to_title(True)

    def test_type_error_with_float(self):
        """Test that TypeError is raised when input is a float."""
        with pytest.raises(TypeError, match="Input must be a string"):
            snake_to_title(3.14)

    @pytest.mark.parametrize(
        "input_str,expected",
        [
            ("simple_test", "Simple test"),
            ("one_two_three", "One two three"),
            ("", ""),
            ("_", ""),
            ("a", "A"),
            ("a_b", "A b"),
            ("__test__", "Test"),
            ("UPPER_CASE", "Upper case"),
            ("Mixed_Case_String", "Mixed case string"),
            ("with_123_numbers", "With 123 numbers"),
            ("test_with_@_symbol", "Test with @ symbol"),
        ],
    )
    def test_parametrized_conversions(self, input_str, expected):
        """Parametrized test for various input-output combinations."""
        result = snake_to_title(input_str)
        assert result == expected

    def test_consistency_with_repeated_calls(self):
        """Test that the function returns consistent results across multiple calls."""
        input_str = "hello_world_test"
        expected = "Hello world test"

        for _ in range(5):
            result = snake_to_title(input_str)
            assert result == expected

    def test_edge_case_with_underscores_only_between_words(self):
        """Test edge case with exactly one underscore between each word."""
        result = snake_to_title("word1_word2_word3")
        assert result == "Word1 word2 word3"

    def test_edge_case_with_numeric_words(self):
        """Test edge case with purely numeric segments."""
        result = snake_to_title("123_456_789")
        assert result == "123 456 789"
