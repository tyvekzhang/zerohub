# SPDX-License-Identifier: MIT
"""Comprehensive unit tests for ConfigManager module functions."""

import os
from unittest.mock import MagicMock, patch

import pytest

from src.main.app.libs.config.config import Config
from src.main.app.libs.config.config_manager import (
    create_config_instance,
    get_database_url,
    list_available_configs,
    load_config,
    load_database_config,
    load_security_config,
    load_server_config,
    register_config_class,
)
from src.main.app.libs.config.config_registry import BaseConfig, ConfigRegistry
from src.main.app.libs.config.database_config import DatabaseConfig
from src.main.app.libs.config.security_config import SecurityConfig
from src.main.app.libs.config.server_config import ServerConfig


class TestConfigManagerFunctions:
    """Test cases for ConfigManager module functions."""

    def setup_method(self):
        """Set up test fixtures before each test method."""
        # Clear registry and cache before each test
        ConfigRegistry.clear_all()

        # Clear LRU cache for load functions
        load_config.cache_clear()
        load_server_config.cache_clear()
        load_database_config.cache_clear()
        load_security_config.cache_clear()

    def teardown_method(self):
        """Clean up after each test method."""
        # Clear registry and cache after each test
        ConfigRegistry.clear_all()

        # Clear LRU cache for load functions
        load_config.cache_clear()
        load_server_config.cache_clear()
        load_database_config.cache_clear()
        load_security_config.cache_clear()

    @patch.dict(os.environ, {"ENV": "test"}, clear=False)
    @patch("src.main.app.libs.config.config_manager.ConfigLoader")
    def test_load_config_success(self, mock_config_loader):
        """Test successful config loading."""
        # Setup mock
        mock_loader_instance = MagicMock()
        mock_config_loader.return_value = mock_loader_instance
        mock_loader_instance.load_config.return_value = {
            "server": {
                "name": "test-server",
                "host": "127.0.0.1",
                "port": 8080,
                "version": "1.0.0",
                "app_desc": "Test",
                "api_prefix": "/api",
                "workers": 1,
                "debug": True,
                "log_file_path": "/tmp/test.log",
                "win_tz": "UTC",
                "linux_tz": "UTC",
                "enable_rate_limit": False,
                "global_default_limits": "100/minute",
            },
            "database": {
                "pool_size": 5,
                "max_overflow": 10,
                "pool_recycle": 3600,
                "echo_sql": False,
                "pool_pre_ping": True,
                "enable_redis": False,
                "cache_host": "localhost",
                "cache_port": 6379,
                "cache_pass": "",
                "db_num": 0,
            },
            "security": {
                "enable": True,
                "enable_swagger": True,
                "algorithm": "HS256",
                "secret_key": "test-secret",
                "access_token_expire_minutes": 30,
                "refresh_token_expire_minutes": 10080,
                "white_list_routes": "/health",
                "backend_cors_origins": "*",
                "black_ip_list": "",
            },
        }

        # Call function
        config = load_config()

        # Verify
        assert isinstance(config, Config)
        mock_config_loader.assert_called_once_with("test", None)
        mock_loader_instance.load_config.assert_called_once()

    @patch.dict(os.environ, {"ENV": "prod"}, clear=False)
    @patch("src.main.app.libs.config.config_manager.ConfigLoader")
    def test_load_config_with_custom_file(self, mock_config_loader):
        """Test config loading with custom config file."""
        with patch.dict(os.environ, {"CONFIG_FILE": "/custom/config.yml"}, clear=False):
            # Setup mock
            mock_loader_instance = MagicMock()
            mock_config_loader.return_value = mock_loader_instance
            mock_loader_instance.load_config.return_value = {}

            # Call function
            config = load_config()

            # Verify environment variables are used
            mock_config_loader.assert_called_once_with("prod", "/custom/config.yml")

    @patch("src.main.app.libs.config.config_manager.ConfigLoader")
    def test_load_config_default_environment(self, mock_config_loader):
        """Test config loading with default environment when ENV not set."""
        with patch.dict(os.environ, {}, clear=False):
            # Ensure ENV is not in environment
            if "ENV" in os.environ:
                del os.environ["ENV"]
            # Setup mock
            mock_loader_instance = MagicMock()
            mock_config_loader.return_value = mock_loader_instance
            mock_loader_instance.load_config.return_value = {}

            # Call function
            config = load_config()

            # Verify default environment is used
            mock_config_loader.assert_called_once_with("dev", None)

    def test_load_config_caching(self):
        """Test that load_config results are cached."""
        with patch(
            "src.main.app.libs.config.config_manager.ConfigLoader"
        ) as mock_config_loader:
            # Setup mock
            mock_loader_instance = MagicMock()
            mock_config_loader.return_value = mock_loader_instance
            mock_loader_instance.load_config.return_value = {}

            # Call function multiple times
            config1 = load_config()
            config2 = load_config()

            # Verify same instance is returned due to caching
            assert config1 is config2

            # Verify ConfigLoader is only called once due to caching
            mock_config_loader.assert_called_once()

    @patch("src.main.app.libs.config.config_manager.load_config")
    def test_load_server_config_success(self, mock_load_config):
        """Test successful server config loading."""
        # Setup mock
        mock_config = MagicMock()
        mock_server_config = MagicMock(spec=ServerConfig)
        mock_config.server = mock_server_config
        mock_load_config.return_value = mock_config

        # Call function
        result = load_server_config()

        # Verify
        assert result is mock_server_config
        mock_load_config.assert_called_once()

    @patch("src.main.app.libs.config.config_manager.load_config")
    def test_load_database_config_success(self, mock_load_config):
        """Test successful database config loading."""
        # Setup mock
        mock_config = MagicMock()
        mock_database_config = MagicMock(spec=DatabaseConfig)
        mock_config.database = mock_database_config
        mock_load_config.return_value = mock_config

        # Call function
        result = load_database_config()

        # Verify
        assert result is mock_database_config
        mock_load_config.assert_called_once()

    @patch("src.main.app.libs.config.config_manager.load_config")
    def test_load_security_config_success(self, mock_load_config):
        """Test successful security config loading."""
        # Setup mock
        mock_config = MagicMock()
        mock_security_config = MagicMock(spec=SecurityConfig)
        mock_config.security = mock_security_config
        mock_load_config.return_value = mock_config

        # Call function
        result = load_security_config()

        # Verify
        assert result is mock_security_config
        mock_load_config.assert_called_once()

    def test_load_config_functions_caching(self):
        """Test that individual config load functions are cached."""
        with patch(
            "src.main.app.libs.config.config_manager.load_config"
        ) as mock_load_config:
            # Setup mock
            mock_config = MagicMock()
            mock_config.server = MagicMock()
            mock_config.database = MagicMock()
            mock_config.security = MagicMock()
            mock_load_config.return_value = mock_config

            # Call server config multiple times
            server1 = load_server_config()
            server2 = load_server_config()

            # Call database config multiple times
            db1 = load_database_config()
            db2 = load_database_config()

            # Call security config multiple times
            sec1 = load_security_config()
            sec2 = load_security_config()

            # Verify caching works
            assert server1 is server2
            assert db1 is db2
            assert sec1 is sec2

            # Each function should only call load_config once due to caching
            assert mock_load_config.call_count == 3

    @patch("src.main.app.libs.config.config_manager.ConfigLoader.load_yaml_file")
    def test_get_database_url_dev(self, mock_load_yaml):
        """Test getting database URL for dev environment."""
        # Setup mock
        mock_load_yaml.return_value = {"database": {"url": "sqlite:///dev.db"}}

        # Call function
        result = get_database_url(env="dev")

        # Verify
        assert result == "sqlite:///dev.db"

        # Verify correct config file was loaded
        call_args = mock_load_yaml.call_args[0][0]
        assert "config-dev.yml" in call_args

    @patch("src.main.app.libs.config.config_manager.ConfigLoader.load_yaml_file")
    def test_get_database_url_prod(self, mock_load_yaml):
        """Test getting database URL for prod environment."""
        # Setup mock
        mock_load_yaml.return_value = {
            "database": {"url": "postgresql://user:pass@localhost/prod_db"}
        }

        # Call function
        result = get_database_url(env="prod")

        # Verify
        assert result == "postgresql://user:pass@localhost/prod_db"

        # Verify correct config file was loaded
        call_args = mock_load_yaml.call_args[0][0]
        assert "config-prod.yml" in call_args

    @patch("src.main.app.libs.config.config_manager.ConfigLoader.load_yaml_file")
    def test_get_database_url_local(self, mock_load_yaml):
        """Test getting database URL for local environment."""
        # Setup mock
        mock_load_yaml.return_value = {"database": {"url": "sqlite:///local.db"}}

        # Call function
        result = get_database_url(env="local")

        # Verify
        assert result == "sqlite:///local.db"

        # Verify correct config file was loaded
        call_args = mock_load_yaml.call_args[0][0]
        assert "config-local.yml" in call_args

    def test_get_database_url_invalid_environment(self):
        """Test getting database URL with invalid environment raises AssertionError."""
        with pytest.raises(AssertionError):
            get_database_url(env="invalid")

    @patch("src.main.app.libs.config.config_manager.ConfigLoader.load_yaml_file")
    def test_get_database_url_missing_database_config(self, mock_load_yaml):
        """Test getting database URL when database config is missing."""
        # Setup mock
        mock_load_yaml.return_value = {
            "server": {"host": "127.0.0.1"}
            # Missing database section
        }

        # Call function and expect ValueError
        with pytest.raises(ValueError, match="database config not in: dev"):
            get_database_url(env="dev")

    def test_register_config_class_success(self):
        """Test successful config class registration."""

        class TestConfig(BaseConfig):
            def __init__(self, name: str = "test"):
                self.name = name

            def __str__(self) -> str:
                return f"TestConfig(name={self.name})"

        # Call function
        register_config_class("test_config", TestConfig)

        # Verify registration
        assert ConfigRegistry.get_config_class("test_config") == TestConfig
        assert "test_config" in ConfigRegistry.list_registered()

    def test_register_config_class_invalid_class(self):
        """Test registering invalid config class raises ValueError."""

        class InvalidConfig:
            pass

        with pytest.raises(ValueError, match="must inherit from BaseConfig"):
            register_config_class("invalid", InvalidConfig)

    def test_register_config_class_duplicate_name(self):
        """Test registering duplicate config class name raises ValueError."""

        class TestConfig1(BaseConfig):
            def __init__(self):
                pass

            def __str__(self) -> str:
                return "TestConfig1"

        class TestConfig2(BaseConfig):
            def __init__(self):
                pass

            def __str__(self) -> str:
                return "TestConfig2"

        register_config_class("duplicate", TestConfig1)

        with pytest.raises(ValueError, match="already registered"):
            register_config_class("duplicate", TestConfig2)

    def test_create_config_instance_success(self):
        """Test successful config instance creation."""

        class TestConfig(BaseConfig):
            def __init__(self, name: str = "default", value: int = 0):
                self.name = name
                self.value = value

            def __str__(self) -> str:
                return f"TestConfig(name={self.name}, value={self.value})"

        register_config_class("test_config", TestConfig)

        config_data = {"name": "test", "value": 42}
        instance = create_config_instance("test_config", config_data)

        assert instance is not None
        assert isinstance(instance, TestConfig)
        assert instance.name == "test"
        assert instance.value == 42

    def test_create_config_instance_nonexistent_config(self):
        """Test creating instance of non-existent config returns None."""
        config_data = {"name": "test"}
        instance = create_config_instance("nonexistent", config_data)

        assert instance is None

    def test_create_config_instance_invalid_data(self):
        """Test creating instance with invalid data raises ValueError."""

        class TestConfig(BaseConfig):
            def __init__(self, required_param: str):
                self.required_param = required_param

            def __str__(self) -> str:
                return f"TestConfig(required_param={self.required_param})"

        register_config_class("test_config", TestConfig)

        config_data = {}  # Missing required_param

        with pytest.raises(
            ValueError, match="Failed to create test_config config instance"
        ):
            create_config_instance("test_config", config_data)

    def test_list_available_configs_empty(self):
        """Test listing available configs when registry is empty."""
        result = list_available_configs()
        assert result == []

    def test_list_available_configs_multiple(self):
        """Test listing multiple available configs."""

        class TestConfig1(BaseConfig):
            def __init__(self):
                pass

            def __str__(self) -> str:
                return "TestConfig1"

        class TestConfig2(BaseConfig):
            def __init__(self):
                pass

            def __str__(self) -> str:
                return "TestConfig2"

        register_config_class("config1", TestConfig1)
        register_config_class("config2", TestConfig2)

        result = list_available_configs()

        assert len(result) == 2
        assert "config1" in result
        assert "config2" in result

    def test_config_manager_integration(self):
        """Test integration between config manager functions."""

        # Register a custom config
        class CustomConfig(BaseConfig):
            def __init__(self, value: str = "default"):
                self.value = value

            def __str__(self) -> str:
                return f"CustomConfig(value={self.value})"

        register_config_class("custom", CustomConfig)

        # Verify it's listed
        available_configs = list_available_configs()
        assert "custom" in available_configs

        # Create instance
        instance = create_config_instance("custom", {"value": "test"})
        assert instance.value == "test"

        # Verify it's cached in registry
        cached_instance = ConfigRegistry.get_instance("custom")
        assert cached_instance is instance

    @patch("src.main.app.libs.config.config_manager.constant")
    def test_get_database_url_with_constants(self, mock_constant):
        """Test get_database_url uses constant module correctly."""
        mock_constant.RESOURCE_DIR = "/test/resource"

        with patch(
            "src.main.app.libs.config.config_manager.ConfigLoader.load_yaml_file"
        ) as mock_load_yaml:
            mock_load_yaml.return_value = {"database": {"url": "test://test"}}

            result = get_database_url(env="dev")

            # Verify the correct path is constructed
            call_args = mock_load_yaml.call_args[0][0]
            assert "/test/resource" in call_args
            assert "config-dev.yml" in call_args

    def test_global_config_variable_behavior(self):
        """Test the global config variable behavior in config_manager."""
        # This test ensures the global config variable is properly managed
        # Note: The global config variable is set in load_config function

        with patch(
            "src.main.app.libs.config.config_manager.ConfigLoader"
        ) as mock_config_loader:
            mock_loader_instance = MagicMock()
            mock_config_loader.return_value = mock_loader_instance
            mock_loader_instance.load_config.return_value = {}

            # First call should set the global config
            config1 = load_config()

            # Subsequent calls should return cached result
            config2 = load_config()

            assert config1 is config2

    def test_error_handling_in_load_functions(self):
        """Test error handling in individual load functions."""
        with patch(
            "src.main.app.libs.config.config_manager.load_config"
        ) as mock_load_config:
            # Simulate load_config raising an exception
            mock_load_config.side_effect = Exception("Config loading failed")

            with pytest.raises(Exception, match="Config loading failed"):
                load_server_config()

            with pytest.raises(Exception, match="Config loading failed"):
                load_database_config()

            with pytest.raises(Exception, match="Config loading failed"):
                load_security_config()
