# SPDX-License-Identifier: MIT
"""Comprehensive unit tests for individual config classes (ServerConfig, DatabaseConfig, SecurityConfig)."""

from unittest.mock import patch

from src.main.app.libs.config.config_registry import BaseConfig
from src.main.app.libs.config.database_config import DatabaseConfig
from src.main.app.libs.config.security_config import SecurityConfig
from src.main.app.libs.config.server_config import ServerConfig


class TestServerConfig:
    """Test cases for ServerConfig class."""

    def test_server_config_initialization_all_params(self):
        """Test ServerConfig initialization with all parameters."""
        config = ServerConfig(
            name="test-server",
            host="127.0.0.1",
            port=8080,
            version="1.0.0",
            app_desc="Test application",
            api_prefix="/api/v1",
            workers=4,
            debug=True,
            log_file_path="/tmp/test.log",
            win_tz="Eastern Standard Time",
            linux_tz="America/New_York",
            enable_rate_limit=True,
            global_default_limits="100/minute",
        )

        assert config.name == "test-server"
        assert config.host == "127.0.0.1"
        assert config.port == 8080
        assert config.version == "1.0.0"
        assert config.app_desc == "Test application"
        assert config.api_prefix == "/api/v1"
        assert config.workers == 4
        assert config.debug is True
        assert config.log_file_path == "/tmp/test.log"
        assert config.win_tz == "Eastern Standard Time"
        assert config.linux_tz == "America/New_York"
        assert config.enable_rate_limit is True
        assert config.global_default_limits == "100/minute"

    def test_server_config_inheritance(self):
        """Test that ServerConfig inherits from BaseConfig."""
        config = ServerConfig(
            name="test",
            host="localhost",
            port=3000,
            version="1.0",
            app_desc="Test",
            api_prefix="/api",
            workers=1,
            debug=False,
            log_file_path="/tmp/log",
            win_tz="UTC",
            linux_tz="UTC",
            enable_rate_limit=False,
            global_default_limits="50/minute",
        )

        assert isinstance(config, BaseConfig)
        assert isinstance(config, ServerConfig)

    def test_server_config_str_representation(self):
        """Test string representation of ServerConfig."""
        config = ServerConfig(
            name="str-test",
            host="0.0.0.0",
            port=9000,
            version="2.0.0",
            app_desc="String test",
            api_prefix="/api/v2",
            workers=2,
            debug=False,
            log_file_path="/var/log/app.log",
            win_tz="Pacific Standard Time",
            linux_tz="America/Los_Angeles",
            enable_rate_limit=False,
            global_default_limits="200/minute",
        )

        str_repr = str(config)
        assert "ServerConfig(" in str_repr
        assert "str-test" in str_repr
        assert "0.0.0.0" in str_repr
        assert "9000" in str_repr

    def test_server_config_with_boolean_values(self):
        """Test ServerConfig with various boolean values."""
        # Test with debug=True, rate_limit=False
        config1 = ServerConfig(
            name="bool-test-1",
            host="localhost",
            port=8000,
            version="1.0",
            app_desc="Boolean test 1",
            api_prefix="/api",
            workers=1,
            debug=True,
            log_file_path="/tmp/debug.log",
            win_tz="UTC",
            linux_tz="UTC",
            enable_rate_limit=False,
            global_default_limits="100/minute",
        )

        assert config1.debug is True
        assert config1.enable_rate_limit is False

        # Test with debug=False, rate_limit=True
        config2 = ServerConfig(
            name="bool-test-2",
            host="localhost",
            port=8001,
            version="1.0",
            app_desc="Boolean test 2",
            api_prefix="/api",
            workers=1,
            debug=False,
            log_file_path="/tmp/prod.log",
            win_tz="UTC",
            linux_tz="UTC",
            enable_rate_limit=True,
            global_default_limits="50/minute",
        )

        assert config2.debug is False
        assert config2.enable_rate_limit is True

    def test_server_config_with_edge_case_values(self):
        """Test ServerConfig with edge case values."""
        config = ServerConfig(
            name="", # Empty name
            host="0.0.0.0",
            port=65535, # Max port number
            version="0.0.1-alpha", # Version with special characters
            app_desc='App with "quotes" and special chars: !@#$%',
            api_prefix="/", # Minimal prefix
            workers=1, # Minimum workers
            debug=False,
            log_file_path="/very/long/path/to/log/file/that/might/not/exist.log",
            win_tz="UTC+12",
            linux_tz="UTC-11",
            enable_rate_limit=True,
            global_default_limits="1/second", # Very restrictive limit
        )

        assert config.name == ""
        assert config.port == 65535
        assert config.workers == 1
        assert "quotes" in config.app_desc


class TestDatabaseConfig:
    """Test cases for DatabaseConfig class."""

    @patch("src.main.app.libs.config.database_config.project_config_util")
    def test_database_config_initialization_all_params(self, mock_util):
        """Test DatabaseConfig initialization with all parameters."""
        config = DatabaseConfig(
            pool_size=10,
            max_overflow=20,
            pool_recycle=7200,
            echo_sql=True,
            pool_pre_ping=True,
            enable_redis=True,
            cache_host="redis.example.com",
            cache_port=6379,
            cache_pass="secret",
            db_num=1,
            dialect="postgresql",
            url="postgresql://user:pass@localhost:5432/testdb",
        )

        assert config.pool_size == 10
        assert config.max_overflow == 20
        assert config.pool_recycle == 7200
        assert config.echo_sql is True
        assert config.pool_pre_ping is True
        assert config.enable_redis is True
        assert config.cache_host == "redis.example.com"
        assert config.cache_port == 6379
        assert config.cache_pass == "secret"
        assert config.db_num == 1
        assert config.dialect == "postgresql"
        assert config.url == "postgresql://user:pass@localhost:5432/testdb"

    @patch("src.main.app.libs.config.database_config.project_config_util")
    def test_database_config_with_none_dialect(self, mock_util):
        """Test DatabaseConfig with None dialect (should use default)."""
        mock_util.get_db_dialect.return_value = "mysql"
        mock_util.get_db_url.return_value = "mysql://localhost/testdb"

        config = DatabaseConfig(
            pool_size=5,
            max_overflow=10,
            pool_recycle=3600,
            echo_sql=False,
            pool_pre_ping=False,
            enable_redis=False,
            cache_host="localhost",
            cache_port=6379,
            cache_pass="",
            db_num=0,
            dialect=None, # Should trigger default behavior
            url=None,
        )

        assert config.dialect == "mysql"
        mock_util.get_db_dialect.assert_called_once()

    @patch("src.main.app.libs.config.database_config.project_config_util")
    def test_database_config_with_empty_dialect(self, mock_util):
        """Test DatabaseConfig with empty dialect string."""
        mock_util.get_db_dialect.return_value = "sqlite"

        config = DatabaseConfig(
            pool_size=5,
            max_overflow=10,
            pool_recycle=3600,
            echo_sql=False,
            pool_pre_ping=False,
            enable_redis=False,
            cache_host="localhost",
            cache_port=6379,
            cache_pass="",
            db_num=0,
            dialect="   ", # Empty/whitespace string should trigger default
            url="sqlite:///test.db",
        )

        assert config.dialect == "sqlite"
        mock_util.get_db_dialect.assert_called_once()

    @patch("src.main.app.libs.config.database_config.get_sqlite_db_path")
    @patch("src.main.app.libs.config.database_config.project_config_util")
    def test_database_config_sqlite_default_url(self, mock_util, mock_sqlite_path):
        """Test DatabaseConfig with sqlite dialect and no URL (should use default)."""
        mock_sqlite_path.return_value = "sqlite:///default.db"

        config = DatabaseConfig(
            pool_size=5,
            max_overflow=10,
            pool_recycle=3600,
            echo_sql=False,
            pool_pre_ping=False,
            enable_redis=False,
            cache_host="localhost",
            cache_port=6379,
            cache_pass="",
            db_num=0,
            dialect="sqlite",
            url=None,
        )

        assert config.url == "sqlite:///default.db"
        mock_sqlite_path.assert_called_once()

    @patch("src.main.app.libs.config.database_config.project_config_util")
    def test_database_config_non_sqlite_default_url(self, mock_util):
        """Test DatabaseConfig with non-sqlite dialect and no URL."""
        mock_util.get_db_url.return_value = "postgresql://localhost/default"

        config = DatabaseConfig(
            pool_size=5,
            max_overflow=10,
            pool_recycle=3600,
            echo_sql=False,
            pool_pre_ping=False,
            enable_redis=False,
            cache_host="localhost",
            cache_port=6379,
            cache_pass="",
            db_num=0,
            dialect="postgresql",
            url=None,
        )

        assert config.url == "postgresql://localhost/default"
        mock_util.get_db_url.assert_called_once()

    @patch("src.main.app.libs.config.database_config.project_config_util")
    def test_database_config_with_empty_url(self, mock_util):
        """Test DatabaseConfig with empty URL string."""
        mock_util.get_db_url.return_value = "mysql://localhost/fallback"

        config = DatabaseConfig(
            pool_size=5,
            max_overflow=10,
            pool_recycle=3600,
            echo_sql=False,
            pool_pre_ping=False,
            enable_redis=False,
            cache_host="localhost",
            cache_port=6379,
            cache_pass="",
            db_num=0,
            dialect="mysql",
            url="   ", # Whitespace should trigger default behavior
        )

        assert config.url == "mysql://localhost/fallback"
        mock_util.get_db_url.assert_called_once()

    def test_database_config_inheritance(self):
        """Test that DatabaseConfig inherits from BaseConfig."""
        config = DatabaseConfig(
            pool_size=5,
            max_overflow=10,
            pool_recycle=3600,
            echo_sql=False,
            pool_pre_ping=False,
            enable_redis=False,
            cache_host="localhost",
            cache_port=6379,
            cache_pass="",
            db_num=0,
            dialect="sqlite",
            url="sqlite:///test.db",
        )

        assert isinstance(config, BaseConfig)
        assert isinstance(config, DatabaseConfig)

    def test_database_config_str_representation(self):
        """Test string representation of DatabaseConfig."""
        config = DatabaseConfig(
            pool_size=15,
            max_overflow=25,
            pool_recycle=1800,
            echo_sql=True,
            pool_pre_ping=True,
            enable_redis=True,
            cache_host="cache.example.com",
            cache_port=6380,
            cache_pass="cache_secret",
            db_num=2,
            dialect="postgresql",
            url="postgresql://user@host/db",
        )

        str_repr = str(config)
        assert "DatabaseConfig(" in str_repr
        assert "postgresql" in str_repr
        assert "15" in str_repr  # pool_size
        assert "cache.example.com" in str_repr

    def test_database_config_redis_settings(self):
        """Test DatabaseConfig with various Redis settings."""
        config = DatabaseConfig(
            pool_size=5,
            max_overflow=10,
            pool_recycle=3600,
            echo_sql=False,
            pool_pre_ping=False,
            enable_redis=True,
            cache_host="redis-cluster.local",
            cache_port=6380,
            cache_pass="very_secure_password",
            db_num=15,
            dialect="postgresql",
            url="postgresql://localhost/test",
        )

        assert config.enable_redis is True
        assert config.cache_host == "redis-cluster.local"
        assert config.cache_port == 6380
        assert config.cache_pass == "very_secure_password"
        assert config.db_num == 15


class TestSecurityConfig:
    """Test cases for SecurityConfig class."""

    def test_security_config_initialization_all_params(self):
        """Test SecurityConfig initialization with all parameters."""
        config = SecurityConfig(
            enable=True,
            enable_swagger=True,
            algorithm="HS256",
            secret_key="super_secret_key_123",
            access_token_expire_minutes=30,
            refresh_token_expire_minutes=10080,
            white_list_routes="/health,/docs,/openapi.json",
            backend_cors_origins="http://localhost:3000,https://app.example.com",
            black_ip_list="192.168.1.100,10.0.0.50",
        )

        assert config.enable is True
        assert config.enable_swagger is True
        assert config.algorithm == "HS256"
        assert config.secret_key == "super_secret_key_123"
        assert config.access_token_expire_minutes == 30
        assert config.refresh_token_expire_minutes == 10080
        assert config.white_list_routes == "/health,/docs,/openapi.json"
        assert (
            config.backend_cors_origins
            == "http://localhost:3000,https://app.example.com"
        )
        assert config.black_ip_list == "192.168.1.100,10.0.0.50"

    def test_security_config_inheritance(self):
        """Test that SecurityConfig inherits from BaseConfig."""
        config = SecurityConfig(
            enable=False,
            enable_swagger=False,
            algorithm="RS256",
            secret_key="test_key",
            access_token_expire_minutes=15,
            refresh_token_expire_minutes=7200,
            white_list_routes="/public",
            backend_cors_origins="*",
            black_ip_list="",
        )

        assert isinstance(config, BaseConfig)
        assert isinstance(config, SecurityConfig)

    def test_security_config_str_representation(self):
        """Test string representation of SecurityConfig."""
        config = SecurityConfig(
            enable=True,
            enable_swagger=False,
            algorithm="HS512",
            secret_key="test_secret_for_str",
            access_token_expire_minutes=60,
            refresh_token_expire_minutes=20160,
            white_list_routes="/api/health",
            backend_cors_origins="https://frontend.app",
            black_ip_list="malicious.ip.address",
        )

        str_repr = str(config)
        assert "SecurityConfig(" in str_repr
        assert "HS512" in str_repr
        assert "test_secret_for_str" in str_repr
        assert "60" in str_repr

    def test_security_config_disabled_settings(self):
        """Test SecurityConfig with security disabled."""
        config = SecurityConfig(
            enable=False,
            enable_swagger=False,
            algorithm="none",
            secret_key="",
            access_token_expire_minutes=0,
            refresh_token_expire_minutes=0,
            white_list_routes="*",
            backend_cors_origins="*",
            black_ip_list="",
        )

        assert config.enable is False
        assert config.enable_swagger is False
        assert config.algorithm == "none"
        assert config.secret_key == ""
        assert config.access_token_expire_minutes == 0
        assert config.refresh_token_expire_minutes == 0

    def test_security_config_jwt_algorithms(self):
        """Test SecurityConfig with different JWT algorithms."""
        algorithms = [
            "HS256",
            "HS384",
            "HS512",
            "RS256",
            "RS384",
            "RS512",
            "ES256",
            "ES384",
            "ES512",
        ]

        for alg in algorithms:
            config = SecurityConfig(
                enable=True,
                enable_swagger=True,
                algorithm=alg,
                secret_key=f"key_for_{alg}",
                access_token_expire_minutes=30,
                refresh_token_expire_minutes=10080,
                white_list_routes="/health",
                backend_cors_origins="*",
                black_ip_list="",
            )

            assert config.algorithm == alg
            assert config.secret_key == f"key_for_{alg}"

    def test_security_config_token_expiration_edge_cases(self):
        """Test SecurityConfig with edge case token expiration values."""
        # Very short expiration
        config1 = SecurityConfig(
            enable=True,
            enable_swagger=True,
            algorithm="HS256",
            secret_key="short_expiry_key",
            access_token_expire_minutes=1, # 1 minute
            refresh_token_expire_minutes=5, # 5 minutes
            white_list_routes="",
            backend_cors_origins="",
            black_ip_list="",
        )

        assert config1.access_token_expire_minutes == 1
        assert config1.refresh_token_expire_minutes == 5

        # Very long expiration
        config2 = SecurityConfig(
            enable=True,
            enable_swagger=True,
            algorithm="HS256",
            secret_key="long_expiry_key",
            access_token_expire_minutes=525600, # 1 year
            refresh_token_expire_minutes=1051200, # 2 years
            white_list_routes="",
            backend_cors_origins="",
            black_ip_list="",
        )

        assert config2.access_token_expire_minutes == 525600
        assert config2.refresh_token_expire_minutes == 1051200

    def test_security_config_empty_lists(self):
        """Test SecurityConfig with empty list values."""
        config = SecurityConfig(
            enable=True,
            enable_swagger=True,
            algorithm="HS256",
            secret_key="test_key",
            access_token_expire_minutes=30,
            refresh_token_expire_minutes=10080,
            white_list_routes="", # Empty whitelist
            backend_cors_origins="", # Empty CORS origins
            black_ip_list="", # Empty blacklist
        )

        assert config.white_list_routes == ""
        assert config.backend_cors_origins == ""
        assert config.black_ip_list == ""

    def test_security_config_complex_lists(self):
        """Test SecurityConfig with complex comma-separated lists."""
        config = SecurityConfig(
            enable=True,
            enable_swagger=True,
            algorithm="HS256",
            secret_key="complex_config_key",
            access_token_expire_minutes=45,
            refresh_token_expire_minutes=15120,
            white_list_routes="/api/v1/health,/api/v1/status,/api/v1/metrics,/docs,/redoc,/openapi.json",
            backend_cors_origins="http://localhost:3000,http://localhost:3001,https://dev.example.com,https://staging.example.com,https://prod.example.com",
            black_ip_list="192.168.1.100,192.168.1.101,10.0.0.50,172.16.0.100",
        )

        # Test that the full strings are preserved
        assert "/api/v1/health" in config.white_list_routes
        assert "/openapi.json" in config.white_list_routes
        assert "https://prod.example.com" in config.backend_cors_origins
        assert "192.168.1.100" in config.black_ip_list
        assert "172.16.0.100" in config.black_ip_list


class TestConfigClassesCommonBehavior:
    """Test common behavior across all config classes."""

    def test_all_configs_are_baseconfig_subclasses(self):
        """Test that all config classes inherit from BaseConfig."""
        assert issubclass(ServerConfig, BaseConfig)
        assert issubclass(DatabaseConfig, BaseConfig)
        assert issubclass(SecurityConfig, BaseConfig)

    def test_all_configs_implement_str(self):
        """Test that all config classes implement __str__ method."""
        # Create instances with minimal required parameters
        server = ServerConfig(
            name="test",
            host="localhost",
            port=8080,
            version="1.0",
            app_desc="test",
            api_prefix="/api",
            workers=1,
            debug=False,
            log_file_path="/tmp/test.log",
            win_tz="UTC",
            linux_tz="UTC",
            enable_rate_limit=False,
            global_default_limits="100/minute",
        )

        database = DatabaseConfig(
            pool_size=5,
            max_overflow=10,
            pool_recycle=3600,
            echo_sql=False,
            pool_pre_ping=False,
            enable_redis=False,
            cache_host="localhost",
            cache_port=6379,
            cache_pass="",
            db_num=0,
        )

        security = SecurityConfig(
            enable=True,
            enable_swagger=True,
            algorithm="HS256",
            secret_key="test_key",
            access_token_expire_minutes=30,
            refresh_token_expire_minutes=10080,
            white_list_routes="",
            backend_cors_origins="",
            black_ip_list="",
        )

        # All should have string representations
        assert str(server).startswith("ServerConfig(")
        assert str(database).startswith("DatabaseConfig(")
        assert str(security).startswith("SecurityConfig(")

    def test_config_classes_with_dict_representation(self):
        """Test that config classes can be represented as dictionaries through __dict__."""
        server = ServerConfig(
            name="dict-test",
            host="127.0.0.1",
            port=8080,
            version="1.0.0",
            app_desc="Dict test",
            api_prefix="/api",
            workers=2,
            debug=True,
            log_file_path="/tmp/dict.log",
            win_tz="UTC",
            linux_tz="UTC",
            enable_rate_limit=True,
            global_default_limits="50/minute",
        )

        server_dict = server.__dict__
        assert server_dict["name"] == "dict-test"
        assert server_dict["host"] == "127.0.0.1"
        assert server_dict["port"] == 8080
        assert server_dict["debug"] is True
